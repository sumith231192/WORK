package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utility.ConfigFileReader;

public class Login {
	
	WebDriver driver;
	ConfigFileReader configFileReader;


	public Login(WebDriver driver) {
		 
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
		 
		
	}

	
	@FindBy(id = "identifierId")
	private WebElement user_id;
	
	
	@FindBy(id = "identifierNext")
	private WebElement next;
	
	
	public WebDriver naviageToLogin()
	{/*
		System.out.println(driver);
//		driver.get("https://accounts.google.com");
		driver.get(configFileReader.getApplicationUrl());
		System.out.println("URL:"+configFileReader.getApplicationUrl());*/
		return driver;
	}
	public void setUserId(String userid)
	{
		user_id.sendKeys( userid);
	}
	
	
	
	public WebElement getNexr()
	{
		return next;
	}
	
	
	
	
	
}
