package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import Utility.ConfigFileReader;

public class PasswordPage {
	
	WebDriver driver;
	ConfigFileReader configFileReader;

	
	public PasswordPage(WebDriver driver) {
		 
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
		 
		
	}
	
	
	@FindBy(xpath = "//input[@name='password']")
	private WebElement password;
	
	@FindBy(id="passwordNext")
	private WebElement passwordNext;
	
	@FindBy(xpath ="//*[contains(text(), 'welcome')]")
	private WebElement welcome;
	
	
	
	
	
	public void setPassword(String pass_word)
	{
		password.sendKeys( pass_word);
	}
	
	public WebElement pass()
	{
		return password;
	}
	
	public WebElement getPasswordNext()
	{
		return passwordNext;
	}

}
