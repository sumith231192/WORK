package stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.testng.Assert;

import PageObject.Login;
import PageObject.PasswordPage;
//import PageObjectManager.PageObjectManager;
import Utility.ConfigFileReader;
import Utility.Wait;
import Utility.WebDriverManager;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition{
	
//WebDriver driver;


//WebDriver driver;
Login login ;

WebDriverManager webDriverManager;	
ConfigFileReader configFileReader;
PasswordPage passwordPage;




	 @Given("^user is already on gmail login page$")
	 public void user_is_already_on_gmail_login_page() throws Throwable {
		 webDriverManager = new WebDriverManager();
		WebDriver driver = webDriverManager.getDriver();
		 configFileReader= new ConfigFileReader();
		login = new Login(driver);
		 System.out.println(login);
		System.out.println("URL:"+configFileReader.getApplicationUrl());
		login.naviageToLogin().get(configFileReader.getApplicationUrl());
		Wait.untilPageLoadComplete(driver);
		login.setUserId(configFileReader.getUserId());
		 login.getNexr().click();
		 System.out.println("Page Is Going to move to Paaswor See driver"+driver);
		 passwordPage = new PasswordPage(driver);
		 System.out.println(passwordPage);
		 Wait.untilPageLoadComplete(driver);
//		 driver.findElement(By.xpath(""))
//	     passwordPage = new PageObjectManager(driver).getPasswordPage();
		 System.out.println(configFileReader.getPassword());
//		 Wait.until(driver, waitConditi);
		 Wait.waitUnitWebElementVisible(driver, passwordPage.pass());
	     passwordPage.setPassword(configFileReader.getPassword());
		
		 
//		 passwordPage.pass().sendKeys("Sumith");
	     
	     passwordPage.getPasswordNext().click();
		 
	     throw new PendingException();
	 }	 
	
	 @When("^title of login page is gmail$")
	 public void title_of_login_page_is_gmail() throws Throwable {
		/* String title = Driver.getDriver().getTitle();
		 System.out.println(title);
		 Assert.assertEquals("gmail", title); */
	     throw new PendingException();
	 }
	
	 
	
	 @Then("^user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	 public void user_enters_and(String username, String password) throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     throw new PendingException();
	 }

	 @Then("^user clicks on login button$")
	 public void user_clicks_on_login_button() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     throw new PendingException();
	 }

	 @Then("^user is on home page$")
	 public void user_is_on_home_page() throws Throwable {
	     // Write code here that turns the phrase above into concrete actions
	     throw new PendingException();
	 }



	 @Then("^Close the browser$")
	 public void close_the_browser(){
//		 Driver.getDriver().quit();
	 }
	
	
	

}
