package stepDefinitions;

import org.openqa.selenium.WebDriver;

import Utility.WebDriverManager;

public class TestContext {

	public WebDriver getWebDriverManager() {
		WebDriverManager webDriverManager = new WebDriverManager();
			WebDriver driver = webDriverManager.getDriver();
		return driver;
	}

}
