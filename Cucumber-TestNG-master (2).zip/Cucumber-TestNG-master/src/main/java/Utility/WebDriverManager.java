package Utility;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


public class WebDriverManager {
	private WebDriver driver;
	public WebDriver getDriver() {
		if(driver == null) 
			{

			driver = createDriver();
			System.out.println("As Drver is Null Creatig driver"+driver);
			}
		System.out.println(driver);
		return driver;
	}

	private WebDriver createDriver() {
		driver = createLocalDriver();
		   return driver;
	}

	private WebDriver createRemoteDriver() {
		throw new RuntimeException("RemoteWebDriver is not yet implemented");
	}

	private WebDriver createLocalDriver() {

		System.out.println("Initializing Browser.....");	
		String browser = "Chrome";
			if(browser.toUpperCase().equalsIgnoreCase("CHROME"))
			{
			System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
			driver = new ChromeDriver();
//			driver.get("https://accounts.google.com");
			System.out.println("DRIVER:"+driver);
		
			}
			else if(browser.toUpperCase().equalsIgnoreCase("IE"))
			{
			System.setProperty("webdriver.chrome.driver","./drivers/IEDriver.exe");
			driver = new ChromeDriver();
			}
		return driver;
	}	

	public void closeDriver() {
		driver.close();
//		driver.quit();
	}

}