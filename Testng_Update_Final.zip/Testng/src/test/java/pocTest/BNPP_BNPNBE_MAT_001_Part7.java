package pocTest;

import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import helper.Screenshot;
import pageObject.BNPP_BillDetail_Page;
import pageObject.BNPP_Client_Account_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ManualBillableEvents_Page;
import pageObject.BNPP_ShellJobs;
import utility.ConfigFileReader;
import utility.CreedFileValid;
import utility.DataBaseConnection;
import utility.ExcelReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BNPNBE_MAT_001_Part7 {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ManualBillableEvents_Page manualBillableEvents;
	BNPP_Client_Account_Page clientAccountPage;
	BNPP_BillDetail_Page billDetails;
	DataBaseConnection dataBaseConnection;
	XSSFSheet DB_Validation_ExcelWSheet;
	BNPP_ShellJobs shellJob;
	ExcelReader excelReader;
	HashMap<String, String> SheetHash;
	HashMap<String, String> getMultiDbResult;
	String accntNum;
	String chargeCode;
	String queryInExcel;
	String query;
	String datalabel;
	CreedFileValid creFileValid;
	
	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		SheetHash = new HashMap<>();
		excelReader = new ExcelReader();
		DB_Validation_ExcelWSheet = excelReader.getSheet("DB_Validation");
		getMultiDbResult = new HashMap<>();
		dataBaseConnection = new DataBaseConnection();
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		shellJob = new BNPP_ShellJobs();
		creFileValid = new CreedFileValid();
	}
	
	@Test(priority = 70,groups = { "REG_ETOE" })
	public void TC70_VerifyBillDetails_Function() throws Exception {
		homePage.navigateToBNPP_BillDetail_Page("View");
		billDetails = new BNPP_BillDetail_Page(driver);
		billDetails.ckeckBillDetailLabelDisplayed();
		billDetails.SearchBillDetails("TC_ID='TC70' and Sr_No='1'");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC70' and Sr_No='1'","1");
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC70", "SL1");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
	}
	
	@Test(priority = 71,groups = { "REG_ETOE" })
	public void TC71_VerifyBillDetails_Function() throws Exception {
		homePage.navigateToBNPP_BillDetail_Page("View");
		billDetails = new BNPP_BillDetail_Page(driver);
		billDetails.ckeckBillDetailLabelDisplayed();
		billDetails.SearchBillDetails("TC_ID='TC71' and Sr_No='1'");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC71' and Sr_No='1'","1");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC71' and Sr_No='2'","2");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC71' and Sr_No='3'","3");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC71' and Sr_No='4'","4");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC71' and Sr_No='5'","5");
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC71", "SL1");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC71", "SL2");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC71", "SL3");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC71", "SL4");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC71", "SL5");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
	}
	
	@Test(priority = 72,groups = { "REG_ETOE" })
	public void TC72_VerifyBillDetails_Function() throws Exception {
		homePage.navigateToBNPP_BillDetail_Page("View");
		billDetails = new BNPP_BillDetail_Page(driver);
		billDetails.ckeckBillDetailLabelDisplayed();
		billDetails.SearchBillDetails("TC_ID='TC72' and Sr_No='1'");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC72' and Sr_No='2'","2");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC72' and Sr_No='3'","3");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC72' and Sr_No='4'","4");
	}
	
	@Test(priority = 73)
	public void TC73_ReportValidation_Function() throws Exception {
		//Validation for CRE and REVAL generated
	}	
	
	@Test(priority = 74)
	public void TC74_ReportValidation_Function() throws Exception {
		//creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "FEEREV", "X_IE_NAME");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "1275", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "850", "NB_FEE");
				
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1845.634", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10", "NB_FEE");
				
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "1745.634", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "634", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "530.5185", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "45", "NB_FEE");
	}
	
	@Test(priority = 75)
	public void TC75_ReportValidation_Function() throws Exception {
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "1275", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "850", "NB_FEE");
				
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1845.634", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10", "NB_FEE");
				
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "1745.634", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "634", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "530.5185", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "45", "NB_FEE");
	}
	
	@Test(priority = 76)
	public void TC76_ReportValidation_Function() throws Exception {
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "1275", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "850", "NB_FEE");
				
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1845.634", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10", "NB_FEE");
				
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "1745.634", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "634", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "530.5185", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "45", "NB_FEE");
	}
	
	@Test(priority = 77)
	public void TC77_ReportValidation_Function() throws Exception {
		//header validation
		//Validation REVAL
		//Tailor validation
	}
	
	@Test(priority = 78)
	public void TC_78_BNP_Update_application_date_Function() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC78'");
		dataBaseConnection.verifyResult("TC_ID='TC78'");
		}
	
	@Test(priority = 79,groups = { "RUN", "REG_ETOE" })
	public void TC_79_Update_Billing_Group_Function() throws Exception
	{
		//need to get updated code from Bharat 
		
		}
	@Test(priority = 80,groups = { "RUN", "REG_ETOE" })
	public void TC_80_Update_Billing_Group_Function() throws Exception
	{
		//need to get updated code from Bharat 
		
		}
	
	@Test(priority = 81)
	public void TC81_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		homePage.navigateToBNPP_ManualBillableEvents_Page("view");
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.FilterManualTransactionEntry("TC_ID='TC81'");
		manualBillableEvents.CheckManualTransactionEntryView("TC_ID='TC81'");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
		}
	
	@Test(priority = 82,groups = { "RUN", "REG_ETOE" })
	public void TC_82_Update_Billing_Group_Function() throws Exception
	{
		//need to get updated code from Bharat 
		
		}
	
	@Test(priority = 83)
	public void TC83_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC83'");
		shellJob.getUnixConnection(colarray[0]);
	}
	
	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
}
