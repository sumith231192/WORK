package pocTest;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import helper.Screenshot;
import pageObject.BNPP_ClientAccountPricelistDetails_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ManualBillableEvents_Page;
import pageObject.BNPP_ShellJobs;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BNPNBE_MAT_001_Part6 {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ManualBillableEvents_Page manualBillableEvents;
	BNPP_ClientAccountPricelistDetails_Page priceListDetails;
	DataBaseConnection dataBaseConnection;
	BNPP_ShellJobs shellJob;
	
	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		shellJob = new BNPP_ShellJobs();
	}
	
	@Test(priority = 66)
	public void TC_66_BNP_Update_application_date_Test() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC66'");
		dataBaseConnection.verifyResult("TC_ID='TC66'");
		}	
	
	@Test(priority = 67)
	public void TC67_CreatePreferentialPriceList_Function() throws Exception {
		homePage.navigateToBNPP_ClientAccountPricelistDetailsATADMIN_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		priceListDetails = new BNPP_ClientAccountPricelistDetails_Page(driver);
		priceListDetails.ckeckClientAccountPricelistDetailsLabelDisplayed();
		priceListDetails.FilterForPricelistDetails("TC_ID='TC67'");
		priceListDetails.ClientAccountPricelistDetailsCreationORUpdate("TC_ID='TC67'");
		priceListDetails.ckeckClientAccountPricelistDetailsLabelDisplayed();
	}
	
	@Test(priority = 68)
	public void TC68_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		homePage.navigateToBNPP_ManualBillableEvents_Page("view");
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.FilterManualTransactionEntry("TC_ID='TC68'");
		manualBillableEvents.CheckManualTransactionEntryView("TC_ID='TC68'");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
		}
	
	@Test(priority = 69,groups = { "RUN", "REG_ETOE" })
	public void TC69_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC69'");
		shellJob.getUnixConnection(colarray[0]);
	}
	
	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
}
