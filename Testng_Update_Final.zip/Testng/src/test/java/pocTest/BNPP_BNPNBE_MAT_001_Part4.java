package pocTest;

import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import helper.Screenshot;
import pageObject.BNPP_BillDetail_Page;
import pageObject.BNPP_BookingCancellation_Page;
import pageObject.BNPP_ChargeAccountDefinition_Page;
import pageObject.BNPP_ClientAccountPricelistDetails_Page;
import pageObject.BNPP_ClientHierarchy_Page;
import pageObject.BNPP_Client_Account_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ManualBillableEvents_Page;
import pageObject.BNPP_OfficerAdjustmentsDebit_Page;
import pageObject.BNPP_Package_Definition_Page;
import pageObject.BNPP_ShellJobs;
import pageObject.BNPP_Subscription_Page;
import utility.ConfigFileReader;
import utility.CreedFileValid;
import utility.DataBaseConnection;
import utility.ExcelReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BNPNBE_MAT_001_Part4 {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ClientHierarchy_Page clientHierarchy;
	BNPP_BookingCancellation_Page bookingcancel;
	BNPP_Package_Definition_Page packagedefinition;
	BNPP_ChargeAccountDefinition_Page chargeAccountDefinition;
	BNPP_ManualBillableEvents_Page manualBillableEvents;
	BNPP_OfficerAdjustmentsDebit_Page AdjustmentsDebit;
	BNPP_Subscription_Page subscriptionPage;
	BNPP_ClientAccountPricelistDetails_Page priceListDetails;
	BNPP_Client_Account_Page clientAccountPage;
	BNPP_BillDetail_Page billDetails;
	DataBaseConnection dataBaseConnection;
	XSSFSheet DB_Validation_ExcelWSheet;
	BNPP_ShellJobs shellJob;
	ExcelReader excelReader;
	HashMap<String, String> SheetHash;
	HashMap<String, String> getMultiDbResult;
	String accntNum;
	String chargeCode;
	String queryInExcel;
	String query;
	String datalabel;
	CreedFileValid creFileValid;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		SheetHash = new HashMap<>();
		excelReader = new ExcelReader();
		DB_Validation_ExcelWSheet = excelReader.getSheet("DB_Validation");
		getMultiDbResult = new HashMap<>();
		dataBaseConnection = new DataBaseConnection();
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		shellJob = new BNPP_ShellJobs();
		creFileValid = new CreedFileValid();
		
	}
	@Test(priority = 44,groups = { "REG_ETOE" })
	public void TC44_VerifyBillDetails_Function() throws Exception {
		homePage.navigateToBNPP_BillDetail_Page("View");
		billDetails = new BNPP_BillDetail_Page(driver);
		billDetails.ckeckBillDetailLabelDisplayed();
		billDetails.SearchBillDetails("TC_ID='TC44' and Sr_No='1'");
		//billDetails.VerifyBillDetails("TC_ID='TC44' and Sr_No='1'");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC44' and Sr_No='2'","1");
	}
	
	@Test(priority = 45,groups = { "RUN", "REG_ETOE" })
	public void TC_45_Verify_Settlement_for_Charges_Adjustment_CRE_Function() throws Exception
	{
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1432.99", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "121.55", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "8125", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "625", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "003", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "11.79", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "100", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "257.9344", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "20", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "135.56735", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "", "NB_FEE");		
		}
	
	@Test(priority = 46,groups = { "RUN", "REG_ETOE" })
	public void TC_46_Verify_Accrual_Entires_CRE_Function() throws Exception
	{
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1432.99", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "121.55", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "8125", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "625", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "003", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "11.79", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "100", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "257.9344", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "20", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000022", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "004", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "24", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "000022", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "005", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "320.24483125", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "825", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "175", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "750", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "634", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10020.905", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "850", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "135.56735", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "155.56735", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "", "NB_FEE");
		
		}
	@Test(priority = 47,groups = { "RUN", "REG_ETOE" })
	public void TC_47_Verify_Reversal_Entires_CRE_Function() throws Exception
	{
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1432.99", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "121.55", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "8125", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "625", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "003", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "11.79", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "100", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "257.9344", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "20", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000022", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "004", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "24", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "000022", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "005", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "320.24483125", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "825", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "175", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDV", "750", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "11.7893", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTICO", "634", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "10020.905", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "850", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "135.56735", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "000023", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "006", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "155.56735", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSCTICO", "", "NB_FEE");
		}
	
	@Test(priority = 48,groups = { "RUN", "REG_ETOE" })
	public void TC_48_Verify_Invoice_REVAL_Function() throws Exception
	{	
		//header validation
		//all in Reval
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "1432.99", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "121.55", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "002", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "8125", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDCOR", "625", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "003", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "11.79", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "CLSDDB2B", "100", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "257.9344", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSDC", "20", "NB_FEE");
		
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "10002", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "000021", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "001", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "EUR", "CLT_CURR");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "135.56735", "AMT_FEE");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSDDB2B", "", "NB_FEE");
		//Tailor validation
		}
		
	//Test 49, 50 & 51 OUTOFSCOPE
	
	@Test(priority = 52)
	public void TC_52_BNP_Update_application_date_Function() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC52'");
		dataBaseConnection.verifyResult("TC_ID='TC52'");
		}
	
	@Test(priority = 53)
	public void TC53_Update_Account_Level_Exception_Rate_Function() throws Exception {
		homePage.navigateToBNPP_ClientAccountPricelistDetailsATADMIN_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		priceListDetails = new BNPP_ClientAccountPricelistDetails_Page(driver);
		priceListDetails.ckeckClientAccountPricelistDetailsLabelDisplayed();
		priceListDetails.FilterForPricelistDetails("TC_ID='TC53'");
		priceListDetails.ClientAccountPricelistDetailsCreationORUpdate("TC_ID='TC53'");
		priceListDetails.ckeckClientAccountPricelistDetailsLabelDisplayed();
	}	

	@Test(priority = 54)
	public void TC54_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		homePage.navigateToBNPP_ManualBillableEvents_Page("view");
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.FilterManualTransactionEntry("TC_ID='TC54'");
		manualBillableEvents.CheckManualTransactionEntryView("TC_ID='TC54'");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC54", "SL1");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
	
		String[] colarray = shellJob.getTestData("TC_ID='TC54'");
		shellJob.getUnixConnection(colarray[0]);
	}

	@Test(priority = 55,groups = { "RUN", "REG_ETOE" })
	public void TC55_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC55'");
		shellJob.getUnixConnection(colarray[0]);
	}

	@Test(priority = 56,groups = { "RUN", "REG_ETOE" })
	public void TC56_validateCreateNewTransaction_Function() throws Exception {

		//Reval Report Validation
	}

	@Test(priority = 57)
	public void TC57_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.CreateManualTransactionEntry("TC_ID='TC57'");
		// manualBillableEvents.AddButton().click();
		// Wait.untilPageLoadComplete(driver);
		// manualBillableEvents.CreateManualTransactionEntry();
		// manualBillableEvents.AddButton().click();
		// Wait.untilPageLoadComplete(driver);
		// manualBillableEvents.CreateManualTransactionEntry();
		manualBillableEvents.SaveButton().click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
		// manualBillableEvents.CheckManualTransactionEntrySuccessful();
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 58)
	public void TC58_AccountMarkedForClosure_Function() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC58'");
		Thread.sleep(1000);
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.selectAccountUpdMFC("Yes");
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();

			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 59)
	public void TC59_WaiveAccount_Function() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC59'");
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.selectAccountUpdWaiveBill("Yes");
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 60)
	public void TC60_BookingCancellation_Function() throws Exception {
		homePage.navigateTo_BNPP_Booking_Cancellation_Page();
		Wait.untilPageLoadComplete(driver);
		bookingcancel = new BNPP_BookingCancellation_Page(driver);
		bookingcancel.validateCreationLabelDisplayed();
		bookingcancel.validate_booking_cancelation("TC_ID='TC60'");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 61,groups = { "RUN", "REG_ETOE" })
	public void TC61_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC61'");
		shellJob.getUnixConnection(colarray[0]);
	}

	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}

}
