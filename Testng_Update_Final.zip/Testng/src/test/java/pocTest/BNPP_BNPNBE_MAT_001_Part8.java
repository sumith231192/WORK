package pocTest;

import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObject.BNPP_BillDetail_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ShellJobs;
import utility.ConfigFileReader;
import utility.CreedFileValid;
import utility.DataBaseConnection;
import utility.ExcelReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BNPNBE_MAT_001_Part8 {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;	
	BNPP_BillDetail_Page billDetails;
	DataBaseConnection dataBaseConnection;
	XSSFSheet DB_Validation_ExcelWSheet;
	BNPP_ShellJobs shellJob;
	ExcelReader excelReader;
	HashMap<String, String> SheetHash;
	HashMap<String, String> getMultiDbResult;
	String accntNum;
	String chargeCode;
	String queryInExcel;
	String query;
	String datalabel;
	CreedFileValid creFileValid;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		SheetHash = new HashMap<>();
		excelReader = new ExcelReader();
		DB_Validation_ExcelWSheet = excelReader.getSheet("DB_Validation");
		getMultiDbResult = new HashMap<>();
		dataBaseConnection = new DataBaseConnection();
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		shellJob = new BNPP_ShellJobs();
		creFileValid = new CreedFileValid();
	}
	
	@Test(priority = 84,groups = { "RUN", "REG_ETOE" })
	public void TC_84_Verify_Transcation_Deleted_From_Table_Function() throws Exception
	{
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC71", "SL1");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		}
	
	@Test(priority = 85,groups = { "REG_ETOE" })
	public void TC85_VerifyBillDetails_Function() throws Exception {
		homePage.navigateToBNPP_BillDetail_Page("View");
		billDetails = new BNPP_BillDetail_Page(driver);
		billDetails.ckeckBillDetailLabelDisplayed();
		billDetails.SearchBillDetails("TC_ID='TC85' and Sr_No='1'");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC85' and Sr_No='1'","1");
	}
	
	@Test(priority = 86)
	public void TC86_ReportValidation_Function() throws Exception {
		
		//Need to conform for negative validation
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "     ", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "      ", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "   ", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "   ", "CLT_CURR");
						
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "     ", "CLT_BRANCH");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "      ", "CLT_RADIX");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "   ", "CLT_ORDIN");
		creFileValid.checkVlaueIsAvalableInFieldname("RDJ_TB_001_ALL_20170110_1_ATCDL", "PYSCTSTD", "   ", "CLT_CURR");
	}
	
	@Test(priority = 87)
	public void TC87_ReportValidation_Function() throws Exception {
		//Validation for REVAL generated
	}
	
	public void TC_88_BNP_Update_application_date_Function() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC88'");
		dataBaseConnection.verifyResult("TC_ID='TC88'");
		}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC89_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC89'");
		shellJob.getUnixConnection(colarray[0]);
	}
	
	public void TC_90_BNP_Update_application_date_Function() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC90'");
		dataBaseConnection.verifyResult("TC_ID='TC90'");
		}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC91_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC91'");
		shellJob.getUnixConnection(colarray[0]);
	}
	
	@Test(priority = 92)
	public void TC92_ReportValidation_Function() throws Exception {
		//Validation for REVAL generated
	}

	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
}
