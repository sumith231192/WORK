package pocTest;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pageObject.BNPP_BillDetail_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ShellJobs;
import utility.ConfigFileReader;
import utility.CreedFileValid;
import utility.DataBaseConnection;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BNPNBE_MAT_001_Part5 {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	DataBaseConnection dataBaseConnection;
	BNPP_BillDetail_Page billDetails;
	BNPP_ShellJobs shellJob;
	
	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {
		
		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		shellJob = new BNPP_ShellJobs();		
	}
	
	@Test(priority = 62)
	public void TC62_ReportValidation_Function() throws Exception {
		homePage.navigateToBNPP_BillDetail_Page("View");
		billDetails = new BNPP_BillDetail_Page(driver);
		billDetails.ckeckBillDetailLabelDisplayed();
		billDetails.SearchBillDetails("TC_ID='TC62' and Sr_No='1'");
		billDetails.VerifyAccountSummaryDetails("TC_ID='TC62' and Sr_No='1'","1");
		//Validation for CRE and REVAL generated
	}
		
	@Test(priority = 63,groups = { "RUN", "REG_ETOE" })
	public void TC63_validateCreateNewTransaction() throws Exception {
		
		//Validation for CRE and REVAL generated
	}
	
	@Test(priority = 64)
	public void TC_64_BNP_Update_application_date_Test() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC64'");
		dataBaseConnection.verifyResult("TC_ID='TC64'");
		}

	@Test(priority = 65,groups = { "RUN", "REG_ETOE" })
	public void TC65_validateCreateNewTransaction() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC65'");
		shellJob.getUnixConnection(colarray[0]);
	}
	
}
