package pocTest;

import java.util.HashMap;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pageObject.BNPP_ShellJobs;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.ExcelUtils;
import utility.ExcelReader;

public class BNPP_BNPNBE_MAT_001_Part2 {
	ConfigFileReader configFileReader;
	DataBaseConnection dataBaseConnection;
	XSSFSheet DB_Validation_ExcelWSheet;
	BNPP_ShellJobs shellJob;
	ExcelReader excelReader;
	HashMap<String, String> SheetHash;
	HashMap<String, String> getMultiDbResult;
	String accntNum;
	String chargeCode;
	String queryInExcel;
	String query;
	String datalabel;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		SheetHash = new HashMap<>();
		excelReader = new ExcelReader();
		DB_Validation_ExcelWSheet = excelReader.getSheet("DB_Validation");
		getMultiDbResult = new HashMap<>();
		dataBaseConnection = new DataBaseConnection();
		shellJob = new BNPP_ShellJobs();
	}

	@Test(priority = 28, groups = { "RUN", "REG_ETOE" })
	public void TC_28_Verify_Consolidated_Data_Table_Function() throws Exception {

		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL1");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		// dataBaseConnection.ceckDbResultValue(getMultiDbResult,excelReader.getValueFromExcel(SheetHash, "Account_Numer"));
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL2");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL3");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL4");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		// dataBaseConnection.ceckDbResultValue(getMultiDbResult,excelReader.getValueFromExcel(SheetHash, "Account_Numer"));
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL5");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL6");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL7");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		// dataBaseConnection.ceckDbResultValue(getMultiDbResult,excelReader.getValueFromExcel(SheetHash, "Account_Numer"));
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL8");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC28", "SL9");
		accntNum = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_3");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "CD_CFIELD20_2");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account_Number", accntNum).replace("Charge_Code", chargeCode);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
	}

	@Test(priority = 29, groups = { "RUN", "REG_ETOE" })
	public void TC_29_Verify_Charge_Computed_Function() throws Exception {
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC29", "SL1");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		// dataBaseConnection.ceckDbResultValue(getMultiDbResult,excelReader.getValueFromExcel(SheetHash, "Account_Numer"));
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC29", "SL2");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC29", "SL3");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC29", "SL4");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
		// dataBaseConnection.ceckDbResultValue(getMultiDbResult,excelReader.getValueFromExcel(SheetHash, "Account_Numer"));
		
		SheetHash = excelReader.getHashValueFromExcel(DB_Validation_ExcelWSheet, "TC29", "SL5");
		accntNum = excelReader.getValueFromExcel(SheetHash, "ptd_a_ph");
		chargeCode = excelReader.getValueFromExcel(SheetHash, "PTD_PRODUCT");
		datalabel = excelReader.getValueFromExcel(SheetHash, "tbms_data_label");
		queryInExcel = excelReader.getValueFromExcel(SheetHash, "SQL_Query");
		query = queryInExcel.replace("Account Number", accntNum).replace("Charge Code", chargeCode).replace("data label", datalabel);
		getMultiDbResult = dataBaseConnection.getMultiDbResult(query);
		dataBaseConnection.ceckTotalDBWithTotalExcelForTest(getMultiDbResult, SheetHash);
	}

	// TC_30 OUTOFSCOPE

	@Test(priority = 31, groups = { "RUN", "REG_ETOE" })
	public void TC_31_BNP_Update_application_date_Function() throws Exception {
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC31'");
		dataBaseConnection.verifyResult("TC_ID='TC31'");
	}

	@Test(priority = 32, groups = { "RUN", "REG_ETOE" })
	public void TC32_validateCreateNewTransaction_Function() throws Exception {

		String[] colarray = shellJob.getTestData("TC_ID='TC32'");
		shellJob.getUnixConnection(colarray[0]);
	}

}
