package test;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_Package_Definition_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_Package_Definition_Test {
	ConfigFileReader configFileReader;
	BNPP_Package_Definition_Page pd;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Environment_Page envPage;
	BNPP_Login_Page loginPage;
	BNPP_Home_Page homePage;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@BeforeMethod(groups = { "REG_ETOE" })
	public void BeforePage() throws ClassNotFoundException, SQLException {
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		Wait.untilPageLoadComplete(driver);
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		Wait.untilPageLoadComplete(driver);
		homePage = new BNPP_Home_Page(driver);
		Wait.untilPageLoadComplete(driver);
		homePage.navigateTo_BPNPP_PackageDefinition_Page("CREATE");
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC13_BNP_Define_package() throws Exception {
		pd = new BNPP_Package_Definition_Page(driver);
		pd.definePakageCode("TC_ID='TC01'");
		pd.definePakageChagecode("CC");
		pd.savePackageDefinition();
	}
}
