package test;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObject.BNPP_ClientHierarchy_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_ClientHierarchy_Test {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ClientHierarchy_Page clientHierarchy;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;
	DataBaseConnection dataBaseConnection;

	@BeforeClass(enabled= false)
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@BeforeMethod(enabled= false)
	public void BeforePage() throws ClassNotFoundException, SQLException {
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		homePage.navigateToBNPP_ClientHierarchy_Page("view");
		Wait.untilPageLoadComplete(driver);
	}

	@Test(enabled= false)
	public void TC1_ClientHierarchy_Function() throws Exception {
		clientHierarchy = new BNPP_ClientHierarchy_Page(driver);
		clientHierarchy.ckeckClientHierarchyLabelDisplayed();
		clientHierarchy.EnterClientHierarchyDetails("TC_ID='TC01'");
		clientHierarchy.VerifyLocalHierarchyDisplayed();
	}
	
	@Test(groups = { "TEST","DB", "REG_ETOE" })
	public void TC_1_BNP_Update_application_date_Test() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		String DateValue = "02/01/2016";
		dataBaseConnection.updateDbDate(DateValue);
		dataBaseConnection.getDbResult(dataBaseReader.getCheckDBDateQuery());
		}
		
	@AfterClass(enabled= false)
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
}
