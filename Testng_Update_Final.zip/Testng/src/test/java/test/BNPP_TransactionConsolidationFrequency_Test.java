package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import org.testng.annotations.Test;

import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_FileUpload_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_TransactionConsolidationFrequency_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_TransactionConsolidationFrequency_Test {

	ConfigFileReader configFileReader;
	BNPP_TransactionConsolidationFrequency_Page tcf;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Environment_Page envPage;
	BNPP_Login_Page loginPage;
	BNPP_Home_Page homePage;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;
	BNPP_FileUpload_Page fileUploadPage;

	@BeforeClass(groups = { "RUN", "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@BeforeMethod(groups = { "RUN", "REG_ETOE" })
	public void BeforePage() {
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		Wait.untilPageLoadComplete(driver);
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		Wait.untilPageLoadComplete(driver);
		homePage = new BNPP_Home_Page(driver);
		homePage.navigateTo_BNPP_TransactionConsolidationFrequency_Page("CREATE");
		Wait.untilPageLoadComplete(driver);

	}

	@Test(groups = { "RUN", "REG_ETOE", "BNPP_TransactionConsolidationFrequency_Test" })
	public void TC1_validateCreateNewTransaction() throws Exception {
		tcf = new BNPP_TransactionConsolidationFrequency_Page(driver);
		tcf.transactionConsolidationFrequencyLabel();
		tcf.transactioncosolidation("TC_ID='TC01'");
		tcf.validateCreation();

	}
	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}

}
