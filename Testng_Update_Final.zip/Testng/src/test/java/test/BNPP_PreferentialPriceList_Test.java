package test;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import helper.FilePathReader;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_FileUpload_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_Package_Definition_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_PreferentialPriceList_Test {

	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Environment_Page envPage;
	BNPP_Login_Page loginPage;
	BNPP_Home_Page homePage;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;
	BNPP_FileUpload_Page fileUploadPage;
	BNPP_Package_Definition_Page package_Definition_Page;
	FilePathReader filePathReader;

	@BeforeClass(groups = { "TEST", "RUN", "REG_ETOE" })
	public void initWebDriver() throws ClassNotFoundException, SQLException {

		
	
		configFileReader = new ConfigFileReader();
	}

	@BeforeMethod(groups = { "TEST", "RUN", "REG_ETOE" })
	public void BeforePage() {
		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		driver.get(configFileReader.getApplicationUrl());
		Wait.untilPageLoadComplete(driver);
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		Wait.untilPageLoadComplete(driver);

	}

	@Test(groups = { "TEST", "REG_ETOE" } )
	public void TC05_BNP_Attach_Price_List_FileUpload() throws ClassNotFoundException, SQLException {

		homePage = new BNPP_Home_Page(driver);
		Wait.untilPageLoadComplete(driver);
		homePage.navigateToBNPP_FileUpload_Page("CREATE");
		fileUploadPage = new BNPP_FileUpload_Page(driver);
		Wait.untilPageLoadComplete(driver);
		fileUploadPage.ckeckPageFileUploadLabelDisplayed();

		//fileUploadPage.fillProcessname("PRICING_PREF");
		//fileUploadPage.uploadCopyOfFile("PRICING_PREF");
//		fileUploadPage.deleteCopyOfFileCreated("PRICING_PREF");
		fileUploadPage.checkFileUploadStatus();

	}

	@Test(groups = { "TEST", "RUN", "REG_ETOE" })
	public void TC16_BNP_CreatePreferentialPriceList_FileUpload_PRICING_PREF_Test()
			throws ClassNotFoundException, SQLException {

		homePage = new BNPP_Home_Page(driver);
		Wait.untilPageLoadComplete(driver);
		homePage.navigateToBNPP_FileUpload_Page("CREATE");
		fileUploadPage = new BNPP_FileUpload_Page(driver);
		Wait.untilPageLoadComplete(driver);
		//fileUploadPage.ckeckPageFileUploadLabelDisplayed();
//			fileUploadPage.enterProcessname("OFFER_ADJST");
		//fileUploadPage.fillProcessname("PRICING_PREF");
		//fileUploadPage.uploadCopyOfFile("PRICING_PREF");
//		fileUploadPage.deleteCopyOfFileCreated("PRICING_PREF");
		fileUploadPage.checkFileUploadStatus();

	}

	@Test(groups = { "TEST", "REG_ETOE" })
	public void TC20_BNP_CreatePreferentialPriceList_FileUpload_OFFER_ADJST_Test()
			throws ClassNotFoundException, SQLException {

		homePage = new BNPP_Home_Page(driver);
		Wait.untilPageLoadComplete(driver);
		homePage.navigateToBNPP_FileUpload_Page("CREATE");
		fileUploadPage = new BNPP_FileUpload_Page(driver);
		Wait.untilPageLoadComplete(driver);
		fileUploadPage.ckeckPageFileUploadLabelDisplayed();
//			fileUploadPage.enterProcessname("OFFER_ADJST");
		//fileUploadPage.fillProcessname("OFFER_ADJST");
		//fileUploadPage.uploadCopyOfFile("OFFER_ADJST");
//		fileUploadPage.deleteCopyOfFileCreated("OFFER_ADJST");
		fileUploadPage.checkFileUploadStatus();

	}

	@Test(groups = { "TEST", "REG_ETOE" })
	public void TC20_1_BNP_CreatePreferentialPriceList_FileUpload_MANUAL_EVENTS_Test()
			throws ClassNotFoundException, SQLException {

		homePage = new BNPP_Home_Page(driver);
		Wait.untilPageLoadComplete(driver);
		homePage.navigateToBNPP_FileUpload_Page("CREATE");
		fileUploadPage = new BNPP_FileUpload_Page(driver);
		Wait.untilPageLoadComplete(driver);
		fileUploadPage.ckeckPageFileUploadLabelDisplayed();
//			fileUploadPage.enterProcessname("OFFER_ADJST");
		//fileUploadPage.fillProcessname("MANUAL_EVENTS");
		//fileUploadPage.uploadCopyOfFile("MANUAL_EVENTS");
//		fileUploadPage.deleteCopyOfFileCreated("MANUAL_EVENTS");
		fileUploadPage.checkFileUploadStatus();

	}

	@AfterMethod(groups = { "TEST", "RUN", "REG_ETOE" })
	public void AfterMethord() {
		
		driver.quit();
//		filePathReader.deletTempFileCreated("");
		
	}

	/*@AfterClass(groups = { "TEST", "RUN", "REG_ETOE" })
	public void AfterClass() {
		 driver.close();
		filePathReader.deletTempFileCreated("");
	}*/

}
