package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import pageObject.BNPP_Environment_Page;

import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_Package_Definition_Page;
import pageObject.BNPP_StandardPricelistDefinition_Page;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_StandardPricelitsDefinition_Test {
	ConfigFileReader configFileReader;
	BNPP_StandardPricelistDefinition_Page sp;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Environment_Page envPage;
	BNPP_Login_Page loginPage;
	BNPP_Home_Page homePage;
	String title_Login;

	@BeforeClass(groups = { "RUN", "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@BeforeMethod(groups = { "RUN", "REG_ETOE" })
	public void BeforePage() {
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		Wait.untilPageLoadComplete(driver);
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		Wait.untilPageLoadComplete(driver);
		homePage = new BNPP_Home_Page(driver);
		homePage.navigateTo_BNPP_StandardPricelisDefinition_Page("CREATE");
		Wait.untilPageLoadComplete(driver);

	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC1_validateCreateNewTransaction() throws Exception {
		
		sp.BNPP_StandardPriceltisDefinition_Page(driver);
		sp.standard_pricelist_definitionLabel();
		sp.Standardpricelisdefinition("TC_ID='TC01'");
		sp.validateCreationLabelDisplayed();

	}

}
