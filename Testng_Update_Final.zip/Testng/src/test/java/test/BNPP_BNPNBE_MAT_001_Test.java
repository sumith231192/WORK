package test;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;

import helper.AssertionHelper;
import helper.Screenshot;
import pageObject.BNPP_BookingCancellation_Page;
import pageObject.BNPP_ChargeAccountDefinition_Page;
import pageObject.BNPP_ClientHierarchy_Page;
import pageObject.BNPP_Client_Account_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ManualBillableEvents_Page;
import pageObject.BNPP_OfficerAdjustmentsDebit_Page;
import pageObject.BNPP_Package_Definition_Page;
import pageObject.BNPP_Subscription_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BNPNBE_MAT_001_Test {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ClientHierarchy_Page clientHierarchy;
	BNPP_BookingCancellation_Page bookingcancel;
	BNPP_Package_Definition_Page packagedefinition;
	BNPP_ChargeAccountDefinition_Page chargeAccountDefinition;
	BNPP_ManualBillableEvents_Page manualBillableEvents;
	BNPP_OfficerAdjustmentsDebit_Page AdjustmentsDebit;
	BNPP_Subscription_Page subscriptionPage;
	BNPP_Client_Account_Page clientAccountPage;
	DataBaseConnection dataBaseConnection;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
	}

	@Test(priority = 2,enabled=false)
	public void TC_02_ClientHierarchy_Function() throws Exception {
		homePage.navigateToBNPP_ClientHierarchy_Page("view");
		Wait.untilPageLoadComplete(driver);
		clientHierarchy = new BNPP_ClientHierarchy_Page(driver);
		clientHierarchy.ckeckClientHierarchyLabelDisplayed();
		clientHierarchy.EnterClientHierarchyDetails("TC_ID='TC01'");
		clientHierarchy.VerifyLocalHierarchyDisplayed();
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 3,enabled=false)
	public void TC03_ClientAddressUpdate() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			String[] colArray = clientAccountPage.getTestData("TC_ID='TC03' and Sr_No='1'");
			clientAccountPage.verifyAdrressCode(colArray);
			clientAccountPage.clickUpdateClient();

		} else
			AssertionHelper.markFail("Client Account screen not present");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 4,enabled=false)
	public void TC04_attachPriceListUI() throws FilloException, Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC04'");
		clientAccountPage.clickclientMaintenance();
		Wait.untilPageLoadComplete(driver);
		clientAccountPage.checkClientMaintenancePageHeader();
		clientAccountPage.enterMaintenanceClientID(colArray[0]);
		// clientAccountPage.enterClientMaintenanceDate(colArray[7]);
		clientAccountPage.selectClientMaintenanceDropdown();
		clientAccountPage.enterMaintenanceType(colArray[10]);
		clientAccountPage.clickClientMaintenanceDetails();
		clientAccountPage.enterClientMaintenancePriceList(colArray[11]);
		clientAccountPage.clickClientMaintenanceOKButton();
		clientAccountPage.clickClientMaintenanceSaveButton();
		clientAccountPage.checkClientAcctUpdateStatus();
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 6,enabled=false)
	public void TC1_ChargeAccountDefinition_Function() throws Exception {
		homePage.navigateToBNPP_ChargeAccountDefinition_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		chargeAccountDefinition = new BNPP_ChargeAccountDefinition_Page(driver);
		chargeAccountDefinition.ckeckChargeAccountDefinitionLabelDisplayed();
		chargeAccountDefinition.EnterDataForChargeAccountDefinition("TC_ID='TC01'");
		// chargeAccountDefinition.AddButton().click();
		// chargeAccountDefinition.EnterDataForChargeAccountDefinition();
		chargeAccountDefinition.SaveButton().click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "ChargeAccountDefinition\\");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 8,enabled=false)
	public void TC08_SetInvoiceLevel() throws FilloException, Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC08'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		Thread.sleep(2000);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.setClientUpdInvoiceLvl(colArray[2]);
				clientAccountPage.clickSaveButton();
				Wait.untilPageLoadComplete(driver);
				clientAccountPage.checkClientAcctUpdateStatus();
			} else {
				System.out.println(pageTitleDisplayed);
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
			}
		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 9,enabled=false)
	public void TC09_SetInvoiceTemplet() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC09'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.setInvoiceTemplet(colArray[4]);
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
		} else
			new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 10,enabled=false)
	public void TC10_SetInvoiceLanguageAndDistributionChannel() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC10'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.setInvoiceLanguage(colArray[3]);
				clientAccountPage.setInvoiceDisributionChannel(colArray[5]);
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();

			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 11,enabled=false)
	public void TC11_CreateSubscriptionArrear() throws Exception {
		homePage.navigateToSubscription("Create");
		subscriptionPage = new BNPP_Subscription_Page(driver);
		String[] colArray = subscriptionPage.getTestData("TC_ID='TC11'");
		subscriptionPage.enterClientBgID(colArray[0]);
		subscriptionPage.enterAccount(colArray[1]);
		subscriptionPage.enterChargeCode(colArray[2]);
		Thread.sleep(1000);
		boolean checkChargeCode = subscriptionPage.checkChargecode();
		if (!checkChargeCode)
			subscriptionPage.enterChargeCode(colArray[2]);
		subscriptionPage.enterVolume(colArray[3]);
		subscriptionPage.selectPricingFrequency(colArray[4]);
		subscriptionPage.enterFromDate(colArray[5]);
		subscriptionPage.enterToDate(colArray[6]);
		if (!(configFileReader.getValue("USERID")).equalsIgnoreCase("ATADMIN")) {
			subscriptionPage.selectProRate(configFileReader.getValue(colArray[7]));
			subscriptionPage.selectCollectionMethod(configFileReader.getValue(colArray[8]));
			Thread.sleep(2000);
		}
		subscriptionPage.clickSaveBtn();
		Wait.untilPageLoadComplete(driver);
		subscriptionPage.statusMsg();
		homePage.navigateToSubscription("View");
		subscriptionPage.viewSubscription(colArray);
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 12,enabled=false)
	public void TC12_Subscriptiondvanced() throws Exception {
		homePage.navigateToSubscription("Create");
		subscriptionPage = new BNPP_Subscription_Page(driver);
		String[] colArray = subscriptionPage.getTestData("TC_ID='TC12'");
		subscriptionPage.enterClientBgID(colArray[0]);
		subscriptionPage.enterAccount(colArray[1]);
		subscriptionPage.enterChargeCode(colArray[2]);
		Thread.sleep(1000);
		boolean checkChargeCode = subscriptionPage.checkChargecode();
		if (!checkChargeCode)
			subscriptionPage.enterChargeCode(colArray[2]);
		subscriptionPage.enterVolume(colArray[3]);
		subscriptionPage.selectPricingFrequency(colArray[4]);
		subscriptionPage.enterFromDate(colArray[5]);
		subscriptionPage.enterToDate(colArray[6]);
		if (!(configFileReader.getValue("USERID")).equalsIgnoreCase("ATADMIN")) {
			subscriptionPage.selectProRate(configFileReader.getValue(colArray[7]));
			subscriptionPage.selectCollectionMethod(configFileReader.getValue(colArray[8]));
			Thread.sleep(2000);
		}
		subscriptionPage.clickSaveBtn();
		Wait.untilPageLoadComplete(driver);
		subscriptionPage.statusMsg();
		homePage.navigateToSubscription("View");
		subscriptionPage.viewSubscription(colArray);
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 13,enabled=false)
	public void TC13_BNP_Define_package() throws Exception {
		homePage.navigateTo_BPNPP_PackageDefinition_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		packagedefinition = new BNPP_Package_Definition_Page(driver);
		packagedefinition.definePakageCode("TC_ID='TC01'");
		packagedefinition.definePakageChagecode("TC_ID='TC01' and Sr_No='1'");
		packagedefinition.definePakageChagecode("TC_ID='TC01' and Sr_No='2'");
		packagedefinition.savePackageDefinition();
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\"); 	
	}

	@Test(priority = 14,enabled=false)
	public void TC14_AttachPackageToAccount() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC14'");
		Thread.sleep(1000);
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.clickPackageDefinition();
				Wait.untilPageLoadComplete(driver);
				clientAccountPage.setPackageBundleCode(colArray[6]);
				clientAccountPage.setPackageFromDate(colArray[7]);
				clientAccountPage.setPackageToDate(colArray[8]);
				clientAccountPage.clickPackageApplybtn2ndscreen();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 19)
	public void TC1_DebitOfficerAdjustment_Function() throws Exception {
		homePage.navigateToBNPP_OfficerAdjustmentsDebit_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		AdjustmentsDebit = new BNPP_OfficerAdjustmentsDebit_Page(driver);
		AdjustmentsDebit.ckeckOfficerAdjustmentsDebitLabelDisplayed();
		AdjustmentsDebit.EnterIDForDebitOfficerAdjustment("TC_ID='TC01'");
		AdjustmentsDebit.ckeckAdjustmentDetailsLabelDisplayed();
		// AdjustmentsDebit.AddButton().click();
		AdjustmentsDebit.EnterAdjustmentdetails("TC_ID='TC01'");
		AdjustmentsDebit.SaveButton().click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 21)
	public void TC21_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.CreateManualTransactionEntry("TC_ID='TC01'");
		// manualBillableEvents.AddButton().click();
		// Wait.untilPageLoadComplete(driver);
		// manualBillableEvents.CreateManualTransactionEntry();
		// manualBillableEvents.AddButton().click();
		// Wait.untilPageLoadComplete(driver);
		// manualBillableEvents.CreateManualTransactionEntry();
		manualBillableEvents.SaveButton().click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
		// manualBillableEvents.CheckManualTransactionEntrySuccessful();
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 54)
	public void TC54_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		homePage.navigateToBNPP_ManualBillableEvents_Page("view");
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.FilterManualTransactionEntry("TC_ID='TC02'");
		manualBillableEvents.CheckManualTransactionEntryView("TC_ID='TC02'");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 57)
	public void TC57_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		Wait.untilPageLoadComplete(driver);
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.CreateManualTransactionEntry("TC_ID='TC01'");
		// manualBillableEvents.AddButton().click();
		// Wait.untilPageLoadComplete(driver);
		// manualBillableEvents.CreateManualTransactionEntry();
		// manualBillableEvents.AddButton().click();
		// Wait.untilPageLoadComplete(driver);
		// manualBillableEvents.CreateManualTransactionEntry();
		manualBillableEvents.SaveButton().click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
		// manualBillableEvents.CheckManualTransactionEntrySuccessful();
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 58)
	public void TC58_AccountMarkedForClosure() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC58'");
		Thread.sleep(1000);
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.selectAccountUpdMFC("Yes");
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();

			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 59)
	public void TC59_WaiveAccount() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC59'");
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.selectAccountUpdWaiveBill("Yes");
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(priority = 60)
	public void TC60_BookingCancellation_Function() throws Exception {
		homePage.navigateTo_BNPP_Booking_Cancellation_Page();
		Wait.untilPageLoadComplete(driver);
		bookingcancel = new BNPP_BookingCancellation_Page(driver);
		bookingcancel.validateCreationLabelDisplayed();
		bookingcancel.validate_booking_cancelation("TC_ID='TC01'");
		Screenshot.takeSnapShot(driver, "BNPP_BNPNBE_MAT_001_Test\\");
	}

	@Test(groups = { "TEST","DB", "REG_ETOE" })

	public void TC_1_BNP_Update_application_date_Test() throws Exception
	{
		dataBaseConnection = new DataBaseConnection();
		dataBaseConnection.updateDbDate("TC_ID='TC01'");
		}
	
	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
}
