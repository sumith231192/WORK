package test;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pageObject.BNPP_ShellJobs;

import utility.ConfigFileReader;
import utility.ExcelUtils;

public class BNPP_ShellJobs_Test {
	ConfigFileReader configFileReader;
	BNPP_ShellJobs sj = new BNPP_ShellJobs();

	@BeforeClass(groups = { "RUN", "REG_ETOE" })
	public void initWebDriver() throws Exception {
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC22_validateCreateNewTransaction1() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC22'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC23_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC23'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC24_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC24'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC25_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC25'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC27_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC27'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC32_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC32'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC37_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC37'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC38_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC38'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC39_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC39'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC41_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC41'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC43_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC43'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC54_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC54'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC55_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC55'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC56_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC56'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC61_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC61'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC63_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC63'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC65_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC65'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC69_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC69'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC83_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC83'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC89_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC89'");
		sj.getUnixConnection(colarray[0]);
	}

	@Test(groups = { "RUN", "REG_ETOE" })
	public void TC91_validateCreateNewTransaction() throws Exception {

		String[] colarray = sj.getTestData("TC_ID='TC91'");
		sj.getUnixConnection(colarray[0]);
	}

}
