package test;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;

import helper.AssertionHelper;
import helper.Screenshot;
import pageObject.BNPP_Client_Account_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_Subscription_Page;

import org.testng.annotations.Test;

import utility.ConfigFileReader;

import utility.Wait;
import utility.WebDriverManager;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;

public class BNPP_Client_Account_Test {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Client_Account_Page clientAccountPage;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;

	@BeforeClass
	public void initWebDriver() throws ClassNotFoundException, SQLException {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();

		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
	}

	@Test
	public void TC03_ClientAddressUpdate() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC08'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.clickClientAddress();
				Wait.untilPageLoadComplete(driver);
				boolean clientAddressTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
				if (clientAddressTitleDisplayed) {
					clientAccountPage.checkClientAddressHeader();
					 clientAccountPage.verfiyClientAddress();
					 clientAccountPage.clickApplyButton();
				} else
					throw new RuntimeException("Client Account Page-Client Address Detail Page is not loaded");

			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
	}

	@Test(priority = 2)
	public void TC04_attachPriceListUI() throws FilloException, Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC07'");
		clientAccountPage.clickclientMaintenance();
		Wait.untilPageLoadComplete(driver);
		clientAccountPage.checkClientMaintenancePageHeader();
		clientAccountPage.enterMaintenanceClientID(colArray[0]);
		//clientAccountPage.enterClientMaintenanceDate(colArray[7]);
		clientAccountPage.selectClientMaintenanceDropdown();
		clientAccountPage.enterMaintenanceType(colArray[10]);
		clientAccountPage.clickClientMaintenanceDetails();
		clientAccountPage.enterClientMaintenancePriceList(colArray[11]);
		clientAccountPage.clickClientMaintenanceOKButton();
		clientAccountPage.clickClientMaintenanceSaveButton();
		clientAccountPage.checkClientAcctUpdateStatus();
	}
	@Test(priority = 2, enabled = false)
	public void TC08_SetInvoiceLevel() throws FilloException, Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC01'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		Thread.sleep(2000);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.setClientUpdInvoiceLvl(colArray[2]);
				clientAccountPage.clickSaveButton();
				Wait.untilPageLoadComplete(driver);
				clientAccountPage.checkClientAcctUpdateStatus();
			} else {
				System.out.println(pageTitleDisplayed);
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
			}
		} else
			throw new RuntimeException("Client Account Page is not loaded");
	}

	@Test(priority = 3, enabled = false)
	public void TC09_SetInvoiceTemplet() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC02'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.setInvoiceTemplet(colArray[4]);
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
		} else
			new RuntimeException("Client Account Page is not loaded");
	}

	@Test(priority = 4, enabled = false)
	public void TC10_SetInvoiceLanguageAndDistributionChannel() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC02'");
		clientAccountPage.clickUpdateClient();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterClientBgID(colArray[0]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkClientUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.setInvoiceLanguage(colArray[3]);
				clientAccountPage.setInvoiceDisributionChannel(colArray[5]);
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();

			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
		} else
			throw new RuntimeException("Client Account Page is not loaded");
	}

	@Test(priority = 5)
	public void TC14_AttachPackageToAccount() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC06'");
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.clickPackageDefinition();
				Wait.untilPageLoadComplete(driver);
				clientAccountPage.setPackageBundleCode(colArray[6]);
				clientAccountPage.setPackageFromDate(colArray[7]);
				clientAccountPage.setPackageToDate(colArray[8]);
				clientAccountPage.clickPackageApplybtn2ndscreen();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
	}

	@Test(priority = 6, enabled = false)
	public void TC58_AccountMarkedForClosure() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC02'");
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.selectAccountUpdMFC("Yes");
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();

			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
	}

	@Test(priority = 7, enabled = false)
	public void TC59_WaiveAccount() throws Exception {
		homePage.navigateToClientAccountHome();
		clientAccountPage = new BNPP_Client_Account_Page(driver);
		String[] colArray = clientAccountPage.getTestData("TC_ID='TC02'");
		clientAccountPage.clickUpdateAccount();
		Wait.untilPageLoadComplete(driver);
		boolean pageClientAccountTitleDisplayed = clientAccountPage.checkClientAccountPageHeader();
		if (pageClientAccountTitleDisplayed) {
			clientAccountPage.enterAccountId(colArray[1]);
			clientAccountPage.clickGoBtn();
			Wait.untilPageLoadComplete(driver);
			boolean pageTitleDisplayed = clientAccountPage.checkAccountUpdateHeader();
			if (pageTitleDisplayed) {
				clientAccountPage.selectAccountUpdWaiveBill("Yes");
				clientAccountPage.clickSaveButton();
				clientAccountPage.checkClientAcctUpdateStatus();
			} else
				throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");

		} else
			throw new RuntimeException("Client Account Page is not loaded");
	}

	@BeforeMethod
	public void BeforePage() throws Exception {

	}

	@DataProvider

	@AfterMethod
	public void afterMethod() {
		clientAccountPage.clickClientmenuButton();
	}

	@AfterClass
	public void AfterClass() {
		 driver.manage().deleteAllCookies();
		 driver.close();
		 driver.quit();
	}

}
