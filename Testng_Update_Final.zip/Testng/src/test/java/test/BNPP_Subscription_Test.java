package test;

import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;

import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;

import static org.testng.Assert.assertEquals;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import helper.DropDownHelper;
import pageObject.BNPP_Client_Account_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_Subscription_Page;
import utility.ConfigFileReader;
import utility.Wait;
import utility.WebDriverManager;
import utility.ExcelUtils;
import helper.AssertionHelper;
/**
 * This class is a page object class used to identify elements on Subscription page.
 *
 * @version 1 10 May 2019
 * @author HCL
 */

public class BNPP_Subscription_Test {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Subscription_Page subscriptionPage;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	ExcelUtils excelQuery;
	AssertionHelper assertionHelper ;
	
	@BeforeClass
	public void initWebDriver() throws ClassNotFoundException, SQLException {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		excelQuery = new ExcelUtils();
		assertionHelper= new AssertionHelper();
		
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		
	}
	@BeforeMethod
	public void BeforePage() throws ClassNotFoundException, SQLException {
		homePage = new BNPP_Home_Page(driver);
		
	}
/*
  @Test(priority=1,enabled=false )
  public void TC11_CreateSubscriptionArrear() throws Exception {
	  homePage.navigateToSubscription("Create");
	  subscriptionPage = new BNPP_Subscription_Page(driver);
	  String[] colArray = subscriptionPage.getTestData("TC_ID='TC01'");
	  subscriptionPage.enterClientBgID(colArray[0]);
	  subscriptionPage.enterAccount(colArray[1]);
	  subscriptionPage.enterChargeCode(colArray[2]);
	  Thread.sleep(1000);
	  boolean checkChargeCode=subscriptionPage.checkChargecode();
	  if (!checkChargeCode)
		  subscriptionPage.enterChargeCode(colArray[2]); 
	  subscriptionPage.enterVolume(colArray[3]);
	  subscriptionPage.selectPricingFrequency(colArray[4]);
	  subscriptionPage.enterFromDate(colArray[5]);
	  subscriptionPage.enterToDate(colArray[6]);
	  if (!(configFileReader.getValue("USERID")).equalsIgnoreCase("ATADMIN")) {
	  subscriptionPage.selectProRate(configFileReader.getValue("SubscriptionProRate"));
	  subscriptionPage.selectCollectionMethod(configFileReader.getValue("SubscriptionCollectionMethod1"));
	  Thread.sleep(2000);}
	  subscriptionPage.clickSaveBtn();
	  Wait.untilPageLoadComplete(driver);
	  subscriptionPage.statusMsg();
  }
  
  @Test(priority=2)
  public void TC11_ViewSubscriptionArrear() throws Exception {
	  subscriptionPage = new BNPP_Subscription_Page(driver);
	  String[] colArray = subscriptionPage.getTestData("TC_ID='TC01'");
	  boolean checkSubscriptionViewPage=subscriptionPage.checkSubscriptionViewPage();
	  if (checkSubscriptionViewPage) {
		  subscriptionPage.clickfilter();
		  for (int i=0;i<=6;i++) {
			  subscriptionPage.selectFilterDropdown(i);
			  subscriptionPage.setFilterDropdownValue(colArray[i]);
			  subscriptionPage.clickfilterAdd();
		  }
		  subscriptionPage.clickfilterSearch();
		  boolean subscriptionRecordPresent=subscriptionPage.checkFilterResult();
		  if (subscriptionRecordPresent) {
				  subscriptionPage.clickfilterDetail();
				  subscriptionPage.validateSubscriptionResult(colArray);
		  } 
		  else throw new RuntimeException("Subscription view Filtered Table is not loaded");
	  }
	  else throw new RuntimeException("Subscription view Page is not loaded");
  }
  
  
  @Test(priority=3)
  public void TC12_Subscriptiondvanced() throws Exception {
	  homePage.navigateToSubscription("Create");
	  subscriptionPage = new BNPP_Subscription_Page(driver);
	  String[] colArray = subscriptionPage.getTestData("TC_ID='TC01'");
	  subscriptionPage.enterClientBgID(colArray[0]);
	  subscriptionPage.enterAccount(colArray[1]);
	  subscriptionPage.enterChargeCode(colArray[2]);
	  Thread.sleep(1000);
	  boolean checkChargeCode=subscriptionPage.checkChargecode();
	  if (!checkChargeCode)
		  subscriptionPage.enterChargeCode(colArray[2]); 
	  subscriptionPage.enterVolume(colArray[3]);
	  subscriptionPage.selectPricingFrequency(colArray[4]);
	  subscriptionPage.enterFromDate(colArray[5]);
	  subscriptionPage.enterToDate(colArray[6]);
	  if (!(configFileReader.getValue("USERID")).equalsIgnoreCase("ATADMIN")) {
	  subscriptionPage.selectProRate(configFileReader.getValue(colArray[7]));
	  subscriptionPage.selectCollectionMethod(configFileReader.getValue(colArray[7]));
	  Thread.sleep(2000);}
	  subscriptionPage.clickSaveBtn();
	  Wait.untilPageLoadComplete(driver);
	  subscriptionPage.statusMsg();
  }
  
  @Test(priority=4)
  public void TC12_ViewSubscriptionArrear() throws Exception {
	//to change this portion according to the Data file being created  
	  homePage.navigateToSubscription("View");
	  subscriptionPage = new BNPP_Subscription_Page(driver);
	  String[] colArray = subscriptionPage.getTestData("TC_ID='TC01'");
	  boolean checkSubscriptionViewPage=subscriptionPage.checkSubscriptionViewPage();
	  if (checkSubscriptionViewPage) {
		  subscriptionPage.clickfilter();
		  for (int i=0;i<=6;i++) {
			  subscriptionPage.selectFilterDropdown(i);
			  subscriptionPage.setFilterDropdownValue(colArray[i]);
			  subscriptionPage.clickfilterAdd();
		  }
		  subscriptionPage.clickfilterSearch();
		  boolean subscriptionRecordPresent=subscriptionPage.checkFilterResult();
		  if (subscriptionRecordPresent) {
				  subscriptionPage.clickfilterDetail();
				  subscriptionPage.validateSubscriptionResult(colArray);
		  } 
		  else throw new RuntimeException("Subscription view Filtered Table is not loaded");
	  }
	  else throw new RuntimeException("Subscription view Page is not loaded");
  }
  
 // @AfterMethod
  //public void afterMethod() {
	//  homePage.navigateToSubscription("View");
 // }
  
@AfterClass
  public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
		driver.quit();
  }*/
}
