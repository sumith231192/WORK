package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pageObject.BNPP_ClientAccountPricelistDetails_Page;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_ClientAccountPricelistDetails_Test {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ClientAccountPricelistDetails_Page priceListDetails;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@BeforeMethod(groups = { "REG_ETOE" })
	public void BeforePage() throws Exception {
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		homePage.navigateToBNPP_ClientAccountPricelistDetailsATADMIN_Page("CREATE");
		priceListDetails = new BNPP_ClientAccountPricelistDetails_Page(driver);
		}

	@Test(groups = { "REG_ETOE" })
	public void TC1_ClientAccountPricelistDetails_Function() throws Exception {
		priceListDetails.ckeckClientAccountPricelistDetailsLabelDisplayed();
		priceListDetails.FilterForPricelistDetails("TC_ID='TC01'");
		priceListDetails.ClientAccountPricelistDetailsCreationORUpdate("TC_ID='TC01'");
		priceListDetails.ckeckClientAccountPricelistDetailsLabelDisplayed();
	}
	
	/*@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.quit();
	}*/
}
