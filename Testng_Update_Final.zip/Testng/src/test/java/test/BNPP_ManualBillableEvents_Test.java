package test;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import helper.Screenshot;
import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import pageObject.BNPP_ManualBillableEvents_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_ManualBillableEvents_Test {
	ConfigFileReader configFileReader;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Login_Page loginPage;
	BNPP_Environment_Page envPage;
	BNPP_Home_Page homePage;
	BNPP_ManualBillableEvents_Page manualBillableEvents;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		homePage = new BNPP_Home_Page(driver);
		homePage.navigateToBNPP_ManualBillableEvents_Page("CREATE");
		manualBillableEvents = new BNPP_ManualBillableEvents_Page(driver);
		Wait.untilPageLoadComplete(driver);
	}

	@Test(priority=1)
	public void TC1_ManualTransactionEntry_Function() throws Exception {
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.CreateManualTransactionEntry("TC_ID='TC01'");
		//manualBillableEvents.AddButton().click();
		//Wait.untilPageLoadComplete(driver);
		//manualBillableEvents.CreateManualTransactionEntry();
		//manualBillableEvents.AddButton().click(); 
		//Wait.untilPageLoadComplete(driver);
		//manualBillableEvents.CreateManualTransactionEntry();
		manualBillableEvents.SaveButton().click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
		//manualBillableEvents.CheckManualTransactionEntrySuccessful();
	}

	@Test(priority=2)
	public void TC2_ManualTransactionEntry_Function() throws Exception {
		homePage.navigateToBNPP_ManualBillableEvents_Page("view");
		manualBillableEvents.ckeckManualBillableEventsLabelDisplayed();
		manualBillableEvents.FilterManualTransactionEntry("TC_ID='TC02'");
		manualBillableEvents.CheckManualTransactionEntryView("TC_ID='TC02'");
	}

	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}

}
