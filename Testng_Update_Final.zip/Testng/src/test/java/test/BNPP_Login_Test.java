package test;

import java.io.IOException;
import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import pageObject.BNPP_Environment_Page;
import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import utility.ConfigFileReader;
import utility.CsvReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_Login_Test{

ConfigFileReader configFileReader;
WebDriverManager webDriverManager;	
WebDriver driver;
BNPP_Environment_Page envPage;
BNPP_Login_Page loginPage ;
BNPP_Home_Page homePage ;
DataBaseConnection dBconnection ;
DataBaseReader dataBaseReader;
CsvReader csvReader = new CsvReader();


@BeforeClass(groups = { "REG_ETOE" })
public void initWebDriver() throws ClassNotFoundException, SQLException {

	webDriverManager = new WebDriverManager();
	driver = webDriverManager.getDriver();
	configFileReader = new ConfigFileReader();
}
@BeforeMethod(groups = { "REG_ETOE" })
public void BeforePage()
{
	loginPage = new BNPP_Login_Page(driver);
	loginPage.naviageToLoginXlerate();
	Wait.untilPageLoadComplete(driver);
}



@Test(groups = { "REG_ETOE" })
public void TC2_LoginFunction() throws ClassNotFoundException, SQLException, IOException {
	
	loginPage.navigateTo_BNPP_Environment_Page();
	Wait.untilPageLoadComplete(driver);
	String Test = csvReader.get_Record_Data("OutPutCSV","201602ES00000004", "NITZ VENEZUELA BV");
	
	System.out.println(Test);

}

@AfterClass(groups = { "REG_ETOE" })
public void AfterClass()
{
	driver.close();
}

}