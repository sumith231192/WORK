package test;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import helper.Screenshot;
import pageObject.BNPP_BookingCancellation_Page;
import pageObject.BNPP_Environment_Page;

import pageObject.BNPP_Home_Page;
import pageObject.BNPP_Login_Page;
import utility.ConfigFileReader;
import utility.DataBaseConnection;
import utility.DataBaseReader;
import utility.ExcelUtils;
import utility.Wait;
import utility.WebDriverManager;

public class BNPP_BookingCancellation_Test {

	ConfigFileReader configFileReader;
	BNPP_BookingCancellation_Page bc;
	WebDriverManager webDriverManager;
	WebDriver driver;
	BNPP_Environment_Page envPage;
	BNPP_Login_Page loginPage;
	BNPP_Home_Page homePage;
	String title_Login;
	DataBaseConnection dBconnection;
	DataBaseReader dataBaseReader;

	@BeforeClass(groups = { "REG_ETOE" })
	public void initWebDriver() throws Exception {

		webDriverManager = new WebDriverManager();
		driver = webDriverManager.getDriver();
		configFileReader = new ConfigFileReader();
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
	}

	@BeforeMethod(groups = { "REG_ETOE" })
	public void BeforePage() throws ClassNotFoundException, SQLException {
		loginPage = new BNPP_Login_Page(driver);
		loginPage.naviageToLoginXlerate();
		Wait.untilPageLoadComplete(driver);
		loginPage.navigateTo_BNPP_Environment_Page();
		Wait.untilPageLoadComplete(driver);
		envPage = new BNPP_Environment_Page(driver);
		envPage.navigateToBNPP_Home_Page();
		Wait.untilPageLoadComplete(driver);
		homePage = new BNPP_Home_Page(driver);
		homePage.navigateTo_BNPP_Booking_Cancellation_Page();
		Wait.untilPageLoadComplete(driver);
	}

	@Test(groups = {"REG_ETOE" })
	public void TC1_validateCreateNewTransaction() throws Exception {
		bc = new BNPP_BookingCancellation_Page(driver);
		bc.validateCreationLabelDisplayed();
		bc.validate_booking_cancelation("TC_ID='TC01'");
		Screenshot.takeSnapShot(driver, "BookingCancellation\\");

	}
	@AfterClass(groups = { "REG_ETOE" })
	public void AfterClass() {
		driver.manage().deleteAllCookies();
		driver.close();
	}
	
}
