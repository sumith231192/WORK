package helper;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.Date;

import org.apache.commons.io.FileUtils;

import utility.ConfigFileReader;

public class FilePathReader {
	ConfigFileReader configFileReader = new ConfigFileReader();
	boolean FileCheck = false;

	public String getFilePathMSExcelXLS(String FileName) {
		File folder = new File("./src/main/resources/TestData");
		File[] listOfFiles = folder.listFiles();
		String filname = null;
		FileName = FileName + ".xls";
		
		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile() && listOfFiles[i].getName().equals(FileName)) {
				System.out.println("File " + listOfFiles[i].getName());
				filname = listOfFiles[i].getName();
				FileCheck = true;
			}

			else {
				System.out.println("File Not Founf Yet...");
			
			}
		}
		
		if (FileCheck = true)
		{
			final String dir = System.getProperty("user.dir");
			FileName = dir+"\\src\\main\\resources\\TestData\\"+FileName;
//			System.out.println("########################################"+FileName);
			return FileName;
		}
			
		else
		{
			System.out.println("File " + FileName + "is not in the directory. So retruning Null");

			return null;
		}
	}
	
	
	public String makeAcopyRenameTheFile(String FileName)
	{
		String TimestampFileName = getCurrentTimeFileName();
		TimestampFileName = TimestampFileName+".xls";
		String sourceFile = getFilePathMSExcelXLS(FileName);
		String desFile = getFilePathMSExcelXLS(FileName).replace(".xls", TimestampFileName);
		desFile = desFile.replace("\\TestData\\", "\\TestData\\Temp_");
		 
		 
		 
		File sourceExcel = new File(sourceFile);
		File dstExcel = new File(desFile);
		System.out.println("Dest:"+desFile);
		System.out.println("Source:"+sourceFile);
		try {

		    FileUtils.copyFile(sourceExcel, dstExcel);

		} catch (IOException e) {

		    e.printStackTrace();
		}
		
		return desFile;
	}
	
	public String getCurrentTimeFileName()
	{
		Date date= new Date();
		 
		 long time = date.getTime();
		     System.out.println("Time in Milliseconds: " + time);
		 
		 Timestamp ts = new Timestamp(time);
		 System.out.println("Current Time Stamp: " + ts);
		 String TimeFilNam= ts.toString().replace("-", "_").replace(":", "").replace(" ", "_").replace(".", "");
		return TimeFilNam;
	}
	
	public void deletTempFileCreated(String Filename)
	{
		File folder = new File("./src/main/resources/TestData/");
				 File[] files = folder.listFiles( new FilenameFilter() {
				    @Override
				    public boolean accept( final File dir,
				                           final String name ) {
				        return name.matches( "Temp_"+Filename+".*\\.xls" );
				    }
				} );
				for ( final File file : files ) {
//					file.deleteOnExit();
				    if ( !file.delete() ) {
				        System.err.println( "Can't remove " + file.getAbsolutePath() );
				    }
				}
	}

}
