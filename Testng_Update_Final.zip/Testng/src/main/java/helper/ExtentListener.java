package helper;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import utility.Log;

public class ExtentListener implements ITestListener{
        
	public static ExtentReports extent;
	public static ExtentTest test;

	public void onFinish(ITestContext arg0) {
       // extent.flush();
        Log.info(arg0.getName()+" Test Finished..");
	}

	public void onStart(ITestContext arg0) {
		//extent = ExtentManager.getInstance();
		//test = extent.createTest(arg0.getName());
		//test = extent.createTest(arg0.getCurrentXmlTest().getName());
		Log.info(arg0.getCurrentXmlTest().getName()+" Class Started..");
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailure(ITestResult arg0) {
		//test.Log(Status.FAIL, arg0.getThrowable());
		Log.error(arg0.getMethod().getMethodName()+" Test Failed.."+arg0.getThrowable());
	}

	public void onTestSkipped(ITestResult arg0) {
		//test.Log(Status.SKIP, arg0.getThrowable());
		Log.warn(arg0.getMethod().getMethodName()+" Test Skipped.."+arg0.getThrowable());
	}

	public void onTestStart(ITestResult arg0) {
		//test.Log(Status.INFO, arg0.getName()+" started..");
		Log.info(arg0.getMethod().getMethodName()+" Test Started..");
	}

	public void onTestSuccess(ITestResult arg0) {
		//test.Log(Status.INFO, arg0.getName()+" Passed..");
		Log.info(arg0.getMethod().getMethodName()+" Test Passed..");
	}

}
