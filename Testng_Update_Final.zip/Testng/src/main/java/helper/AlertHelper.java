package helper;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;

import utility.Log;

public class AlertHelper {

	private WebDriver driver;
	
	
	public AlertHelper(WebDriver driver){
		this.driver = driver;
		Log.info("AlertHelper object is craeted..");
	}
	
	public Alert getAlert(){
		Log.info("alert test: "+driver.switchTo().alert().getText());
		return driver.switchTo().alert();
	}
	
	public void acceptAlert(){
		getAlert().accept();
		Log.info("accept Alert is done...");
	}
	
	public void dismissAlert(){
		getAlert().dismiss();
		Log.info("dismiss Alert is done...");
	}
	
	public String getAlertText(){
		String text = getAlert().getText();
		Log.info("alert text: "+text);
		return text;
	}
	
	public boolean isAlertPresent(){
		try{
			driver.switchTo().alert();
			Log.info("alert is present");
			return true;
		}
		catch(NoAlertPresentException e){
			Log.info(e.getCause());
			return false;
		}
	}
	
	public void acceptAlertIfPresent(){
		if(isAlertPresent()){
			acceptAlert();
		}
		else{
			Log.info("Alert is not present..");
		}
	}
	
	public void dismissAlertIfPresent(){
		if(isAlertPresent()){
			dismissAlert();
		}
		else{
			Log.info("Alert is not present..");
		}
	}
	
	public void acceptPrompt(String text){
		if(isAlertPresent()){
			Alert alert = getAlert();
			alert.sendKeys(text);
			alert.accept();
			Log.info("alert text: "+text);
		}
	}
}
