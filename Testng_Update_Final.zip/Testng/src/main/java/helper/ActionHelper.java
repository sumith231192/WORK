package helper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import utility.Log;

public class ActionHelper {
	
private WebDriver driver;
	
	
	public ActionHelper(WebDriver driver){
		this.driver = driver;
		Log.info("AlertHelper object is craeted..");
	}
	
	
	Actions act;
	 
	 public void dragElementTo(WebElement element){
		 act = new Actions(driver);
		 act.clickAndHold(element).dragAndDropBy(element, 0, 1000);
		}	
	 
	 public void doubleClick(WebElement element){
		 act = new Actions(driver);
		 act.doubleClick(element);
		}	
	 
}
