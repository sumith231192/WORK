package helper;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utility.Log;
/**
 * 
 *
 *
 */
public class VerificationHelper {

	private WebDriver driver;
		
	public VerificationHelper(WebDriver driver){
		this.driver = driver;
	}
	
	public boolean isDisplayed(WebElement element){
		try{
			element.isDisplayed();
			Log.info("element is Displayed.."+element.getText());
			return true;
		}
		catch(Exception e){
			Log.error("element is not Displayed..", e.getCause());
			return false;
		}
	}
	
	public boolean isNotDisplayed(WebElement element){
		try{
			element.isDisplayed();
			Log.info("element is present.."+element.getText());
			return false;
		}
		catch(Exception e){
			Log.error("element is not present..");
			return true;
		}
	}
	
	public String readValueFromElement(WebElement element){
		if(null == element){
			Log.info("WebElement is null..");
			return null;
		}
		boolean status = isDisplayed(element);
		if(status){
			Log.info("element text is .."+element.getText());
			return element.getText();
		}
		else{
			return null;
		}
	}
	public String getText(WebElement element){
		if(null == element){
			Log.info("WebElement is null..");
			return null;
		}
		boolean status = isDisplayed(element);
		if(status){
			Log.info("element text is .."+element.getText());
			return element.getText();
		}
		else{
			return null;
		}
	}
	
	public String getTitle(){
		Log.info("page title is: "+driver.getTitle());
		return driver.getTitle();
	}
	
	
}
