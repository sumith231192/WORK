package utility;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

public class DataBaseReader {
	
	private Properties properties;
	private final String DataBaseQuery = "./src/main/resources/DataBaseQuery/DBquery.properties";
	
	public DataBaseReader(){
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(DataBaseQuery));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + DataBaseQuery);
		}		
	}
	
	
	public String getUserID()
	{
		String USERID = properties.getProperty("DB_USERID").trim();
		if(USERID!= null) return USERID;
		else throw new RuntimeException("USER ID is Blank ");		
	}
	
	public String getPassword()
	{
		String PASSWORD = properties.getProperty("DB_PASSWORD").trim();
		if(PASSWORD!= null) return PASSWORD;
		else throw new RuntimeException("PASSWORD is Blank ");		
	}
	
	public String getDBurl()
	{
		String DBurl = properties.getProperty("DB_URL").trim();
		if(DBurl!= null) return DBurl;
		else throw new RuntimeException("DB URL is Blank ");		
	}
	
	public String getTestQuery()
	{
		String testQuery = properties.getProperty("TEST_QUERY").trim();		
		if(testQuery!= null) return testQuery;
		else throw new RuntimeException("Query is Blank ");		
	}
	
	public String getDBUpdateQuery()
	{
		String testQuery = properties.getProperty("UPDATE_APP_DATE").trim();
		if(testQuery!= null) return testQuery;
		else throw new RuntimeException("Query is Blank ");		
	}
	
	public String getCheckDBDateQuery()
	{
		String testQuery = properties.getProperty("CHECK_APP_DATE").trim();
		if(testQuery!= null) return testQuery;
		else throw new RuntimeException("Query is Blank ");		
	}
	
	public String setSecutityforNOADM()
	{
		String testQuery = properties.getProperty("SEC_SET_NOADM").trim();
		if(testQuery!= null) return testQuery;
		else throw new RuntimeException("Query is Blank ");		
	}
	public String getStafId()
	{
		String testQuery = properties.getProperty("STAFF_ID").trim();
		if(testQuery!= null) return testQuery;
		else throw new RuntimeException("STAFF_ID is Blank ");		
	}
	
	public HashMap<String, String> getDataBaseRecordRecordDataValuehash()
	{
		
		HashMap<String, String> mymap = new HashMap<String, String>();
		for (String key : properties.stringPropertyNames()) {
		    String value = properties.getProperty(key);
		    mymap.put(key, value);
		}		
		return mymap;		
	}	
}


	
	