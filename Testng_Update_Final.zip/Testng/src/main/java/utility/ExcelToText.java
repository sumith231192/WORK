package utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;

import org.apache.poi.ss.usermodel.Cell;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelToText {

	public Sheet openExcel(String filePath, String fileName, String sheetName) throws IOException {
		Sheet Sheet;
		Workbook wrkBook = null;

		// Create an object of File class to open xlsx file
		File file = new File(filePath + "\\" + fileName);
		// Create an object of FileInputStream class to read excel file

		FileInputStream inputStream = new FileInputStream(file);
		// Find the file extension by splitting file name in substring and getting only
		// extension name

		String fileExtention = fileName.substring(fileName.indexOf("."));

		if (fileExtention.equals(".xlsx")) {
			wrkBook = new XSSFWorkbook(inputStream);
		}
		else {
			System.out.println("The file format is not supported");
			System.out.println(fileExtention);
		}
		// Read sheet inside the workbook by its name
		Sheet = wrkBook.getSheet(sheetName);
		return Sheet;
	}
	// Get the number of rows of an Excel sheet
	public int getNoOfRowsofExcel(Sheet Sheet) {
		int noOfRows = Sheet.getPhysicalNumberOfRows();
		return noOfRows;
	}

	// Get the row data for Feed file
	public String getFeedFileData(Sheet Sheet, int RowNo) {
		Cell Cell;
		Row Row;
		String CellValue = null;
		String RowValue = null;
		System.out.println("In getFeedFileData");
		Row = Sheet.getRow(RowNo);

		Cell = Row.getCell(0);
		final int cellType = Cell.getCellType();
		if (cellType == Cell.CELL_TYPE_STRING) {
			CellValue = Cell.getStringCellValue();
			CellValue = CellValue.replaceAll((" "), "");
			int CellValueLength = CellValue.length();

			if (CellValueLength == 1) {
				int Cellno = Row.getPhysicalNumberOfCells();
				System.out.println("No of cells =" + Cellno);
				String[] strArray1 = new String[Cellno];

				for (int i = 0; i <= Cellno - 1; i++) {
					Cell = Row.getCell(i);
					if (cellType == Cell.CELL_TYPE_STRING) {
						CellValue = Cell.getStringCellValue();

						CellValue = CellValue.trim();

						CellValue = CellValue.replaceAll(("!"), "");
					}
					strArray1[i] = CellValue;
					System.out.println(CellValue);
				}
				RowValue = strArray1[0];
				for (int i = 1; i <= Cellno - 1; i++) {
					if (strArray1[i].equals("end")) {
						break;
					}
					RowValue = RowValue + "|" + strArray1[i];
				}
			}
			else {
				System.out.println("Not required");
				RowValue = null;
			}
		}
		if (RowValue != null) {
			return RowValue;
		} else {
			return null;
		}

	}

	// To Create and write the feed file data in a text file
	public void writeToFile(String msg, String textFileName) {

		String newLine = System.getProperty("line.separator");

		String fileName = System.getProperty("user.dir") + "\\src\\main\\resources\\testData\\" + textFileName;
		System.out.println(fileName);
		PrintWriter printWriter = null;
		File file = new File(fileName);
		try {
			if (!file.exists())
				file.createNewFile();
			printWriter = new PrintWriter(new FileOutputStream(fileName, true));
			printWriter.write(msg);
			printWriter.write(newLine);
		} catch (IOException ioex) {
			ioex.printStackTrace();
		} finally {
			if (printWriter != null) {
				printWriter.flush();
				printWriter.close();
			}
		}
	}
}

