package utility;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {

	private Properties properties = new Properties();
	private final String propertyFilePath = "./src/main/resources/configs/Configeration.properties";

	public ConfigFileReader() {
		BufferedReader reader;
		System.out.println(propertyFilePath);
		try {
			reader = new BufferedReader(new FileReader(propertyFilePath));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + propertyFilePath);
		}
	}

	public String getChromeDriverPath() {
		String driverPath = properties.getProperty("CHROMEDRIVERPATH");
		if (driverPath != null)
			return driverPath;
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}

	public String getIEDriverPath() {
		String driverPath = properties.getProperty("IEDRIVERPATH");
		if (driverPath != null)
			return driverPath;
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}

	public long getImplicitlyWait() {
		String implicitlyWait = properties.getProperty("IMPLICITLYWAIT");
		if (implicitlyWait != null)
			return Long.parseLong(implicitlyWait);
		else
			throw new RuntimeException("implicitlyWait not specified in the Configuration.properties file.");
	}

	public long getWebElemntWaitTime() {
		String ElemntWaitTime = properties.getProperty("WAITFORELEMENT");
		if (ElemntWaitTime != null)
			return Long.parseLong(ElemntWaitTime);
		else
			throw new RuntimeException("implicitlyWait not specified in the Configuration.properties file.");
	}

	public String getApplicationUrl() {
		String url = properties.getProperty("URL");
//		System.out.println("%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%"+url);
		if (url != null)
			return url;
		else
			throw new RuntimeException("url not specified in the Configuration.properties file.");
	}

	public String getUserId() {
		String userid = properties.getProperty("USERID");
		if (userid != null)
			return userid;
		else
			throw new RuntimeException("url not specified in the Configuration.properties file.");
	}

	public String getPassword() {
		String password = properties.getProperty("PASSWORD");
		if (password != null)
			return password;
		else
			throw new RuntimeException("url not specified in the Configuration.properties file.");
	}

	public String getBrowser() {
		String browser = properties.getProperty("BROWSER").trim();
		System.out.println("The Current test is going in IE Browser");
		if (browser != null)
			return browser;
		else
			throw new RuntimeException("url not specified in the Configuration.properties file.");
	}

	public String getBranch() {
		String branch = properties.getProperty("BRANCH");
		if (branch != null)
			return branch;
		else
			throw new RuntimeException("Branch is given Blank in the Configuration.properties file.");
	}
	public String getOffice() {
		String office = properties.getProperty("OFFICE");
		if (office != null)
			return office;
		else
			throw new RuntimeException("Office is given Blank in the Configuration.properties file.");
	}

	public String getTestDataTxtFilePath() {
		String FileTxtPath = properties.getProperty("TEXT_FILE_PATH");
		if (FileTxtPath != null)
			return FileTxtPath;
		else
			throw new RuntimeException(
					"Test data TXT file path is not specified in the Configuration.properties file.");
	}

	public String getReportConfigPath() {
		String reportConfigPath = properties.getProperty("REPORTCONFIGPATH");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
	}

	public String getOutputCSVFilePath() {

		String feedFilePath = properties.getProperty("FEED_FILE_PATH");
		if (feedFilePath != null)
			return feedFilePath;
		else
			throw new RuntimeException("Feed File file path is not specified in the Configuration.properties file.");
	}
	public String getValue(String field) {

		String feedFilePath = properties.getProperty(field);
		if (feedFilePath != null)
			return feedFilePath;
		else
			throw new RuntimeException("field is not specified in the Configuration.properties file.");
	}
	
	public String getUnixHostName() {

		String unix_host = properties.getProperty("UNIX_HOST");
		if (unix_host != null)
			return unix_host;
		else
			throw new RuntimeException("UNIX HOST is not specified in the Configuration.properties file.");
	}
	
	public String getUnixUserId() {

		String unix_usr = properties.getProperty("UNIX_USER");
		if (unix_usr != null)
			return unix_usr;
		else
			throw new RuntimeException("UNIX USER is not specified in the Configuration.properties file.");
	}
	public String getUnixPassword() {

		String unix_pas = properties.getProperty("UNIX_PASSWORD");
		if (unix_pas != null)
			return unix_pas;
		else
			throw new RuntimeException("UNIX PASSWORD is not specified in the Configuration.properties file.");
	}

		

}