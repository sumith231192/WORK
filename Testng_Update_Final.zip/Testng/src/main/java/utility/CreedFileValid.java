package utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import org.apache.poi.util.SystemOutLogger;

import helper.AssertionHelper;

public class CreedFileValid {
	ConfigFileReaderForCREED configFileReaderForCREED;

//	AssertionHelper assertionHelper = new AssertionHelper();
//CreedFileValid creedFileValid = new CreedFileValid();
	/*
	 * public static void main (String Arg[]) throws FileNotFoundException { String
	 * Getval = creedFileValid.getPositionsGivenValueCreedFile(
	 * "RDJ_TB_001_ALL_20170110_1_ATCDL", "FEEACC", "36036");
	 * System.out.println(Getval);
	 * 
	 * }
	 */
	public void checkVlaueIsAvalableInFieldname(String Filename, String idetifier, String valuetoFind, String FieldName)
			throws FileNotFoundException {
//	CLT_BRANCH
		ArrayList<String> checkval = getFieldNamesValueCreedFile(Filename, idetifier, valuetoFind);
		if (!checkval.isEmpty() && checkval.contains(FieldName)) {
			AssertionHelper.markPass(
					"PASS: Value is displayed in Postiosns:" + checkval.toString().replace("[", "").replace("]", ""));
		} else {
			AssertionHelper.markFail("FAILED: Given vlue is not displayed");
		}
	}

	public void checkValueIsDisplayedInCreed(String Filename, String idetifier, String valuetoFind)
			throws FileNotFoundException {
		ArrayList<String> checkval = getFieldNamesValueCreedFile(Filename, idetifier, valuetoFind);
		if (!checkval.isEmpty()) {
			AssertionHelper.markPass(
					"PASS: Value is displayed in Postiosns:" + checkval.toString().replace("[", "").replace("]", ""));
		} else {
			AssertionHelper.markFail("FAILED: Given vlue is not displayed");
		}
	}

	public ArrayList<String> getFieldNamesValueCreedFile(String Filename, String idetifier, String valuetoFind)
			throws FileNotFoundException {

		HashMap<String, String> getval = vlaueInTotalCreedWithKey(Filename, idetifier, valuetoFind);

//		System.out.println(getKey(getval, valuetoFind));
		return getKey(getval, valuetoFind);
	}

	public static <K, V> ArrayList<String> getKey(Map<K, V> map, V value) {
		ArrayList<String> blist = new ArrayList<String>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			if (value.equals(entry.getValue())) {
//			return entry.getKey();
//				System.out.println(entry.getKey().toString());
				blist.add(entry.getKey().toString());
			}
		}
		return blist;
	}

	public HashMap<String, String> vlaueInTotalCreedWithKey(String Filename, String idetifier, String valuetoFind)
			throws FileNotFoundException {
		ArrayList<HashMap<String, String>> uu = getArrListForALLCreed(Filename, idetifier);
		int y = 0;
		HashMap<String, String> hasval = new HashMap<>();
		for (HashMap<String, String> lis : uu) {

			String ggg = valuetoFind;
//			
//			ArrayList<String> validatedValue = null;

			for (Map.Entry<String, String> entry : lis.entrySet()) {
				if (ggg.equals(entry.getValue())) {
//					validatedValue.add(entry.getKey());
					hasval.put(entry.getKey(), entry.getValue());
				}
			}
		}
//		System.out.println(hasval.toString());
		return hasval;
	}

	public ArrayList<HashMap<String, String>> getArrListForALLCreed(String Filename, String idetifier)
			throws FileNotFoundException {

		/*
		 * String Filename = "RDJ_TB_001_ALL_20170110_1_ATCDL"; String idetifier =
		 * "RDJ_XCLE201701101542495"
		 */;

		ArrayList<String> FinalArrlist = new ArrayList<String>();
		configFileReaderForCREED = new ConfigFileReaderForCREED();
		HashMap<String, String> finhash = new HashMap<>();
		HashMap<String, String> finalhash = new HashMap<>();
		ArrayList<HashMap<String, String>> AllList = new ArrayList<>();
		FinalArrlist = getFilterReqData(getDataInArrayList(Filename), idetifier);
//		System.out.println(configFileReaderForCREED.getRecordRecordDataValuehash());
		finhash = configFileReaderForCREED.getRecordRecordDataValuehash();

		for (int j = 0; j <= FinalArrlist.size() - 1; j++)

		{
			String b = FinalArrlist.get(j);
//			System.out.println("#################"+b+"#####################");

			String[] bArr = b.split("");
//			System.out.println(bArr.length);
//			System.out.println(finhash.size());
			for (Entry<String, String> v : finhash.entrySet()) {
				String g = "";

//					System.out.println(v.getValue().split("..").toString());
				String cc = v.getValue();

				int starval = Integer.parseInt(cc.replace("..", "##").split("##")[0]) - 1;
				int endval = Integer.parseInt(cc.replace("..", "##").split("##")[1]) - 1;
				if (endval <= bArr.length + 1) {
					for (int i = starval; i <= endval - 1; i++) {
						g = g + bArr[i];
					}
					finalhash.put(v.getKey(), g);
//						System.out.println(finalhash);
					g = "";
				} else if (starval >= bArr.length) {
					AssertionHelper.markFail("The Field Name Count and The File Value Doneot mach .. Please check the File Maping Sheet");
				}
			}
//		System.out.println(finalhash);
			AllList.add(finalhash);

		}
		return AllList;

	}

	@SuppressWarnings("null")
	public ArrayList<String> getFilterReqData(ArrayList<String> itemList, String identifier) {

//			String identifierVal = null;
		ArrayList<String> ArrarrayList;
		ArrayList<String> TargetarrayList = new ArrayList<String>();

//		ArrayList<String> itemList  = creedFileValid.getDataInArrayList("");

		for (String v : itemList) {
			String[] vArr = v.split(" ");
			ArrarrayList = new ArrayList<String>(Arrays.asList(vArr));
			if (ArrarrayList.contains(identifier) && !identifier.equals(null)) {
				TargetarrayList.add(v);
			}

		}
		return TargetarrayList;

	}

	public ArrayList<String> getDataInArrayList(String Filename) throws FileNotFoundException {

//		ArrayList<String> itemList = new ArrayList<>();
		HashMap<Integer, String> map = new HashMap<>();
		Scanner s = new Scanner(new File("./src/main/resources/FeedFiles/" + Filename + ".txt"));
		ArrayList<String> itemList = new ArrayList<String>();
		try (BufferedReader br = new BufferedReader(
				new FileReader("./src/main/resources/FeedFiles/"+Filename+".txt"))) {

			String sCurrentLine;

			while ((sCurrentLine = br.readLine()) != null) {
				itemList.add(sCurrentLine);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
//	        System.out.println(itemList);
		return itemList;

	}

}
