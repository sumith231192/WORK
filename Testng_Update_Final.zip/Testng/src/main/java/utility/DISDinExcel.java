package utility;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DISDinExcel {
	
	//Declaring variables for attributes in DISD
	private int descriptionIndex = 0, positionIndex = 0, sizeIndex = 0;

	public  void getOutBondFileTextData(String uniqueValue , String descriptionField, String descriptionFieldValue ) throws IOException {

		//Defining the Unique Attribute & providing the value for the same 
//		/*String uniqueValue = "2";
		String uniqueDescriptionAttribute = "Sequential number";
		
		//Creating Object for the Main Class DISDinExcel
		DISDinExcel mainObject = new DISDinExcel();

		
		// 1. Splitting the Text File and return as a ArrayList with each value is the string of each row
		
			ArrayList<String> getRowWiseTextFile = mainObject.getTextFileAsRowString();

			// Get the description field name and its value to be verified from the User
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

			/*
			 * Commenting this line. In feature if we need the unique attribute value from the user, then we can add this line
			 * System.out.println("Please enter the Unique Attribute value :   ");
			String uniqueValue = br.readLine();*/
			
			//Description Fi
			/*System.out.println("Please enter the Description field name to be verified :  ");
			String descriptionField = br.readLine();
	
			System.out.println("Please enter the value of the Description field to be verified:   ");
			String descriptionFieldValue = br.readLine();*/

			// System.out.println("The description entered is "+desfield);
			// System.out.println("The value entered is "+desvalue);

		// 2. Excel > Get the position of Unique Description Attribute & Description Field Value that need to be verified. 
		
			/* Get the output as a HashMap where the 
			 * key will be the Attribute Name {descriptionField & uniqueDescriptionAttribute}
			 * Value will be a string with the format {Position Size/Type} - delimited by space
			 */
	
			HashMap<String, String> fieldPositions = mainObject.getPositionfromDISDFile(uniqueDescriptionAttribute,descriptionField);
	
			//System.out.println(fieldPositions);
		
		
		// 3. Iterate the ArrayList and get the Unique value row
		
			/* Get the unique Description Attribute Value from the HashMap
			 * Delimit the String Array and get the Position & Size
			 * Based on the size, traverse the arraylist and check for the substring of unique id and get the row that need to be checked
			 */
			String fieldPositionsValues[] = fieldPositions.get(uniqueDescriptionAttribute).split("/s+");
			int startPosition=Integer.parseInt(fieldPositionsValues[0])-1;
			int endPosition=startPosition+(Integer.parseInt(fieldPositionsValues[1])-1);
			String rowToBeValidated=mainObject.getRowFromArrayList(getRowWiseTextFile,startPosition,endPosition,uniqueValue);
			
			//System.out.println("The Row to be checked based on the unique value : \n"+rowToBeValidated);
		
	    // 4. Excel > Get the position of the Attribute Value
		
			/* Get the Description Attribute Value that need to be checked from the HashMap
			 * Delimit the String Array and get the Position & Size
			 * Based on the size, get the end position
			 */
			fieldPositionsValues = fieldPositions.get(descriptionField).split("/s+");
			startPosition=Integer.parseInt(fieldPositionsValues[0])-1;
			endPosition=startPosition+(Integer.parseInt(fieldPositionsValues[1]));
		
		
		// 5. Navigate to that particular position of the row and check for the value
			
			
			//Based on the position get the attribute vale and check with the descriptionFieldValue and print the result
			String attributeValue=rowToBeValidated.substring(startPosition, endPosition).trim();
			//System.out.println("attributeValue :"+attributeValue);
			//System.out.println("descriptionFieldValue :"+descriptionFieldValue);
			
			if(attributeValue.equals(descriptionFieldValue)) {
				System.out.println("Both the Values are matching");
			}
			else
				System.out.println("Both the values are not matching");
			
			//System.out.println("******************************************************");
		
	}

	//Open the Text file and separate it based on each line and send the output as a ArrayList where each value is a string of one single row
	public ArrayList<String> getTextFileAsRowString() throws FileNotFoundException {
		String value = "";

		File textfile = new File("./src/main/resources/FeedFiles/RDJ_TB_001_ALL_20170110_1_ATCDL.txt");

		// Split the Text File row wise
		ArrayList<String> getRowWiseTextFile = new ArrayList<String>();

		@SuppressWarnings("resource")
		Scanner scan = new Scanner(textfile);
		while (scan.hasNext()) {
			String rowValue = scan.nextLine();
			if (!rowValue.equals(null)) {
				getRowWiseTextFile.add(rowValue);
			}
		}

		return getRowWiseTextFile;
	}

	//Open the Excel File and get the Position & Size/Type values for uniqueDescriptionField & descriptionField and store those in the HashMap and return the HahMap
	private HashMap<String, String> getPositionfromDISDFile(String uniqueDescriptionField, String descriptionField)	throws IOException {
		// TODO Auto-generated method stub
		HashMap<String, String> fieldPositions = new HashMap<String, String>();
		String descriptionPosition = "", uniqueDescriptionPosition = "";
		try {

			FileInputStream file = new FileInputStream(new File("./src/main/resources/FeedFiles/SuntecExcel.xlsx"));

			XSSFWorkbook workbook = new XSSFWorkbook(file);
			FormulaEvaluator objFormulaEvaluator = new XSSFFormulaEvaluator((XSSFWorkbook) workbook);

			XSSFSheet sheet = workbook.getSheetAt(0);

			DataFormatter objDefaultFormat = new DataFormatter();
			Iterator<Row> rowiterator = sheet.iterator();

			for (Row rowValue : sheet) {
				Iterator<Cell> headerIterator = rowValue.cellIterator();
				Cell header = null;
				// table header row
				if (rowValue.getRowNum() == 0) {
					// getting specific column's index

					while (headerIterator.hasNext()) {
						header = headerIterator.next();
						if (header.getStringCellValue().equalsIgnoreCase("Description")) {

							descriptionIndex = header.getColumnIndex();

						}

						else if (header.getStringCellValue().equalsIgnoreCase("Position")) {
							positionIndex = header.getColumnIndex();

						}

						else if (header.getStringCellValue().equalsIgnoreCase("Size/Type")) {
							sizeIndex = header.getColumnIndex();

						}

					}

				}

				else {
					Cell cell = rowValue.getCell(descriptionIndex);
					if (cell.getStringCellValue().equals(descriptionField)) {

						cell = rowValue.getCell(positionIndex);
						objFormulaEvaluator.evaluate(cell);
						descriptionPosition = objDefaultFormat.formatCellValue(cell, objFormulaEvaluator);

						cell = rowValue.getCell(sizeIndex);
						objFormulaEvaluator.evaluate(cell);
						descriptionPosition = descriptionPosition + " "
								+ objDefaultFormat.formatCellValue(cell, objFormulaEvaluator);

					} else if (cell.getStringCellValue().equals(uniqueDescriptionField)) {

						cell = rowValue.getCell(positionIndex);
						objFormulaEvaluator.evaluate(cell);
						uniqueDescriptionPosition = objDefaultFormat.formatCellValue(cell, objFormulaEvaluator);

						cell = rowValue.getCell(sizeIndex);
						objFormulaEvaluator.evaluate(cell);
						uniqueDescriptionPosition = uniqueDescriptionPosition + " "
								+ objDefaultFormat.formatCellValue(cell, objFormulaEvaluator);

					}

				}

			}
			fieldPositions.put(descriptionField, descriptionPosition);
			fieldPositions.put(uniqueDescriptionField, uniqueDescriptionPosition);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		if (fieldPositions.isEmpty()) {
			System.out.println("No such Attributes are present in DISD");
		} else {
			return fieldPositions;
		}

		return null;

	}

	//Based on the uniqueValue check the arraylist and get the row and return it as a String
	private String getRowFromArrayList(ArrayList<String> getRowWiseTextFile,int startPosition, int endPosition,String uniqueValue)
	{
		//System.out.println("startPosition"+startPosition+"endPosition"+endPosition);
		Iterator<String> i=getRowWiseTextFile.iterator();
		String rowValue,attributeValue;
		while(i.hasNext())
		{
			rowValue=(String) i.next();
			//System.out.println(rowValue);
			
			attributeValue=rowValue.substring(startPosition, endPosition).trim();
			//System.out.println("attributeValue :"+attributeValue);
			if(attributeValue.equals(uniqueValue)) {
				return rowValue;
			}
			
			
			
		}
		return null;
	}
}
