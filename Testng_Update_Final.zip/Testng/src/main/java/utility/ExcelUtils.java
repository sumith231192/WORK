package utility;

import java.util.ArrayList;
import java.util.List;

import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

public class ExcelUtils {
	static String path;

	public static void setExcelFile(String Path) throws Exception {
		try {
			ExcelUtils.path = Path;
		} catch (Exception e) {
			throw (e);
		}
	}

	public static String[] getCellData(String RowNum, String ColNum, String TableName, String condition )
			throws Exception {
		List<String> list1 = new ArrayList<String>();

		System.setProperty("ROW", RowNum);
		
		Fillo fillo = new Fillo();
		Connection connection = fillo.getConnection(path);
		String strQuery = "Select " + ColNum + " from " + TableName + " where " + condition;
		Recordset recordset = connection.executeQuery(strQuery);

		String[] colArray = ColNum.split(",");
		int noOfArrayElements = colArray.length;
		while (recordset.next()) {
			for (int i = 0; i <= noOfArrayElements - 1; i++)
				list1.add(recordset.getField(colArray[i]));
		}
		int arrayListLength = list1.size();
		System.out.println(list1);
		String[] colArray1 = new String[arrayListLength];
		for (int index = 0; index <= arrayListLength - 1; index++) {
			colArray1[index] = (String) list1.get(index);

		}
		return colArray1;
	}
}
