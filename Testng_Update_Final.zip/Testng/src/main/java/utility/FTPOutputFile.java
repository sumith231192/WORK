package utility;

import java.io.IOException;

public class FTPOutputFile {

	public static void main(String[] args) {

		ftpOutFile("C:\\Users\\BharatS\\Desktop\\RunFtP.bat /home/bnpeu/manish/mm_Main_Test.txt C:\\Users\\BharatS\\Downloads\\test.txt");
	}

	public static void ftpOutFile(String execCommand) {

		try {
			Process process = Runtime.getRuntime().exec(execCommand);
			System.out.println("Execution complete");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
