package utility;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.opencsv.CSVReader;

public class CsvReader {

	ConfigFileReaderForCSV cofigTwo = new ConfigFileReaderForCSV();
	ConfigFileReader configFileReader = new ConfigFileReader();

	static CsvReader csvReader = new CsvReader();
	String fileName;

	/*public static void main(String arg[]) throws IOException {

		String fileName = csvReader.getFileName("Tommrow");

		System.out.println(fileName);

		List<String[]> listData = csvReader.getDataFromCSV(fileName);
		ArrayList<String> disData = csvReader.distributeDataByType(listData);

		HashMap<String, HashMap<String, ArrayList<String>>> TotalHashData = csvReader.getDataInToHashDataSet(disData);

		ArrayList<String> FileHeader = TotalHashData.get("HeaderData").get("Header");
		System.out.println("File Header :" + csvReader.validateFileHeader(FileHeader));
		ArrayList<String> FileTrailer = TotalHashData.get("FooterData").get("Footer");
		System.out.println("File Trailer :" + csvReader.vlaidateTrailerdata(FileTrailer));
		String idenValue = "201602ES00000004";
		String getval = "NITZ VENEZUELA BV";

		csvReader.validateRecord(TotalHashData, idenValue, getval);

	}*/
	public String  get_Record_Data(String filename ,String idenValue , String getval) throws IOException
	{
		String fileName = csvReader.getFileName(filename);

		System.out.println(fileName);

		List<String[]> listData = csvReader.getDataFromCSV(fileName);
		ArrayList<String> disData = csvReader.distributeDataByType(listData);

		HashMap<String, HashMap<String, ArrayList<String>>> TotalHashData = csvReader.getDataInToHashDataSet(disData);
		/*String idenValue = "201602ES00000004";
		String getval = "NITZ VENEZUELA BV";*/
		System.out.println(TotalHashData);
		System.out.println(TotalHashData.get("FooterData").get("Footer"));
		System.out.println(TotalHashData.get("Data"));
		System.out.println(TotalHashData.get("HeaderData").get("Header"));
		System.out.println(TotalHashData.get("Data").get("201602ES00000004"));
		String result = csvReader.validateRecord(TotalHashData, idenValue, getval);
		return result;

	}
	
	public boolean validate_File_Footer_Data() throws IOException {
		String fileName = csvReader.getFileName("OutPutCSV");

		System.out.println(fileName);

		List<String[]> listData = csvReader.getDataFromCSV(fileName);
		ArrayList<String> disData = csvReader.distributeDataByType(listData);

		HashMap<String, HashMap<String, ArrayList<String>>> TotalHashData = csvReader.getDataInToHashDataSet(disData);

		ArrayList<String> FileTrailer = TotalHashData.get("FooterData").get("Footer");
		boolean validate = vlaidateTrailerdata(FileTrailer);
		return validate;
	}

	public boolean validate_File_Header_Data() throws IOException {
		String fileName = csvReader.getFileName("Tommrow");

		System.out.println(fileName);

		List<String[]> listData = csvReader.getDataFromCSV(fileName);
		ArrayList<String> disData = csvReader.distributeDataByType(listData);

		HashMap<String, HashMap<String, ArrayList<String>>> TotalHashData = csvReader.getDataInToHashDataSet(disData);

		ArrayList<String> FileHeader = TotalHashData.get("HeaderData").get("Header");
		boolean validate = validateFileHeader(FileHeader);

		return validate;

	}

	public String  validateRecord(HashMap<String, HashMap<String, ArrayList<String>>> TotalHashData, String idenValue,
			String getval) {
		ArrayList<String> resultvalue = new ArrayList<String>();
		HashMap<String, ArrayList<String>> RecodesData = new HashMap<String, ArrayList<String>>();
		ArrayList<String> keyRecord = new ArrayList<String>();

		keyRecord = TotalHashData.get("Data").get(idenValue);

		for (String st : keyRecord) {
			String[] srAr = st.replace("|", "##").split("##");
			if (srAr.equals(getval)) {
				if (srAr[0].equals("1")) {
					System.out.println("locatiter is in RecordHeader");
					if (srAr.equals(getval)) {
						int g = Arrays.asList(srAr).indexOf(getval);
						g = g + 1;
						String h = String.valueOf(g) + ".RecordHeader";
						/*System.out.println("Value is in " + g + " Postion");
						System.out.println(cofigTwo.getRecordHeaderValueSize().get(h));*/
						resultvalue.add(cofigTwo.getRecordHeaderValueSize().get(h));
						
					}
				} else if (srAr[0].equals("7")) {
					System.out.println("locatiter is in RecordType 7");
					if (srAr.equals(getval)) {
						int g = Arrays.asList(srAr).indexOf(getval);
						g = g + 1;
						String h = String.valueOf(g) + ".RecordType7";
						/*System.out.println("Value is in " + g + " Postion");
						System.out.println(cofigTwo.getRecordHeaderValueSize().get(h));*/
						resultvalue.add(cofigTwo.getRecordHeaderValueSize().get(h));
					}
				} else if (srAr[0].equals("2")) {
					if (srAr.equals(getval)) {
						int g = Arrays.asList(srAr).indexOf(getval);
						g = g + 1;
						String h = String.valueOf(g) + ".DetailRecord";
						/*System.out.println("Value is in " + g + " Postion");
						System.out.println(cofigTwo.getRecordHeaderValueSize().get(h));*/
						resultvalue.add(cofigTwo.getRecordHeaderValueSize().get(h));
					}
				} else if (srAr[0].equals("3")) {
					System.out.println("locatiter is in DetailRecord- Not Activity details");
					if (srAr.equals(getval)) {
						int g = Arrays.asList(srAr).indexOf(getval);
						g = g + 1;
						String h = String.valueOf(g) + ".DetailRecord";
						/*System.out.println("Value is in " + g + " Postion");
						System.out.println(cofigTwo.getRecordHeaderValueSize().get(h));*/
						resultvalue.add(cofigTwo.getRecordHeaderValueSize().get(h));
					}
				}
			} else {
//				System.out.println("Canot Find the value");
			}
		}
		
		if(resultvalue.size() == 1)
		{
			return resultvalue.get(0);
		}
		else
		{
//			Logg an error at this palce
			return null;
		}

	}

	public HashMap<String, HashMap<String, ArrayList<String>>> getDataInToHashDataSet(ArrayList<String> FileData) {

		ArrayList<String> valSetRecordHeader = new ArrayList<String>();
		ArrayList<String> valSetFileHead = new ArrayList<String>();
		ArrayList<String> valSetFileTailer = new ArrayList<String>();
		HashMap<String, ArrayList<String>> mapData = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> mapFileHeader = new HashMap<String, ArrayList<String>>();
		HashMap<String, ArrayList<String>> mapFileTail = new HashMap<String, ArrayList<String>>();
		HashMap<String, HashMap<String, ArrayList<String>>> TotMap = new HashMap<String, HashMap<String, ArrayList<String>>>();
		String B = "";
		for (String v : FileData) {
			String blubell = v;
			blubell = blubell.replace("|", "##");
			String[] vSplitArray = blubell.split("##");

			if (vSplitArray[0].equals("0")) {

				valSetFileHead.add(v);
				mapFileHeader.put("Header", valSetFileHead);
				TotMap.put("HeaderData", mapFileHeader);

			}

			else {

				if (vSplitArray[0].equals("1") || vSplitArray[0].equals("9")) {
					if (!B.equals("")) {
						ArrayList<String> tet = new ArrayList<String>();
						for (String gg : valSetRecordHeader) {
							tet.add(gg);
						}

						mapData.put(B, tet);

					}
					if (vSplitArray[0].equals("9")) {

						valSetFileTailer.add(v);
						mapFileTail.put("Footer", valSetFileTailer);
						TotMap.put("FooterData", mapFileTail);
					}

					valSetRecordHeader.clear();
					B = "";
					B = vSplitArray[1];
					valSetRecordHeader.add(v);

				} else {
					valSetRecordHeader.add(v);

				}

			}

		}
		TotMap.put("Data", mapData);
		return TotMap;

	}

	public List<String[]> getDataFromCSV(String Filename) throws IOException {
		String CSV_PATH = configFileReader.getOutputCSVFilePath()+"/"+ Filename;
		System.out.println(CSV_PATH);
		CSVReader reader = new CSVReader(new FileReader(CSV_PATH));
		List<String[]> listData = reader.readAll();
		System.out.println("SIZE:" + listData.size());

		return listData;

	}

	public ArrayList<String> distributeDataByType(List<String[]> listData) {
//		String CsvInString = "";
		ArrayList<String> bellRing = new ArrayList<String>();

		HashMap<String, String> mapDisData = new HashMap<String, String>();

		for (String[] strArr : listData) {
			for (String str : strArr) {
//	    		Store the Value interDataStr as Key in the Hash map By iterating interDataStr
//	    		System.out.println(str);
//	    		mapDisData.put(key, value)
//	    		CsvInString = CsvInString+str;
				bellRing.add(str);

			}
		}

//		System.out.println(bellRing);
		return bellRing;
	}

	public String getFileName(String intrName) {
		File folder = new File(configFileReader.getOutputCSVFilePath());
		File[] listOfFiles = folder.listFiles();
		String filname = null;
		intrName = intrName + ".csv";
		Boolean FileCheck = false;

		for (int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isFile() && listOfFiles[i].getName().equals(intrName)) {
				System.out.println("File " + listOfFiles[i].getName());
				filname = listOfFiles[i].getName();
				FileCheck = true;
			}

			else if (FileCheck = false) {
				System.out.println("File " + intrName + "is not in the directory. So retruning Null");
			}
		}
		return filname;

	}

	public boolean validateFileHeader(ArrayList<String> FileHeader) {
		boolean validate = false;
		if (FileHeader.size() == 1) {

			for (String d : FileHeader) {
				d = d.replace("|", "##");
				String[] dArr = d.split("##");
				if (dArr.length == 7) {
					if (checkNumberwith(dArr[0], 1) && checkNumberwith(dArr[1], 5) && checkCharacter(dArr[2], 5)
							&& checkCharacter(dArr[3], 7) && checkCharacter(dArr[4], 2) && checkIsThisDateValid(dArr[5])
							&& checkIsThisTimeValid(dArr[6])) {
						validate = true;
					}

				} else {
					System.out.println(" This is an invalid entry  as " + d + "is having " + dArr.length + " ");
					validate = false;
				}
			}
		} else {
			System.out.println("File header is having Two Header INVLID Data");
			validate = false;
		}
		return validate;

	}

	/*public void getValueAndPostionFileHeader(String getval) throws IOException {

		List<String[]> listData = csvReader.getDataFromCSV(fileName);
		ArrayList<String> disData = csvReader.distributeDataByType(listData);
		HashMap<String, HashMap<String, ArrayList<String>>> TotalHashData = csvReader.getDataInToHashDataSet(disData);
		ArrayList<String> FileHeader = TotalHashData.get("HeaderData").get("Header");

		if (FileHeader.size() == 1) {
			String[] FileHeaderArray = FileHeader.toString().replace("|", "##").split("##");
			if (Arrays.stream(FileHeaderArray).anyMatch(getval::equals)) {
				int g = Arrays.asList(FileHeaderArray).indexOf(getval);
				g = g + 1;
				String h = String.valueOf(g) + ".RecordType7";
				System.out.println("Value is in " + g + " Postion");
				System.out.println(cofigTwo.getRecordHeaderValueSize().get(h));
			}

		} else {
			System.out.println("There are Two file Headers");
		}
	}*/

	public boolean vlaidateTrailerdata(ArrayList<String> FileTrailer) {
		boolean validate = false;
		if (FileTrailer.size() == 1) {

			for (String d : FileTrailer) {
				d = d.replace("|", "##");
				String[] dArr = d.split("##");
				if (dArr.length == 5) {
					if (checkNumberwith(dArr[0], 1) && checkNumberwith(dArr[1], 10) && checkNumberwith(dArr[2], 10)
							&& checkNumberwith(dArr[3], 10) && checkNumberwith(dArr[4], 10)) {
						validate = true;
					}

				} else {
					System.out.println(" This is an invalid entry  as " + d + "is having " + dArr.length + " ");
					validate = false;
				}
			}
		} else {
			System.out.println("File header is having Two Trailer : INVLID Data");
			validate = false;
		}
		return validate;

	}

	public boolean checkCharacter(String value, int sizeToValidate) {
		boolean validate = false;

		if (value != " ") {
			if (value.contains("_")) {
				value = value.replace("_", "");
			}

			if (value.length() <= sizeToValidate && value.length() != 0) {
				Pattern p = Pattern.compile("^[ A-Za-z]+$");
				Matcher m = p.matcher(value);
				boolean b = m.matches();
				if (b) {
					System.out.println(value + " is a Character");
					validate = true;
				} else {
					System.out.println(value + " is not a Character");
				}
			} else {
				System.out.println("Please Enter Value");
			}

		} else {
			System.out.println(value + " is a NUll value : Validation sucess but no vlaue for this parameter");
			validate = true;
		}
		return validate;

	}

	public boolean checkCharacterAndNumber(String value, int sizeToValidate) {
		boolean validate = false;

		if (value != " ") {
			if (value.contains("_")) {
				value = value.replace("_", "");
			}

			if (value.length() <= sizeToValidate && value.length() != 0) {
				Pattern p = Pattern.compile("^[a-zA-Z0-9]+$");
				Matcher m = p.matcher(value);
				boolean b = m.matches();
				if (b) {
					System.out.println(value + " is a CharacterNumber");
					validate = true;
				} else {
					System.out.println(value + " is not a CharacterNumber");
				}
			} else {
				System.out.println("Please Enter Value");
			}

		} else {
			System.out.println(value + " is a NUll value : Validation sucess but no vlaue for this parameter");
			validate = true;
		}
		return validate;

	}

	public boolean checkIsThisDateValid(String dateToValidate) {
		boolean validate = true;

		if (dateToValidate != " ") {

			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
			dateFormat.setLenient(false);
			try {
				dateFormat.parse(dateToValidate.trim());
			} catch (ParseException pe) {
				System.out.println(dateToValidate + " :False - Is NOT A Date");
				return false;

			}
		} else {
			System.out.println(dateToValidate + " is a NUll value : Validation sucess but no vlaue for this parameter");
		}
		System.out.println(dateToValidate + " :False - Is  A Date");
		return true;

	}

	public boolean checkIsThisTimeValid(String timeToValidate) {

		if (timeToValidate != " ") {

			SimpleDateFormat dateFormat = new SimpleDateFormat("hhmmss");
			dateFormat.setLenient(false);
			try {
				dateFormat.parse(timeToValidate.trim());
			} catch (ParseException pe) {
				System.out.println(timeToValidate + " :False - Is NOT A Time");
				return false;
			}
		} else {
			System.out.println(timeToValidate + " is a NUll value : Validation sucess but no vlaue for this parameter");
		}

		System.out.println(timeToValidate + " Is a Time");
		return true;

	}

	public boolean checkNumberwith(String value, int sizeToValidate) {
		boolean validate = false;
		String stringValue = value;
		if (stringValue != " ") {

			if (stringValue.length() <= sizeToValidate && stringValue.length() != 0) {
				validate = true;

				try {
					Double num = Double.parseDouble(stringValue);
				} catch (NumberFormatException e) {
					validate = false;
				}

				if (validate) {
					System.out.println(stringValue + " is a number");
				} else {
					System.out.println(stringValue + " is not a number");
				}
			} else {
				System.out.println("Please Enter Value");

			}
		} else {
			System.out.println(stringValue + " is a NUll value : Validation sucess but no vlaue for this parameter");
			validate = true;
		}
		return validate;

	}

}
