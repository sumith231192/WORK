package utility;

import java.sql.Connection;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import helper.AssertionHelper;
import utility.DataBaseReader;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {

	DataBaseReader dataBaseReader;
	AssertionHelper assertionHelper = new AssertionHelper();
	static String[] testDataValue;

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String TableName = "Application_Date_Set";
		String column = "Application_Date";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public String getDbResult(String query) throws ClassNotFoundException, SQLException {
		dataBaseReader = new DataBaseReader();
		String dbUrl = dataBaseReader.getDBurl();
		String username = dataBaseReader.getUserID();
		String password = dataBaseReader.getPassword();
		Connection con = null;
		String DB_Result = null;
		String user = "NOADM";
//		System.out.println("******" + dbUrl + "*****" + username + "*******" + password);

		try {

			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			stmt.executeQuery("begin  security.set_staff_id('" + user + "','','','',''); END;");
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				DB_Result = rs.getString(1);
				System.out.println("Result from DB" + DB_Result);

			}

		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("Closing the DB connection");
			con.close();
		}
		return DB_Result;

	}
	
	
	public HashMap<String, String> getMultiDbResult(String query) throws ClassNotFoundException, SQLException {
		dataBaseReader = new DataBaseReader();
		String dbUrl = dataBaseReader.getDBurl();
		String username = dataBaseReader.getUserID();
		String password = dataBaseReader.getPassword();
		Connection con = null;
		String DB_Result = null;
		String admin = dataBaseReader.getStafId();
		HashMap<String, String> resultHash = new HashMap<>();
		
//		System.out.println("******" + dbUrl + "*****" + username + "*******" + password);

		try {

			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			stmt.executeQuery("begin  security.set_staff_id('" + admin + "','','','',''); END;");
			ResultSet rs = stmt.executeQuery(query);
			ResultSetMetaData rsmd = rs.getMetaData();
			while (rs.next()) {
				
				for (int i = 1 ; i<= rs.getFetchSize();i++)
				{
					resultHash.put(rsmd.getColumnName(i), rs.getString(i));
				}
				
				System.out.println("Result from DB" + resultHash);

			}

		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("Closing the DB connection");
			con.close();
		}
		return resultHash;

	}
	
	
	
	
	public void ceckDbResultValue(HashMap<String, String> getMultiDbResult,String data)
	{
		ArrayList<String> valueArr = new ArrayList<>();
		if(data.contains("[") && data.contains("]"))
		{
			data = data.replace("[", "").replace("]", "");
		}
		
		for(Map.Entry<String, String> entry : getMultiDbResult.entrySet())
		{
			valueArr.add(entry.getValue());
		}
		
		if(valueArr.size() != 0 && valueArr.contains(data))
		{
		AssertionHelper.markPass("PASS:The Value is Validated Sucessfull:" +data+"Hense making Pass");
		}
		else
		{
			AssertionHelper.markFail("FAIL: Test Data Value:"+data+ " Is Not displyed");
		}
	}

	
	public void ceckTotalDBWithTotalExcelForTest(HashMap<String, String> DbHash, HashMap<String, String> ExcelHsh)
	{
		for(Map.Entry<String, String> entryDB : DbHash.entrySet())
		{
//			
				if(ExcelHsh.containsKey(entryDB.getKey()))
				{
						if(!ExcelHsh.get(entryDB.getKey()).toUpperCase().equals("NULL"))
						{
							if(entryDB.getValue().equals(ExcelHsh.get(entryDB.getKey())))
							{
								AssertionHelper.markPass("PASS:DB VALUE :"+entryDB.getValue()+"Validated With  "+ExcelHsh.get(entryDB.getKey())+"  PASS");
								System.out.println("PASS:DB VALUE :  "+entryDB.getValue()+"  Validated With   "+ExcelHsh.get(entryDB.getKey())+"  PASS");
							}
							else
							{
								AssertionHelper.markPass("FAIL:DB VALUE :"+entryDB.getValue()+"Validated With  "+ExcelHsh.get(entryDB.getKey())+"  FAIL");
								System.out.println("FAIL:DB VALUE :  "+entryDB.getValue()+"  Validated With   "+ExcelHsh.get(entryDB.getKey())+"  FAIL");
							}
						}
						else
						{
							AssertionHelper.markPass("PASS:DB VALUE :"+entryDB.getValue()+"Validated With  NULL"+ExcelHsh.get(entryDB.getKey())+"PASS:  VAlue is NUll");
							System.out.println("PASS:DB VALUE :  "+entryDB.getValue()+"  Validated With  NULL "+ExcelHsh.get(entryDB.getKey())+"PASS :   Value is Null");
						}
				}
		}
			
		
	}
	
	public static <K, V> ArrayList<String> getKey(Map<K, V> map, V value) {
		ArrayList<String> blist = new ArrayList<String>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			if (value.equals(entry.getValue())) {
//			return entry.getKey();
//				System.out.println(entry.getKey().toString());
				blist.add(entry.getKey().toString());
			}
		}
		return blist;
	}
	
	
	public static <K, V> ArrayList<String> getValue(Map<K, V> map, V value) {
		ArrayList<String> blist = new ArrayList<String>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			if (value.equals(entry.getKey())) {
//			return entry.getKey();
//				System.out.println(entry.getKey().toString());
				blist.add(entry.getValue().toString());
			}
		}
		return blist;
	}
	public void updateDbDate(String condition) throws Exception {

		String[] excelData = DataBaseConnection.getTestData(condition);
		String date = excelData[0];

		dataBaseReader = new DataBaseReader();
		String dbUrl = dataBaseReader.getDBurl();
		String username = dataBaseReader.getUserID();
		String password = dataBaseReader.getPassword();
		Connection con = null;
		String DB_Result = null;
		//String user = "NOADM";

		String Date_query = dataBaseReader.getDBUpdateQuery();
		//String Date_SETSEC_query = dataBaseReader.setSecutityforNOADM();
		// String Date_query = "Update TBMS_INIT_PARAMETERS "+"Set TIP_VALUE=
		// '05/01/2016' Where TIP_KEY ='TBA_APPLICATION_DATE'" ;
		Date_query = Date_query.replace("##", date);

		try {

			Class.forName("oracle.jdbc.OracleDriver");
			con = DriverManager.getConnection(dbUrl, username, password);
			Statement stmt = con.createStatement();
			stmt.executeQuery(dataBaseReader.setSecutityforNOADM());
			//stmt.executeQuery("begin  security.set_staff_id('" + user + "','','','',''); END;");
			stmt.executeQuery(Date_query);

			// ResultSet rs = stmt.executeQuery(Date_query); // We Have To ebeter
			stmt.executeQuery("COMMIT;"); // the DB Query with
											// Date Field as
											// Input parameter
			/*
			 * while (rs.next()) { DB_Result = rs.getString(1);
			 * System.out.println("Result from DB" + DB_Result);
			 * 
			 * }
			 */

		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("Closing the DB connection");
			con.close();
		}

	}
	
	public void vlaidateDBdate(String date) throws ClassNotFoundException, SQLException
	{
		String comVal = getDbResult(dataBaseReader.getCheckDBDateQuery());
		if(date.equals(comVal))
				{
			assertionHelper.pass();
				}
		else
		{
			assertionHelper.fail();
		}
	}
	
	
	
	public String getQueryByTestCaseID(HashMap<String, String> getDBQueryHash,String TescaseID)
	{
		
//		HashMap<String, String> getDBQueryHash = dataBaseReader.getDataBaseRecordRecordDataValuehash();
		String Query = "";
		
		ArrayList<String> QueryList = getValue(getDBQueryHash, TescaseID);
		
		if(QueryList.size() == 1)
		{
			Query= QueryList.get(0).toString();
		}
		else
		{
			AssertionHelper.markFail("Duplicate Query Entry For Sametest Case");
		}
		
		return Query;
		
	}
	@SuppressWarnings("static-access")
	public void verifyResult(String condition) throws Exception {
		String result = getDbResult(dataBaseReader.getCheckDBDateQuery());
		String[] excelData = DataBaseConnection.getTestData(condition);
		String date = excelData[0];

		if (date.equalsIgnoreCase(result)) {

			AssertionHelper.markPass("Application Date updated successfully.");
		} else {
			assertionHelper.markFail("Application Date not updated successfully.");
		}
	}

}