package utility;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

public class WebDriverManager {
	ConfigFileReader configFileReader;
	private WebDriver driver;
	public WebDriver getDriver() {
		if(driver == null) 
			{

			driver = createDriver();
			System.out.println("As Drver is Null Creatig driver"+driver);
			}
		System.out.println(driver);
		return driver;
	}

	private WebDriver createDriver() {
		driver = createLocalDriver();
		   return driver;
	}

	private WebDriver createRemoteDriver() {
		throw new RuntimeException("RemoteWebDriver is not yet implemented");
	}

	@SuppressWarnings("deprecation")
	private WebDriver createLocalDriver() {

		System.out.println("Initializing Browser.....");	
//		String browser = configFileReader.getBrowser();
		String browser = "IE";
		System.out.println(browser);
			if(browser.toUpperCase().equalsIgnoreCase("CHROME"))
			{
			System.setProperty("webdriver.chrome.driver","./src/main/resources/drivers/chromedriver.exe");
			driver = new ChromeDriver();
//			driver.get("https://accounts.google.com");
			System.out.println("DRIVER:"+driver);
		
			}
			else if(browser.toUpperCase().equalsIgnoreCase("IE"))
			{
			System.setProperty("webdriver.ie.driver","./src/main/resources/drivers/IEDriver.exe");
			DesiredCapabilities ieCapabilities = DesiredCapabilities.internetExplorer();          
//            ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,true);
			ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
	
            
           
			driver = new InternetExplorerDriver(ieCapabilities);
			driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			System.out.println(driver);
			driver.manage().window().maximize();
			}
		return driver;
	}	

	public void closeDriver() {
		driver.close();
//		driver.quit();
	}

}