package utility;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import helper.AssertionHelper;

public class ExcelReader {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;
	ConfigFileReader configFileReader = new ConfigFileReader();
	public XSSFSheet getSheet(String SheetName) throws Exception {
		HashMap<String, XSSFSheet> sheetFromExcel = new HashMap<>();
		try {
			// Open the Excel file
			FileInputStream ExcelFile = new FileInputStream(configFileReader.getValue("DATAEXCEL"));
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			for (int i = 0; i < ExcelWBook.getNumberOfSheets(); i++) {
				sheetFromExcel.put(ExcelWBook.getSheetAt(i).getSheetName(), ExcelWSheet = ExcelWBook.getSheetAt(i));
			}
			// ExcelWSheet = ExcelWBook.getSheet(SheetName);
		} catch (Exception e) {
			throw (e);
		}
		for (Entry<String, XSSFSheet> entry : sheetFromExcel.entrySet()) {
			if (SheetName.equals(entry.getKey().toString())) {
				ExcelWSheet = entry.getValue();
			}
		}
		return ExcelWSheet;
	}
	public String getValueFromExcel(HashMap<String, String> totHash, String ColumnName) {
		String columnValue = null;
		if (totHash.size() != 0) {
			ArrayList<String> hh = getValue(totHash, ColumnName);
			if (hh.size() == 1) {
				columnValue = hh.toString();
			} else {
				AssertionHelper.markFail("Duplicate value Preset:" + hh.toString());
			}
		} else {
			AssertionHelper.markFail("The Excel To hash is Null");
		}
		if (columnValue.contains("[") && columnValue.contains("]")) {
			columnValue = columnValue.replace("[", "").replace("]", "");
		}
		return columnValue;
	}
	public HashMap<String, String> getHashValueFromExcel(XSSFSheet ExcelWSheet, String TestCaseId, String SerialNo)
			throws Exception
	{
		HashMap<String, String> totHash = new HashMap<>();
		String columnValue = null;
		try {
			/*
			 * System.out.println(ExcelWSheet.getSheetName());
			 * System.out.println(ExcelWSheet.getLastRowNum());
			 * System.out.println(ExcelWSheet.getRow(1).getLastCellNum());
			 * System.out.println(ExcelWSheet.getRow(1).getPhysicalNumberOfCells());
			 */
			//needs to change code here to get only row value instead of whole sheet
			for (int i = 0; i <= ExcelWSheet.getLastRowNum(); i++) {
				if (TestCaseId.equals(ExcelWSheet.getRow(i).getCell(0).getStringCellValue())) {
					if(SerialNo.equals(ExcelWSheet.getRow(i).getCell(1).getStringCellValue())) {
					for (int j = 0; j <= ExcelWSheet.getRow(i).getLastCellNum() - 1; j++) {
						String KeyForMap = "";
						String valueForMap = "";
						KeyForMap = ExcelWSheet.getRow(0).getCell(j).getStringCellValue();
						valueForMap = ExcelWSheet.getRow(i).getCell(j).getStringCellValue();
						/*
						 * if(valueForMap.equals("NULL")) {
						 * 
						 * }
						 */
						totHash.put(KeyForMap, valueForMap);
						// System.out.println(totHash);
					}
				}
				}

			}
		} finally {

		}
		return totHash;
	}

	// This method is to read the test data from the Excel cell, in this we are
	// passing parameters as Row num and Col num

	public static String getCellData(int RowNum, int ColNum) throws Exception {
		try {
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();
			return CellData;
		} catch (Exception e) {
			return "";
		}
	}
	public static String getTestCaseName(String sTestCase) throws Exception {
		String value = sTestCase;
		try {
			int posi = value.indexOf("@");
			value = value.substring(0, posi);
			posi = value.lastIndexOf(".");
			value = value.substring(posi + 1);
			return value;
		} catch (Exception e) {
			throw (e);
		}
	}

	public static int getRowContains(String sTestCaseName, int colNum) throws Exception {
		int i;
		try {
			int rowCount = ExcelReader.getRowUsed();
			for (i = 0; i < rowCount; i++) {
				if (ExcelReader.getCellData(i, colNum).equalsIgnoreCase(sTestCaseName)) {
					break;
				}
			}
			return i;
		} catch (Exception e) {
			throw (e);
		}
	}

	public static int getRowUsed() throws Exception {
		try {
			int RowCount = ExcelWSheet.getLastRowNum();
			return RowCount;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw (e);
		}
	}

	public static <K, V> ArrayList<String> getKey(Map<K, V> map, V value) {
		ArrayList<String> blist = new ArrayList<String>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			if (value.equals(entry.getValue())) {
				// return entry.getKey();
				// System.out.println(entry.getKey().toString());
				blist.add(entry.getKey().toString());
			}
		}
		return blist;
	}

	public static <K, V> ArrayList<String> getValue(Map<K, V> map, V value) {
		ArrayList<String> blist = new ArrayList<String>();
		for (Map.Entry<K, V> entry : map.entrySet()) {
			if (value.equals(entry.getKey())) {
				// return entry.getKey();
				// System.out.println(entry.getKey().toString());
				blist.add(entry.getValue().toString());
			}
		}
		return blist;
	}
}