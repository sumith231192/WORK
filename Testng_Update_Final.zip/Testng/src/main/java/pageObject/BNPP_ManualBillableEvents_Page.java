package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_ManualBillableEvents_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	static String[] testDataValue;

	public BNPP_ManualBillableEvents_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(), 'Manual Billable Events')]")
	private WebElement ManualBillableEvents_Label;

	@FindBy(id = "transDetails_0__MTE_USER1")
	private WebElement User_TextBox;

	@FindBy(id = "transDetails_0__MTE_USER2")
	private WebElement Users_Team_TextBox;

	@FindBy(id = "transDetails_0__MTE_USER6")
	private WebElement Client_Name_TextBox;

	@FindBy(id = "transDetails_0__MTE_USER14")
	private WebElement Charge_code_TextBox;

	@FindBy(id = "transDetails_0__MTE_USER16")
	private WebElement Number_of_Units_TextBox;

	@FindBy(name = "COMMON.ADD_DETAILS")
	private WebElement Add_Button;

	@FindBy(name = "COMMON.SAVE")
	private WebElement Save_Button;

	@FindBy(xpath = "//a[contains(text(), 'Filter')]")
	private WebElement Filter_Link;

	@FindBy(name = "FilterColumn")
	private WebElement FilterColumn_DropDown;

	@FindBy(name = "FilterOperator")
	private WebElement FilterOperator_DropDown;

	@FindBy(name = "FilterValue")
	private WebElement FilterValue_TextBox;

	@FindBy(name = "FilterAdd")
	private WebElement Filter_Add_Button;

	@FindBy(name = "B12")
	private WebElement Filter_Search_Button;

	@FindBy(xpath = "//table[@summary, 'MANUAL_TRANSACTION_MEDIATION')]")
	private WebElement ManualBillableEvents_Table;

	@FindBy(id = "MTE_USER1")
	private WebElement User_Name;

	@FindBy(id = "MTE_USER2")
	private WebElement Users_Team;

	@FindBy(id = "MTE_USER3")
	private WebElement Service_Unique_Reference_Code;

	@FindBy(id = "MTE_USER4")
	private WebElement Source;

	@FindBy(id = "MTE_USER5")
	private WebElement Contrast_Structure;

	@FindBy(id = "MTE_USER6")
	private WebElement Client_Name;

	@FindBy(id = "MTE_USER7")
	private WebElement Branch_Code;

	@FindBy(id = "MTE_USER8")
	private WebElement Radix_Number_of_the_Client;

	@FindBy(id = "MTE_USER9")
	private WebElement Ordinal_of_Account;

	@FindBy(id = "MTE_USER10")
	private WebElement Key_of_Account;

	@FindBy(id = "MTE_USER11")
	private WebElement Account_currency;

	@FindBy(id = "MTE_USER12")
	private WebElement IBAN_Account;

	@FindBy(id = "MTE_USER13")
	private WebElement Description;

	@FindBy(id = "MTE_USER14")
	private WebElement Charge_Code;

	@FindBy(id = "MTE_USER15")
	private WebElement Event_Date;

	@FindBy(id = "MTE_USER16")
	private WebElement Number_of_Units;

	@FindBy(id = "MTE_USER17")
	private WebElement Transaction_Amount;

	@FindBy(id = "MTE_USER18")
	private WebElement Transaction_currency;

	@FindBy(id = "MTE_USER19")
	private WebElement Fee_Amount;

	@FindBy(id = "MTE_USER21")
	private WebElement Fee_currency;

	@SuppressWarnings("static-access")
	public void ckeckManualBillableEventsLabelDisplayed() {
		if (verificationHelper.isDisplayed(ManualBillableEvents_Label)) {
			Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
			assertionHelper.markPass("Manual billable Event screen is displaying successfully.");
		} else {
			assertionHelper.markFail("Manual billable Event screen is not displaying.");
		}
	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "User_Name,Users_Team,Service_Unique_Reference_Code,Source,Contrast_Structure,Client_Name,Branch_Code,Radix_Number_of_the_Client,Ordinal_of_Account,Key_of_Account,Account_currency,IBAN_Account,Description,Charge_Code,Event_Date,Number_of_Units,Transaction_Amount,Transaction_currency,Fee_Amount,Fee_currency";
		String TableName = "Manual_Billable_Events";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		System.out.println(testDataValue[0]);
		return testDataValue;
	}

	public static String[] getDropdownIndexValue(String condition) throws Exception {
		String RowNo = "1";
		String column = "User_Name,Service_Unique_Reference_Code,Source,Contrast_Structure,Client_Name,Branch_Code,Radix_Number_of_the_Client,Ordinal_of_Account,Key_of_Account,Account_currency,IBAN_Account,Description,Charge_Code,Event_Date,Number_of_Units,Transaction_Amount,Transaction_currency,Fee_Amount,Fee_currency";
		String TableName = "Manual_Billable_Events";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		System.out.println(testDataValue[0]);
		return testDataValue;
	}

	public void CreateManualTransactionEntry(String condition) throws Exception {
		String[] excelData = BNPP_ManualBillableEvents_Page.getTestData(condition);

		String User = excelData[0];
		String UsersTeam = excelData[1];
		String ClientName = excelData[5];
		String ChargeCode = excelData[13];
		String NumberofUnits = excelData[15];

		User_TextBox.sendKeys(User);
		Users_Team_TextBox.sendKeys(UsersTeam);
		Client_Name_TextBox.sendKeys(ClientName);
		Charge_code_TextBox.sendKeys(ChargeCode);
		Number_of_Units_TextBox.sendKeys(NumberofUnits);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
	}

	public WebElement AddButton() {
		return Add_Button;
	}

	public WebElement SaveButton() {
		return Save_Button;
	}

	public void CheckManualTransactionEntrySuccessful() {
		// validate the successful message
		// store batch id produced after saving
	}

	public void FilterManualTransactionEntry(String condition) throws Exception {
		String[] excelData = BNPP_ManualBillableEvents_Page.getDropdownIndexValue(condition);
		Filter_Link.click();
		for (int index = 0; index <= 4; index++) {
			Wait.waitUnitWebElementVisible(driver, FilterColumn_DropDown);
			dropDownHelper.selectUsingIndex(FilterColumn_DropDown, index);
			Wait.waitUnitWebElementVisible(driver, FilterValue_TextBox);
			FilterValue_TextBox.sendKeys(excelData[index]);

			Filter_Add_Button.click();
		}
		Wait.waitUnitWebElementVisible(driver, Filter_Search_Button);
		Filter_Search_Button.click();

		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");
	}

	@SuppressWarnings("static-access")
	public void CheckManualTransactionEntryView(String condition) throws Exception {
		String[] excelData = BNPP_ManualBillableEvents_Page.getTestData(condition);
		Screenshot.takeSnapShot(driver, "ManualBillableEvents\\");

		if (excelData[0].equalsIgnoreCase(User_Name.getAttribute("value"))
				&& excelData[1].equalsIgnoreCase(Users_Team.getAttribute("value"))
				&& excelData[2].equalsIgnoreCase(Service_Unique_Reference_Code.getAttribute("value"))
				&& excelData[3].equalsIgnoreCase(Source.getAttribute("value"))
				&& excelData[4].equalsIgnoreCase(Contrast_Structure.getAttribute("value"))
				&& excelData[5].equalsIgnoreCase(Client_Name.getAttribute("value"))
				&& excelData[6].equalsIgnoreCase(Branch_Code.getAttribute("value"))
				&& excelData[7].equalsIgnoreCase(Radix_Number_of_the_Client.getAttribute("value"))
				&& excelData[8].equalsIgnoreCase(Ordinal_of_Account.getAttribute("value"))
				&& excelData[9].equalsIgnoreCase(Key_of_Account.getAttribute("value"))
				&& excelData[10].equalsIgnoreCase(Account_currency.getAttribute("value"))
				&& excelData[11].equalsIgnoreCase(IBAN_Account.getAttribute("value"))
				&& excelData[12].equalsIgnoreCase(Description.getAttribute("value"))
				&& excelData[13].equalsIgnoreCase(Charge_Code.getAttribute("value"))
				&& excelData[14].equalsIgnoreCase(Event_Date.getAttribute("value"))
				&& excelData[15].equalsIgnoreCase(Number_of_Units.getAttribute("value"))
				&& excelData[16].equalsIgnoreCase(Transaction_Amount.getAttribute("value"))
				&& excelData[17].equalsIgnoreCase(Transaction_currency.getAttribute("value"))
				&& excelData[18].equalsIgnoreCase(Fee_Amount.getAttribute("value"))
				&& excelData[19].equalsIgnoreCase(Fee_currency.getAttribute("value"))) {
			assertionHelper.markPass("Field validated successfully.");
		} else {
			assertionHelper.markFail("Field do not match");
		}
	}

}
