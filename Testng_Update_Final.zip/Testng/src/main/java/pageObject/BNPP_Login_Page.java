package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.DropDownHelper;
import utility.ConfigFileReader;

public class BNPP_Login_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);

	public BNPP_Login_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(name = "USERNAME")
	private WebElement userID_TextBox;

	@FindBy(name = "PASSWORD")
	private WebElement password_TextBox;

	@FindBy(name = "OFFICE")
	private WebElement office_DropDown;

	@FindBy(xpath = "//div[@class='form']//div[@id='label']/input")
	private WebElement login_Button;

	public void navigateTo_BNPP_Environment_Page() {
		userID_TextBox.sendKeys(configFileReader.getUserId());
		password_TextBox.sendKeys(configFileReader.getPassword());
		office_DropDown.sendKeys(configFileReader.getOffice());

		/*
		 * dropDownHelper.deSelectUsingVisibleText(office,
		 * configFileReader.getOffice());
		 */
		login_Button.click();
	}

	public void naviageToLoginXlerate() {
		driver.get(configFileReader.getApplicationUrl());
	}

}
