package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_TransactionConsolidationFrequency_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	Wait wait = new Wait();
	static String TableName = "Transaction_Consolidation";
	static String[] testDataValue;

	public BNPP_TransactionConsolidationFrequency_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(),'Transaction Consolidation Frequency Setup')]")
	WebElement Transaction_Consolidation_Frequency_Label;

	@FindBy(id = "details_0__CCUA_USER7")
	private WebElement BgId_TextBox;

	@FindBy(id = "details_0__CCUA_CUST_NO")
	private WebElement ClientID_TextBox;

	@FindBy(id = "details_0__CCUA_SUBS_ACT_NO")
	private WebElement Account_ID_TextBox;

	@FindBy(id = "details_0__CCUA_USER5")
	private WebElement ChargeCode_TextBox;

	@FindBy(id = "details_0__CCUA_USER_DATE1")
	private WebElement FromDate_TextBox;

	@FindBy(id = "details_0__CCUA_USER_DATE2")
	private WebElement ToDate_TextBox;

	@FindBy(id = "details_0__CCUA_USER3")
	private WebElement Transcation_Consolidation_Frequesncy_Dropdown;

	@FindBy(className = "validation-warn-info")
	private WebElement MessageHead;

	@FindBy(id = "SaveBtn")
	private WebElement Save_Button;

	@SuppressWarnings("static-access")
	public void transactionConsolidationFrequencyLabel() {
		if (verificationHelper.isDisplayed(Transaction_Consolidation_Frequency_Label)) {
			Screenshot.takeSnapShot(driver, "ClientHierarchy\\");
			AssertionHelper.markPass("Message Head is displaying suessfully");
		} else {
			assertionHelper.markFail("Message Head is not displaying suessfully");
		}
	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "BG_ID,Client_ID,Account_ID,Charge_Code,From_Date,To_Date,Transaction_Consolidation_Frequency";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void transactioncosolidation(String condition) throws Exception {
		String[] exelData = BNPP_TransactionConsolidationFrequency_Page.getTestData(condition);
		String BG_ID = exelData[0];
		String Client_ID = exelData[1];
		String Account_ID = exelData[2];
		String Charge_Code = exelData[3];
		String From_Date = exelData[4];
		String To_Date = exelData[5];
		String Transaction_Consolidation_Frequency = exelData[6];
		BgId_TextBox.sendKeys(BG_ID);
		ClientID_TextBox.sendKeys(Client_ID);
		Account_ID_TextBox.sendKeys(Account_ID);
		ChargeCode_TextBox.sendKeys(Charge_Code);
		FromDate_TextBox.sendKeys(From_Date);
		ToDate_TextBox.sendKeys(To_Date);

		dropDownHelper.selectUsingVisibleText(Transcation_Consolidation_Frequesncy_Dropdown,
				Transaction_Consolidation_Frequency);
		Save_Button.click();
		Wait.untilPageLoadComplete(driver);
	}
	
	@SuppressWarnings("static-access")
	public void validateCreation() {
		if (verificationHelper.isDisplayed(MessageHead)) {
			Screenshot.takeSnapShot(driver, "ClientHierarchy\\");
			AssertionHelper.markPass("Creation done Successfully.");
		} else {
			assertionHelper.markFail("Creation not done Successfully.");
		}
	}

}
