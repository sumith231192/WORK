package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.ConfigFileReader;

public class BNPP_ManualSettlements_Page {
	
	
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();


	public BNPP_ManualSettlements_Page(WebDriver driver) {
		 
		 this.driver = driver;
		 PageFactory.initElements(driver, this);	
	}

	 
	
	@FindBy(id = "BCP_EXT_REF_VR_NO")
	private WebElement Batch_Number ;
	
	
	
	@FindBy(linkText ="Xelerate Exception : Invalid Invoice number ")
	private WebElement error;
	
	
	@FindBy(id = "SaveBtn")
	private WebElement Save_Button ;
	
	@FindBy(id = "payments_0__PY_BILL_NO")
	private WebElement payment;
	
	
	public void setBatchNumber(String batchnumber)
	{
		
		 Batch_Number.sendKeys(batchnumber);
	}
	
	public WebElement getSaveButton()
	{
		return Save_Button;
	}
	
	public WebElement getPayment()
	{
		return payment;
	}
	

}
