package pageObject;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.ActionHelper;
import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.FilePathReader;
import helper.JavaScriptHelper;
import helper.VerificationHelper;
import helper.WindowHelper;
import test.FindFailed;
import test.Pattern;
import test.Screen;
import utility.ConfigFileReader;
import utility.ExcelUtils;

public class BNPP_FileUpload_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	FilePathReader filePathReader = new FilePathReader();
	JavaScriptHelper javaScriptHelper = new JavaScriptHelper(driver);
	ActionHelper actionHelper = new ActionHelper(driver);
	WindowHelper windowHelp;
	String filepath = "./src/main/resources/SikuliImage/";
	String inputFilePath = "./src/main/resources/TestData";
	static String[] testDataValue;

	public BNPP_FileUpload_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "CMU_PROCESS_NAME")
	private WebElement ProcessName_TextBox;

	@FindBy(id = "CMU_TEMPLATE_ID")
	private WebElement process_Temp;

	@FindBy(xpath = "//label[contains(text(), 'File Upload')]")
	private WebElement FileUpload_Label;

	@FindBy(name = "upFile")
	private WebElement FileUploadPath_TextBox;

	@FindBy(name = "COMMON.BTN_SIGNATURE_UPLOAD")
	private WebElement Upload_Button;

	@FindBy(className = "validation-header")
	private WebElement validationHeader_Text;
	
	@FindBy(linkText = "Create")
	private WebElement Create_Link;
	
	@FindBy(name = "CMU_PROCESS_NAME")
	private WebElement ProcessNameInputTextBox;
	
			

	@SuppressWarnings("static-access")
	public void ckeckPageFileUploadLabelDisplayed() {
		if (verificationHelper.isDisplayed(FileUpload_Label)) {
			assertionHelper.markPass();

		} else {
			assertionHelper.markFail();
		}
	}
	
	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Process_Name,File_Path";
		String TableName = "File_Upload";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		System.out.println(testDataValue[0]);
		return testDataValue;
	}

	public void uploadFile(String condition)  {
		//throws FindFailed
		String[] excelData = BNPP_FileUpload_Page.getTestData(condition);
		String ProcessNameValue = excelData[0];
		String PathOfFile = excelData[1];
		
						
		Screen screen = new Screen();
		Pattern ProcessNameTextBox = new Pattern(filepath + "ProcessNameTextBox.PNG");
		Pattern ProcessNameSearch = new Pattern(filepath + "ProcessNameSearch.PNG");
		Pattern ProcessNameOK = new Pattern(filepath + "ProcessNameOK.PNG");
		Pattern SelectButton = new Pattern(filepath + "SelectButton.PNG");
		Pattern fileInputTextBox = new Pattern(filepath + "FileNameInput.PNG");
		Pattern openButton = new Pattern(filepath + "FileOpen.PNG");
		Pattern browseButton = new Pattern(filepath + "BrowseButton.PNG");
	
		// Select Process Name by Double click
		Actions actions = new Actions(driver);
		actions.doubleClick(ProcessNameInputTextBox).perform();
		Thread.sleep(2000);
		screen.type(ProcessNameTextBox, ProcessNameValue);
		Thread.sleep(2000);
		screen.click(ProcessNameSearch);
		Thread.sleep(3000);
		screen.click(SelectButton);
		Thread.sleep(3000);
		screen.click(ProcessNameOK);
		Thread.sleep(3000);
	
		// Upload file using Selenium
		FileUploadPath_TextBox.sendKeys(PathOfFile);
		Thread.sleep(2000);
		Upload_Button.click();
		}

	
	@SuppressWarnings("static-access")
	public void checkFileUploadStatus() {
		// Create_Link.click();

		if (validationHeader_Text.getText().contains("Error(s)")) {
			System.out.println("TTTTTTTTTTTTTT");
			assertionHelper.markFail();
			Create_Link.click();

		} else {

			assertionHelper.markPass();
			Create_Link.click();
		}
	}

}
