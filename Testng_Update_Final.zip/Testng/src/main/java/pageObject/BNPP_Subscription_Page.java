package pageObject;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.Screenshot;
import utility.ConfigFileReader;
import utility.ExcelUtils;


public class BNPP_Subscription_Page {
	
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	
	public BNPP_Subscription_Page(WebDriver driver) {
		 this.driver = driver;
		 PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = "//label[text()='Subscription Setup']")
	private WebElement subscriptionPageHeader;
	
	@FindBy(id = "eventList_0__APM_CUST_ID")
	private WebElement subscriptionClientID;
	
	@FindBy(id = "eventList_0__APM_ACCT_ID")
	private WebElement subscriptionAccountID;
	
	@FindBy(id = "eventList_0__PRODUCT")
	private WebElement subscriptionChargeCode;
	
	@FindBy(id = "eventList_0__APM_USER_CHAR4")
	private WebElement subscriptionPricingFrequency;
	
	@FindBy(id = "eventList_0__APM_FROM_DATE")
	private WebElement subscriptionFromDate;
	
	@FindBy(id = "eventList_0__APM_TO_DATE")
	private WebElement subscriptionToDate;
	
	@FindBy(id = "eventList_0__APM_USER_CHAR8")
	private WebElement subscriptionProRate;
	
	@FindBy(id = "eventList_0__APM_USER_CHAR9")
	private WebElement subscriptionCollectionMethod;
	
	@FindBy(name = "eventList[0].DELETED")
	private WebElement subscriptioncheckBox;

	@FindBy(xpath = "//input[@id='SaveBtn']")
	private WebElement subscriptionSaveButton;
	
	@FindBy(id = "eventList_0__APM_USER_NUM1")
	private WebElement subscriptionVolume;
	
	@FindBy(id = "filter_img")
	private WebElement subscriptionViewFilter;
	
	@FindBy(name = "FilterColumn")
	private WebElement subscriptionViewFilterDropDown;
	
	@FindBy(name = "FilterValue")
	private WebElement subscriptionViewFilterValue;
	
	@FindBy(name = "FilterAdd")
	private WebElement subscriptionViewFilterAdd;
	
	@FindBy(name = "B12")
	private WebElement subscriptionViewFilterSearch;
	
	@FindBy(xpath = "//a[@title='Shows Subscription Setup details of record [1]']")
	private WebElement subscriptionViewFilterDetails;
	
	@FindBy(name = "eventList[0].APM_CUST_ID")
	private WebElement subscriptionViewClientID;
	
	@FindBy(name = "eventList[0].APM_ACCT_ID")
	private WebElement subscriptionViewAccountID;
	
	@FindBy(name = "eventList[0].PRODUCT")
	private WebElement subscriptionViewChargeCode;
	
	@FindBy(name = "eventList[0].APM_USER_NUM1")
	private WebElement subscriptionViewVolume;
	
	@FindBy(name = "eventList[0].APM_USER_CHAR4")
	private WebElement subscriptionViewFrequency;
	
	@FindBy(name = "eventList[0].APM_FROM_DATE")
	private WebElement subscriptionViewFromDate;
	
	@FindBy(name = "eventList[0].APM_TO_DATE")
	private WebElement subscriptionViewToDate;
	
	@FindBy(xpath = "//li[contains(text(),'Xelerate Exception')]")
	private WebElement subscriptionErrorMsg;
	
	@FindBy(xpath = "//li[contains(text(),'Successfully saved')]")
	private WebElement subscriptionSuccessMsg;
	
	
	public String[] getTestData(String condition) throws Exception {
		 String RowNum="1";
		 String Col="Client_ID,Account_Id,Charge_Code,Volume,Pricing_Frequency,From_Date,To_Date";
		 String TableName="Subscription_Setup";
		 ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		 String[] colArray = ExcelUtils.getCellData(RowNum, Col, TableName, condition);
		 return colArray;
	}
	
	
	
	public boolean checkSubscriptionHeader() {
		if (subscriptionPageHeader.isDisplayed())
			return true;
		else
		return false;
		
	}
	
	public boolean checkSubscriptionViewPage() {
		if (subscriptionViewFilter.isDisplayed())
			return true;
		else
		return false;
		
	}
	
	public void enterClientBgID(String clientBgID) {
		if (subscriptionClientID.isDisplayed()) {
			subscriptionClientID.clear();
			subscriptionClientID.sendKeys(clientBgID);}
		else throw new RuntimeException("Subscription Page-Client /BG ID WebEdit box is not present");
	}	
		
	public void enterAccount(String dtAccountID) {
		if (subscriptionAccountID.isDisplayed()) {
			subscriptionAccountID.clear();
			subscriptionAccountID.sendKeys(dtAccountID);}
		else throw new RuntimeException("Subscription Page-Account ID WebEdit box is not present");
	}
	
	
	public void enterChargeCode(String dtChargeCode) {
		if (subscriptionChargeCode.isDisplayed()) {
			subscriptionChargeCode.clear();
			subscriptionChargeCode.sendKeys(dtChargeCode);}
		else throw new RuntimeException("Subscription Page-Charge Code WebEdit box is not present");
	}
	
	public void enterVolume(String dtvolume) {
		if (subscriptionVolume.isDisplayed()) {
			subscriptionVolume.clear();
			subscriptionVolume.sendKeys(dtvolume);}
		else throw new RuntimeException("Subscription Page-Volume WebEdit box is not present");
	}
	
	public void enterFromDate(String fromDate) {
		if (subscriptionFromDate.isDisplayed()) {
			subscriptionFromDate.clear();
			subscriptionFromDate.sendKeys(fromDate);}
		else throw new RuntimeException("Subscription Page-From Date WebEdit box is not present");
	}
	
	public void enterToDate(String toDate) {
		if (subscriptionToDate.isDisplayed()) {
			subscriptionToDate.clear();
			subscriptionToDate.sendKeys(toDate);}
		else throw new RuntimeException("Subscription Page-To Date WebEdit box is not present");
	}
	
	public void selectPricingFrequency(String visibleText) {
		if (subscriptionPricingFrequency.isDisplayed())
			dropDownHelper.selectUsingVisibleText(subscriptionPricingFrequency,visibleText);
		else throw new RuntimeException("Subscription Page-Pricing Frequency DropDown is not present");
	}
	
	
	public void selectProRate(String visibleText) {
		if (subscriptionProRate.isDisplayed())
			dropDownHelper.selectUsingVisibleText(subscriptionProRate,visibleText);
		else throw new RuntimeException("Subscription Page-Pricing Frequency DropDown is not present");
	}
	
	public void selectCollectionMethod(String visibleText) {
		if (subscriptionCollectionMethod.isDisplayed())
			dropDownHelper.selectUsingVisibleText(subscriptionCollectionMethod,visibleText);
		else throw new RuntimeException("Subscription Page-Pricing Frequency DropDown is not present");
	}
	
	public void clickSaveBtn() {
		Screenshot.takeSnapShot(driver, "SubscriptionSetup\\");
		if (subscriptionSaveButton.isDisplayed()) {
			subscriptionSaveButton.click();}
		else {
			throw new RuntimeException("Subscription Page-To save button is not present");
		}
	}
	
	public void clickfilter() {
		if (subscriptionViewFilter.isDisplayed())
			subscriptionViewFilter.click();
		else throw new RuntimeException("Subscription Page-Filter is not present on View Page");
	}
	
	public void clickfilterAdd() {
		if (subscriptionViewFilterAdd.isDisplayed())
			subscriptionViewFilterAdd.click();
		else throw new RuntimeException("Subscription Page- Add Filter is not present on View Page");
	}
	
	public void clickfilterSearch() {
		if (subscriptionViewFilterSearch.isDisplayed())
			subscriptionViewFilterSearch.click();
		else throw new RuntimeException("Subscription Page- Search button is not present on View Page");
	}
	
	public void clickfilterDetail() {
		if (subscriptionViewFilterDetails.isDisplayed())
			subscriptionViewFilterDetails.click();
		else throw new RuntimeException("Subscription Page- Detail Link is not present on View Page");
	}
	
	public void selectFilterDropdown(int index) {
		if (subscriptionViewFilterDropDown.isDisplayed())
			dropDownHelper.selectUsingIndex(subscriptionViewFilterDropDown, index);
		else throw new RuntimeException("Subscription Page-Filter DropDown is not present");
	}
	
	public void setFilterDropdownValue(String filterValue) {
		if (subscriptionViewFilterValue.isDisplayed()) {
			subscriptionViewFilterValue.clear();
			subscriptionViewFilterValue.sendKeys(filterValue);}
		else throw new RuntimeException("Subscription Page-Filter Value is not present");
	}
	
	public boolean checkFilterResult() {
		if (subscriptionViewFilterDetails.isDisplayed()) return true;
		else return false;
	}
	
	public boolean checkChargecode() {
		if (subscriptionChargeCode.getAttribute("Value").length()>0)
			return true;
		else return false;
	}
	
	public void validateSubscriptionResult(String[] colArray) {
		int arrayLength = colArray.length;
		String clientId = subscriptionViewClientID.getAttribute("Value");
		String AccountId=subscriptionViewAccountID.getAttribute("Value");
		String ChargeCode=subscriptionViewChargeCode.getAttribute("Value");
		String Volume=subscriptionViewVolume.getAttribute("Value");
		String Frequency=subscriptionViewFrequency.getAttribute("Value");
		String FromDate=subscriptionViewFromDate.getAttribute("Value");
		String ToDate=subscriptionViewToDate.getAttribute("Value");
		
		System.out.println("the values are "+clientId+" "+AccountId+" "+ChargeCode+" "+Volume+" "+Frequency);
		int counter=0;
		if (clientId.equalsIgnoreCase(colArray[0]))
			counter++;	
		if (AccountId.equalsIgnoreCase(colArray[1]))
			counter++;
		if (ChargeCode.equalsIgnoreCase(colArray[2]))
			counter++;
		if (Volume.equalsIgnoreCase(colArray[3]))
			counter++;
		if (Frequency.equalsIgnoreCase(colArray[4].substring(0,1)))
			counter++;
		if (FromDate.equalsIgnoreCase(colArray[5]))
			counter++;
		if (ToDate.equalsIgnoreCase(colArray[6]))
			counter++;
			System.out.println("The count of counter is "+counter);
		if (counter==7) {
			Screenshot.takeSnapShot(driver, "SubscriptionSetup\\");
			AssertionHelper.markPass("The values of subscription in view are matching");}
		else {Screenshot.takeSnapShot(driver, "SubscriptionSetup\\");
			AssertionHelper.markFail("The values of subscription in view are not matching");}
	}
	
	public void statusMsg() {
		String msg=null;
		Screenshot.takeSnapShot(driver, "SubscriptionSetup\\");
		if (subscriptionErrorMsg.isDisplayed()) {
			msg=subscriptionErrorMsg.getText();
			AssertionHelper.markFail("Error while adding subscription "+msg);}
		else if (subscriptionSuccessMsg.isDisplayed()) { 
			AssertionHelper.markPass();}
		else 
			AssertionHelper.markFail("Status Message did not display");
		
	}
	
	public void viewSubscription(String[] colArray) throws Exception {
		 
		  boolean checkSubscriptionViewPage=checkSubscriptionViewPage();
		  if (checkSubscriptionViewPage) {
			  clickfilter();
			  for (int i=0;i<=6;i++) {
				  selectFilterDropdown(i);
				  setFilterDropdownValue(colArray[i]);
				  clickfilterAdd();
			  }
			  clickfilterSearch();
			  boolean subscriptionRecordPresent=checkFilterResult();
			  if (subscriptionRecordPresent) {
					  clickfilterDetail();
					  validateSubscriptionResult(colArray);
			  } 
			  else throw new RuntimeException("Subscription view Filtered Table is not loaded");
		  }
		  else throw new RuntimeException("Subscription view Page is not loaded");
	  }
	
}
