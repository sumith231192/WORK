package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_BookingCancellation_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	VerificationHelper verificationHelper = new VerificationHelper(driver);

	static String TableName = "Booking_Cancellation";
	static String[] testDataValue;

	public BNPP_BookingCancellation_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(),'Booking Cancellation')]")
	private WebElement Booking_Cancellation_Label;

	@FindBy(id = "CIC_CLIENT_ID")
	private WebElement Client_ID_TextBox;

	@FindBy(id = "CIC_ACCT_ID")
	private WebElement Account_ID_TextBox;

	@FindBy(id = "CIC_INV_REF")
	private WebElement Booking_Reference_TextBox;

	@FindBy(id = "CIC_BILL_NO")
	private WebElement Bill_Number_TextBox;

	@FindBy(name = "CSTM_INV_CANCELLATION.CIC_GO")
	private WebElement GO_Button;

	@FindBy(className = "UnderlineCell")
	private WebElement HeaderText_Label;

	public boolean booking_cancellationLabel() {
		return Booking_Cancellation_Label.isDisplayed();
	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Client_ID,Account_ID,Booking_Reference,Bill_Number";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void validate_booking_cancelation(String condition) throws Exception {

		String[] exelData = BNPP_BookingCancellation_Page.getTestData(condition);

		String clientId = exelData[0];
		String accountId = exelData[1];
		String bookRef = exelData[2];
		String billNum = exelData[3];

		Client_ID_TextBox.sendKeys(clientId);
		Account_ID_TextBox.sendKeys(accountId);
		Booking_Reference_TextBox.sendKeys(bookRef);
		Bill_Number_TextBox.sendKeys(billNum);
		Screenshot.takeSnapShot(driver, "BookingCancellation\\");
		GO_Button.click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "BookingCancellation\\");
	}

	@SuppressWarnings("static-access")
	public void validateCreationLabelDisplayed() {
		if (verificationHelper.isDisplayed(HeaderText_Label)) {
			Screenshot.takeSnapShot(driver, "ClientHierarchy\\");
			AssertionHelper.markPass("Message Head is displaying suessfully");
		} else {
			assertionHelper.markFail("Message Head is not displaying suessfully.");
		}
	}
}
