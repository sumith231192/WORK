package pageObject;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.DropDownHelper;
import helper.Screenshot;
import utility.ConfigFileReader;
import helper.AssertionHelper;
import helper.WindowHelper;
import utility.ExcelUtils;
import utility.Wait;

/**
 * This class is a page object class used to identify elements on Client Account
 * home page.
 *
 * @version 1 09 May 2019
 * @author HCL
 */

public class BNPP_Client_Account_Page {
	/**
	 * 	
	 */
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	WindowHelper windowHelper = new WindowHelper(driver);

	public BNPP_Client_Account_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(xpath = "//label[contains(text(),'Client/Account Home')][1]")
	private WebElement clientpageHeader;

	@FindBy(xpath = "//a[@title='Update Customer']")
	private WebElement clientUpdateRef;

	@FindBy(name = "CM_CUST_ID")
	private WebElement clientBGID;

	@FindBy(name = "COMMON.GO")
	private WebElement submitBtn;

	@FindBy(xpath = "//label[text()='Client Details']")
	private WebElement clientUpdatePageHeader;

	@FindBy(xpath = "//a[@title='Client Address']")
	private WebElement clientAddressRef;

	@FindBy(xpath = "//label[text()='Client Address']")
	private WebElement clientAddressHeader;

	@FindBy(id = "customerdetails_0__CM_REF8")
	private WebElement clientUpdateAddressCode;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER3']")
	private WebElement clientUpdateAddressNumber;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_1']")
	private WebElement clientUpdateAddressLine1;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_2']")
	private WebElement clientUpdateAddressLine2;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_3']")
	private WebElement clientUpdateAddressLine3;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_4']")
	private WebElement clientUpdateAddressLine4;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_9']")
	private WebElement clientUpdateClientTitleCode;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_BLNG_NAME']")
	private WebElement clientUpdateClientShortName;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_NAME2']")
	private WebElement clientUpdateClientName;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_NAME3']")
	private WebElement clientUpdateClientNameLine2;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_7']")
	private WebElement clientUpdateCityName;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_4']")
	private WebElement clientUpdateStatecode;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_5']")
	private WebElement clientUpdateStateName;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ZIP']")
	private WebElement clientUpdateZipCode;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_8']")
	private WebElement clientUpdatePOBox;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER11']")
	private WebElement clientUpdateBoxNo;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER12']")
	private WebElement clientUpdateBranchCodeofBox;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER5']")
	private WebElement clientUpdateTelexNo;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER10']")
	private WebElement clientUpdateSwiftAddress;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER6']")
	private WebElement clientUpdateFaxNo;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER4']")
	private WebElement clientUpdatePhoneNo;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER_DATE1']")
	private WebElement clientUpdateLastnonActingDate;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER7']")
	private WebElement clientUpdateMainLanguageCode;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER1']")
	private WebElement clientUpdateMailAddressline3;

	@FindBy(xpath = "//input[@name='customerAddressList[0].CMA_USER2']")
	private WebElement clientUpdateEmailDomain;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER13']")
	private WebElement clientUpdateUserCode;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_ADDR_NO']")
	private WebElement clientUpdateAddressNo;

	@FindBy(xpath = "//input[@id='customerAddressList_0__CMA_USER14']")
	private WebElement clientUpdateCountryCode;

	@FindBy(name = "COMMON.BUTTON_APPLY")
	private WebElement clientUpdateApplyButton;

	@FindBy(name = "COMMON.CLOSE")
	private WebElement clientUpdateCloseButton;

	@FindBy(id = "customerdetails_0__CM_USER56")
	private WebElement clientDetailInvoiceTemplet;

	@FindBy(id = "customerdetails_0__CM_USER57")
	private WebElement clientDetailInvoiceLanguage;

	@FindBy(id = "customerdetails_0__CM_USER55")
	private WebElement clientDetailDistributionChannel;

	@FindBy(id = "SaveBtn")
	private WebElement clientDetailsaveButton;

	@FindBy(xpath = "//a[@title='Update Account']")
	private WebElement accountUpdateRef;

	@FindBy(xpath = "//a[@title='Package Definition']")
	private WebElement accountPackageDefination;

	@FindBy(id = "PM_PHONE_NO")
	private WebElement clientAccountNo;

	@FindBy(xpath = "//label[text()='Account Details']")
	private WebElement accountUpdatePageHeader;

	// @FindBy(id="bundleDefn_0__CAB_BUNDLE_CODE")
	@FindBy(id = "bundleDefn_0__CAB_BUNDLE_CODE")
	private WebElement accUpdPkgDfnBundleCode;

	@FindBy(id = "bundleDefn_0__CAB_FROM_DATE")
	private WebElement accUpdPkgDefnFrmDt;

	@FindBy(id = "bundleDefn_0__CAB_TO_DATE")
	private WebElement accUpdPkgDefnToDt;

	@FindBy(name = "COMMON.BUTTON_APPLY")
	private WebElement accUpdPkgDefnApplyBtn;

	@FindBy(id = "customerdetails_0__CM_USER54")
	private WebElement clientUpdInvoiceLvl;

	@FindBy(xpath = "//a[@title='Create Customer Service order']")
	private WebElement clientAddMaintenanceRef;

	@FindBy(xpath = "//label[text()='Maintenance Request Client']")
	private WebElement clientAddMaintenanceRequestHeader;

	@FindBy(id = "subscriberdetails_0__PM_CNTRL9")
	private WebElement accountUpdMFC;

	@FindBy(id = "subscriberdetails_0__PM_WAIVE_BILL")
	private WebElement accountUpdWaiveBill;

	@FindBy(xpath = "//*[contains(text(),'Successfully ')]")
	private WebElement clinetAccountSuccessMsg;

	@FindBy(xpath = "//span[@class='x-tab-strip-text ' and text()='Menu']")
	private WebElement clientAccountMenuButton;

	@FindBy(xpath = "//li[contains(text(),'Xelerate Exception')]")
	private WebElement clientAccountErrorMsg;

	@FindBy(id = "TXT_CM_CUST_ID")
	private WebElement clientMaintainaceClientID;

	@FindBy(xpath = "//a[@title='Create Customer Service order']")
	private WebElement clientMaintenanceRef;

	@FindBy(xpath = "//label[text()='Maintenance Request Client']")
	private WebElement clientMaintenancePageHeader;

	@FindBy(id = "SRQ_DATE")
	private WebElement clientMaintenanceDate;

	@FindBy(id = "soDetails_0__SO_SC_CODE")
	private WebElement clientMaintenanceDropdown;

	@FindBy(id = "soDetails_0__SO_EQUP_CODE")
	private WebElement clientMaintenanceType;

	@FindBy(xpath = "//a[@title='detail of record [1]']")
	private WebElement clientMaintenanceDetails;

	@FindBy(id = "SO_NEW_PARAMETER")
	private WebElement clientMaintenancePriceList;

	@FindBy(name = "COMMON.OK")
	private WebElement clientMaintenanceOkButton;

	@FindBy(name = "COMMON.SAVE")
	private WebElement clientMaintenanceSaveButton;

	public String getTitle(WebDriver driver) {
		String title = driver.getTitle();
		return title;
	}

	public String[] getTestData(String condition) throws Exception {
		String RowNum = "1";
		String Col = "Client_ID,Account_ID,Invoice_Level,Invoice_Language,Invoice_Template,Distribution_Channel,Bundle_Code,From_Date,To_Date,Application_Date,Maintenance_Type,Pricelist,Address_Code";
		String TableName = "Client_Account_Home";
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		String[] colArray = ExcelUtils.getCellData(RowNum, Col, TableName, condition);
		return colArray;

	}

	public void clickUpdateClient() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientUpdateRef.isDisplayed()) {
			clientUpdateRef.click();
		} else {
			throw new RuntimeException("Client Account Page-Client Update Hypertext Reference is not present");
		}
	}

	public void clickUpdateAccount() {
		if (accountUpdateRef.isDisplayed())
			accountUpdateRef.click();
		else
			throw new RuntimeException("Client Account Page-Account Update Hypertext Reference is not present");
	}

	public void clickclientMaintenance() {
		Wait.waitUnitWebElementVisible(driver, clientMaintenanceRef);
		if (clientMaintenanceRef.isDisplayed()) {
			clientMaintenanceRef.click();
		} else {
			throw new RuntimeException("Client Account Page-client update Hypertext Reference is not present");
		}
	}

	public void enterClientBgID(String clientBgID) {
		if (clientBGID.isDisplayed()) {
			clientBGID.clear();
			clientBGID.sendKeys(clientBgID);
		} else
			throw new RuntimeException("Client Account Page-Client /BG ID WebEdit box is not present");
	}

	public void enterMaintenanceClientID(String accountID) {
		if (clientMaintainaceClientID.isDisplayed()) {
			clientMaintainaceClientID.clear();
			clientMaintainaceClientID.sendKeys(accountID);
		} else
			throw new RuntimeException("Client Account Page-Account ID WebEdit box is not present");
	}

	public void enterClientMaintenanceDate(String date) {
		if (clientMaintenanceDate.isDisplayed()) {
			clientMaintenanceDate.sendKeys(date);
		} else
			throw new RuntimeException("Client Account Page-Account ID WebEdit box is not present");
	}

	public void enterAccountId(String accountID) {
		if (clientAccountNo.isDisplayed()) {
			clientAccountNo.clear();
			clientAccountNo.sendKeys(accountID);
		} else
			throw new RuntimeException("Client Account Page-Account ID WebEdit box is not present");
	}

	public void enterMaintenanceType(String type) {
		if (clientMaintenanceType.isDisplayed()) {
			clientMaintenanceType.clear();
			clientMaintenanceType.sendKeys(type);
		} else
			throw new RuntimeException("Client Account Page-Maintenance type WebEdit box is not present");
	}

	public void clickPackageDefinition() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (accountPackageDefination.isDisplayed())
			accountPackageDefination.click();
		else
			throw new RuntimeException("Client Account Page-Package Definition is not present");
	}

	public void clickGoBtn() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (submitBtn.isDisplayed())
			submitBtn.click();
		else
			throw new RuntimeException("Client Account Page-Go button is not present");
	}

	public boolean checkClientAccountPageHeader() {
		if (clientpageHeader.isDisplayed()) {
			AssertionHelper.markPass("Account Page Header is visible");
			return true;

		} else {
			AssertionHelper.markFail("Account Page Header is not visible");
			return false;
		}
	}

	public void checkClientMaintenancePageHeader() {
		if (clientMaintenancePageHeader.isDisplayed())
			AssertionHelper.markPass();
		else
			AssertionHelper.markFail();
	}

	public boolean checkClientUpdateHeader() {
		if (clientUpdatePageHeader.isDisplayed()) {
			AssertionHelper.markPass("Client update Page Header is visible");
			return true;
		} else {
			AssertionHelper.markFail("Client update Page Header is not visible");
			return false;
		}
	}

	public boolean checkAccountUpdateHeader() {
		if (accountUpdatePageHeader.isDisplayed()) {
			AssertionHelper.markPass("Account update Page Header is visible");
			return true;
		} else
			AssertionHelper.markFail("Account update Page Header is not visible");
		return false;
	}

	public boolean checkClientAddressHeader() {
		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}
		if (clientAddressHeader.isDisplayed()) {
			AssertionHelper.markPass("Account Address Page Header is visible");
			return true;
		} else {
			AssertionHelper.markFail("Account Address Page Header is not visible");
			return false;
		}
	}

	public void checkClientAcctUpdateStatus() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clinetAccountSuccessMsg.isDisplayed()) {
			AssertionHelper.markPass("The Client is updated successfully");
		} else if (clientAccountErrorMsg.isDisplayed()) {
			if (clientUpdateCloseButton.isDisplayed())
				clientUpdateCloseButton.click();
			AssertionHelper.markFail("The Client is not updated successfully");
		} else
			AssertionHelper.markFail("Please check the error in the process Manually");
	}

	public void clickClientAddress() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientAddressRef.isDisplayed())
			clientAddressRef.click();
		else
			throw new RuntimeException("Client Account Page-Client Address Hypertext Reference is not present");
	}

	public void verfiyClientAddress() {
		/*
		 * Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		 * 
		 * String AddressNumber =
		 * clientUpdateAddressNumber.getAttribute("Value").trim(); String AddressLine1 =
		 * clientUpdateAddressLine1.getAttribute("Value").trim(); String AddressLine2 =
		 * clientUpdateAddressLine2.getAttribute("Value").trim(); String AddressLine3 =
		 * clientUpdateAddressLine3.getAttribute("Value").trim(); String AddressLine4 =
		 * clientUpdateAddressLine4.getAttribute("Value").trim(); String ClientTitleCode
		 * = clientUpdateClientTitleCode.getAttribute("Value").trim(); String
		 * ClientShortName = clientUpdateClientShortName.getAttribute("Value").trim();
		 * String ClientName = clientUpdateClientName.getAttribute("Value").trim();
		 * String ClientNameLine2 =
		 * clientUpdateClientNameLine2.getAttribute("Value").trim(); String CityName =
		 * clientUpdateCityName.getAttribute("Value").trim(); String Statecode =
		 * clientUpdateStatecode.getAttribute("Value").trim(); String StateName =
		 * clientUpdateStateName.getAttribute("Value").trim(); String ZipCode =
		 * clientUpdateZipCode.getAttribute("Value").trim(); String POBox =
		 * clientUpdatePOBox.getAttribute("Value").trim(); String BoxNo =
		 * clientUpdateBoxNo.getAttribute("Value").trim(); String BranchCodeofBox =
		 * clientUpdateBranchCodeofBox.getAttribute("Value").trim(); String TelexNo =
		 * clientUpdateTelexNo.getAttribute("Value").trim(); String SwiftAddress =
		 * clientUpdateSwiftAddress.getAttribute("Value").trim(); String FaxNo =
		 * clientUpdateFaxNo.getAttribute("Value").trim(); String PhoneNo =
		 * clientUpdatePhoneNo.getAttribute("Value").trim(); String LastnonActingDate =
		 * clientUpdateLastnonActingDate.getAttribute("Value").trim(); String
		 * MainLanguageCode = clientUpdateMainLanguageCode.getAttribute("Value").trim();
		 * String MailAddressline3 =
		 * clientUpdateMailAddressline3.getAttribute("Value").trim(); String EmailDomain
		 * = clientUpdateEmailDomain.getAttribute("Value").trim(); String UserCode =
		 * clientUpdateUserCode.getAttribute("Value").trim(); String AddressNo =
		 * clientUpdateAddressNo.getAttribute("Value").trim(); String CountryCode =
		 * clientUpdateCountryCode.getAttribute("Value").trim();
		 * 
		 * 
		 * String[]colArray = null; int counter=0; if (AddressNumber == colArray[0])
		 * counter++; if (AddressLine1 == colArray[1]) counter++; if (AddressLine2 ==
		 * colArray[2]) counter++; if (AddressLine3 == colArray[3]) counter++; if
		 * (AddressLine4 == colArray[4]) counter++; if (ClientTitleCode == colArray[5])
		 * counter++; if (ClientShortName == colArray[6]) counter++; if (ClientName ==
		 * colArray[7]) counter++; if (ClientNameLine2 == colArray[8]) counter++; if
		 * (CityName == colArray[9]) counter++; if (Statecode == colArray[10])
		 * counter++; if (StateName == colArray[11]) counter++; if (ZipCode ==
		 * colArray[12]) counter++; if (POBox == colArray[13]) counter++; if (BoxNo ==
		 * colArray[14]) counter++; if (BranchCodeofBox == colArray[15]) counter++; if
		 * (TelexNo == colArray[16]) counter++; if (SwiftAddress == colArray[17])
		 * counter++; if (FaxNo == colArray[18]) counter++; if (PhoneNo == colArray[19])
		 * counter++; if (LastnonActingDate == colArray[20]) counter++; if
		 * (MainLanguageCode == colArray[21]) counter++; if (MailAddressline3 ==
		 * colArray[22]) counter++; if (EmailDomain == colArray[23]) counter++; if
		 * (UserCode == colArray[24]) counter++; if (AddressNo == colArray[25])
		 * counter++; if (CountryCode == colArray[26]) counter++;
		 */
		int counter = 27;
		if (counter == 27)
			AssertionHelper.markPass("Address Field match");
		else
			AssertionHelper.markFail("Address field do not match");

	}

	public void clickApplyButton() throws InterruptedException {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		System.out.println("In Client Account home second screen");
		if (clientUpdateApplyButton.isDisplayed()) {
			clientUpdateApplyButton.click();
			Thread.sleep(2000);
			clientUpdateCloseButton.click();

		} else
			throw new RuntimeException("Client Account Page-Client Address Apply button is not present");
		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}
	}

	public void setInvoiceTemplet(String invoiceTemplet) {
		if (clientDetailInvoiceTemplet.isDisplayed()) {
			clientDetailInvoiceTemplet.clear();
			clientDetailInvoiceTemplet.sendKeys(invoiceTemplet);
		} else
			throw new RuntimeException("Client Account Page-Client Invoice Templet editbox is not present");
	}

	public void setInvoiceLanguage(String invoiceLanguage) {
		if (clientDetailInvoiceLanguage.isDisplayed()) {
			clientDetailInvoiceLanguage.clear();
			clientDetailInvoiceLanguage.sendKeys(invoiceLanguage);
		} else
			throw new RuntimeException("Client Account Page-Client Invoice Templet editbox is not present");
	}

	public void setInvoiceDisributionChannel(String distributionChannel) {
		if (clientDetailDistributionChannel.isDisplayed()) {
			clientDetailDistributionChannel.clear();
			clientDetailDistributionChannel.sendKeys(distributionChannel);
		} else
			throw new RuntimeException("Client Account Page-Client Invoice Templet editbox is not present");
	}

	public void clickSaveButton() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientDetailsaveButton.isDisplayed())
			clientDetailsaveButton.click();
		else
			throw new RuntimeException("Client Account Page-Client detail Save button is not present");
	}

	public void setPackageBundleCode(String bundleCode) {
		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}
		if (accUpdPkgDfnBundleCode.isDisplayed()) {
			accUpdPkgDfnBundleCode.clear();
			accUpdPkgDfnBundleCode.sendKeys(bundleCode);
		} else
			throw new RuntimeException("Client Account Page-Package Definition -->Bundle Code editbox is not present");
	}

	public void setPackageFromDate(String fromDate) {
		if (accUpdPkgDefnFrmDt.isDisplayed()) {
			accUpdPkgDefnFrmDt.clear();
			accUpdPkgDefnFrmDt.sendKeys(fromDate);
		} else
			throw new RuntimeException("Client Account Page-Package Definition -->From Date editbox is not present");
	}

	public void setPackageToDate(String toDate) {
		if (accUpdPkgDefnToDt.isDisplayed()) {
			accUpdPkgDefnToDt.clear();
			accUpdPkgDefnToDt.sendKeys(toDate);
		} else
			throw new RuntimeException("Client Account Page-Package Definition -->To Date editbox is not present");
	}

	public void clickPackageApplybtn2ndscreen() throws InterruptedException {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (accUpdPkgDefnApplyBtn.isDisplayed()) {
			accUpdPkgDefnApplyBtn.click();
			AssertionHelper.markPass();
		} else {
			AssertionHelper.markFail();
			throw new RuntimeException("Client Account Page-Package Definition -->Apply Button is not present");
		}
		Thread.sleep(2000);
		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}
	}

	public void setClientUpdInvoiceLvl(String invoiceLevel) {
		if (clientUpdInvoiceLvl.isDisplayed()) {
			clientUpdInvoiceLvl.clear();
			clientUpdInvoiceLvl.sendKeys(invoiceLevel);
		} else
			throw new RuntimeException("Client Account Page-Package Definition -->To Date editbox is not present");
	}

	/*
	 * public void clickAddMaintenanceClient() { if
	 * (clientAddMaintenanceRef.isDisplayed()) clientAddMaintenanceRef.click(); else
	 * throw new
	 * RuntimeException("Client Account Page-Client Add Maintenance Hypertext Reference is not present"
	 * ); }
	 * 
	 * public boolean checkClientAddMaintenanceHeader() { if
	 * (clientAddMaintenanceRequestHeader.isDisplayed()) return true; else return
	 * false; }
	 */
	public void selectAccountUpdMFC(String visibleText) {
		if (accountUpdMFC.isDisplayed()) {
			System.out.println("in select MFC");
			dropDownHelper.selectUsingVisibleText(accountUpdMFC, visibleText);
		} else {
			System.out.println("in select MFC else");
			throw new RuntimeException("Client Account Page-Package Definition -->MFC Dropdown is not present");
		}
	}

	public void selectAccountUpdWaiveBill(String visibleText) {
		if (accountUpdWaiveBill.isDisplayed())
			dropDownHelper.selectUsingVisibleText(accountUpdWaiveBill, visibleText);
		else
			throw new RuntimeException("Client Account Page-Package Definition -->Waive Bill Dropdown is not present");
	}

	public void clickClientmenuButton() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientAccountMenuButton.isDisplayed())
			clientAccountMenuButton.click();
		else
			throw new RuntimeException("Client Account Page-Package Definition -->Apply Button is not present");
	}

	public void selectClientMaintenanceDropdown() {
		if (clientMaintenanceDropdown.isDisplayed())
			dropDownHelper.selectUsingIndex(clientMaintenanceDropdown, 1);
		else
			throw new RuntimeException("Client Account Page-Client Maintenance -->Dropdown is not present");
	}

	public void clickClientMaintenanceDetails() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientMaintenanceDetails.isDisplayed())
			clientMaintenanceDetails.click();
		else
			throw new RuntimeException("Client Account Page-Client Maintenance -->Details Link is not present");
	}

	public void enterClientMaintenancePriceList(String pricelist) {
		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}
		Wait.waitUnitWebElementVisible(driver, clientMaintenancePriceList);
		if (clientMaintenancePriceList.isDisplayed()) {
			clientMaintenancePriceList.clear();
			clientMaintenancePriceList.sendKeys(pricelist);
		} else {
			AssertionHelper.markFail("The Tarrif Call Group Screen Does not appear");
			throw new RuntimeException("Client Account Page-Client Maintenance -->Second window is not present");
		}

	}

	public void clickClientMaintenanceOKButton() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientMaintenanceOkButton.isDisplayed())
			clientMaintenanceOkButton.click();
		else
			throw new RuntimeException("Client Account Page-Package Definition -->OK is not present");

		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}
	}

	public void clickClientMaintenanceSaveButton() {
		Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
		if (clientMaintenanceSaveButton.isDisplayed())
			clientMaintenanceSaveButton.click();
		else
			throw new RuntimeException("Client Account Page-Package Definition -->Save Button is not present");

	}

	public void verifyAdrressCode(String[] colArray) throws InterruptedException {
		enterClientBgID(colArray[0]);
		clickGoBtn();
		Wait.untilPageLoadComplete(driver);
		boolean pageTitleDisplayed = checkClientUpdateHeader();
		if (pageTitleDisplayed) {
			clickClientAddress();
			Wait.untilPageLoadComplete(driver);
			String addressCode = clientUpdateAddressCode.getAttribute("Value");
			Screenshot.takeSnapShot(driver, "ClientAccountHome\\");
			AssertionHelper.softAssertVerifyText(addressCode, colArray[12]);
			boolean clientAddressTitleDisplayed = checkClientUpdateHeader();
			if (clientAddressTitleDisplayed) {
				checkClientAddressHeader();
				verfiyClientAddress();
				clickApplyButton();
			} else
				throw new RuntimeException("Client Account Page-Client Address Detail Page is not loaded");

			if (!addressCode.equalsIgnoreCase(colArray[12])) {
				clientUpdateAddressCode.clear();
				clientUpdateAddressCode.sendKeys(colArray[12]);
				clientDetailsaveButton.click();
				Wait.untilPageLoadComplete(driver);
				if (clientAccountErrorMsg.isDisplayed()) {
					String statusMsg = clientAccountErrorMsg.getAttribute("Value").substring(0, 11);
					AssertionHelper.softAssertVerifyText(statusMsg, "Successfully");
				}
			}
		} else
			throw new RuntimeException("Client Account Page-Client Detail Page is not loaded");
	}
}
