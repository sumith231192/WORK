package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.VerificationHelper;

import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_Package_Definition_Page {
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	static String TableName = "Package_Definition";
	static String[] testDataValue;

	public BNPP_Package_Definition_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[contains(@id, 'TBD_BUNDLE_CODE')]")
	private WebElement PackageCode_TextBox;
	@FindBy(name = "bundleDefinitions[0].DELETED")
	private WebElement PackageCode_CheckBox;
	@FindBy(xpath = "//input[contains(@id, 'TBD_FROM_DATE')]")
	private WebElement PackageFromDate_Date;
	@FindBy(xpath = "//input[contains(@id, 'TBD_TO_DATE')]")
	private WebElement PackageToDate_Date;
	@FindBy(xpath = "//input[contains(@id, 'TBDD_CHARGE_CODE')]")
	private WebElement PackageChangeCode_TextBox;
	@FindBy(xpath = "//input[contains(@id, 'TBDD_CHARGE_CODE_DESC')]")
	private WebElement PackageChangeCodeDec_TextBox;
	@FindBy(name = "bundleDefinitions[0].details[0].DELETED")
	private WebElement PackageChangeCodeDecCheckBox_CheckBox;
	@FindBy(xpath = "//button[contains(@name, 'ADD_CHARGE_CODES')]")
	private WebElement AddChargeCode_Button;
	@FindBy(name = "BUNDLE_DEFINITION_COMMON.ADD_DETAILS")
	private WebElement DeleteChargeCode_Button;
	@FindBy(name = "BUNDLE_DEFINITION_COMMON.DELETE")
	private WebElement DeleteDetails_Button;
	@FindBy(name = "BUNDLE_DEFINITION_COMMON.COPY")
	private WebElement CoppyDetails_Button;
	@FindBy(id = "SaveBtn")
	private WebElement Save_Button;
	@FindBy(id = "ClearBtn")
	private WebElement Clear_Button;
	@FindBy(className = "message-header")
	private WebElement messgaeHead_Message;

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Package_Code,Description,From_Date,To_Date,Charge_Code,Charge_Code_Description";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void definePakageCode(String condition) throws Exception {

		String[] exelData = BNPP_BookingCancellation_Page.getTestData(condition);

		String packageCode = exelData[0];
		String fromDate = exelData[1];
		String toDate = exelData[2];

		Wait.waitUnitWebElementVisible(driver, PackageCode_TextBox);
		PackageCode_TextBox.sendKeys(packageCode);
		Wait.waitUnitWebElementVisible(driver, PackageChangeCodeDec_TextBox);
		PackageChangeCodeDec_TextBox.click();
		System.out.println(PackageChangeCodeDec_TextBox.getText());
		PackageFromDate_Date.sendKeys(fromDate);
		PackageToDate_Date.sendKeys(toDate);
	}

	public void definePakageChagecode(String condition) throws Exception

	{
		String[] exelData = BNPP_BookingCancellation_Page.getTestData(condition);
		String chargeCode = exelData[0];
		PackageChangeCode_TextBox.sendKeys(chargeCode);
		Wait.waitUnitWebElementVisible(driver, PackageChangeCodeDec_TextBox);
		System.out.println(PackageChangeCodeDec_TextBox.getText());
	}

	public void savePackageDefinition() {
		Wait.untilPageLoadComplete(driver);
		Wait.waitUnitWebElementVisible(driver, Save_Button);
		Save_Button.click();
		Save_Button.click();
		if (messgaeHead_Message.getText().contains("Successfully saved Record(s)")) {
			AssertionHelper.markPass();
		} else {
			AssertionHelper.markFail();
		}
	}
}
