package pageObject;



import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import utility.ConfigFileReader;
import utility.ExcelUtils;

public class BNPP_ShellJobs{

	ConfigFileReader configFileReader = new ConfigFileReader();
	
	
	
	public String[] getTestData(String condition) throws Exception {
		String RowNum = "1";
		String Col = "Shell_Command";
		String TableName = "Shell_Scripts";
		ExcelUtils.setExcelFile(configFileReader.getValue("DATAEXCEL"));
		String[] colArray = ExcelUtils.getCellData(RowNum, Col, TableName, condition);
		return colArray;

	}

	public void getUnixConnection(String shellScript) 
	{
		String host = configFileReader.getUnixHostName();
		String user = configFileReader.getUnixUserId();
		String password =configFileReader.getUnixPassword();
		try {

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			Session session = jsch.getSession(user, host, 22);
			session.setPassword(password);
			session.setConfig(config);
			session.connect();
			Channel channel = null;

			List<String> listCommands = new ArrayList<String>();
			listCommands.add(shellScript);
			/*if(!commtLine.equals(null))
			{
			listCommands.add(commtLine);
			AssertionHelper.markPass("PASS: CMD exicuted");
			}
			else
			{
				AssertionHelper.markFail("Fail: Please Eneter the Comment Fpor TC");
			}*/

			for (String command : listCommands) {
				System.out.println("executing command::" + command);
				channel = session.openChannel("exec");
				System.out.println(channel);
				((ChannelExec) channel).setCommand(shellScript);
				channel.setInputStream(null);
				((ChannelExec) channel).setErrStream(System.err);
				InputStream in = channel.getInputStream();
				channel.connect();
				byte[] tmp = new byte[1024];
				while (true) {
					while (in.available() > 0) {
						int i = in.read(tmp, 0, 1024);
						if (i < 0)
							break;
						System.out.print(new String(tmp, 0, i));
					}
					if (channel.isEOF()) {
						System.out.println("exit-status: " + channel.getExitStatus());
						break;
					}
				}
			}

			channel.disconnect();
			session.disconnect();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
