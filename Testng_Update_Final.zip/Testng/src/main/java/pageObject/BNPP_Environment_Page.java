package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import utility.ConfigFileReader;

public class BNPP_Environment_Page {
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
		
	public BNPP_Environment_Page(WebDriver driver) {		 
		 this.driver = driver;
		 PageFactory.initElements(driver, this);		 		
	}
	
	@FindBy(name = "OFFICE")
	private WebElement branch_DropDown;
	
	@FindBy(xpath = "//input[@alt='Submit Form']" )
	private WebElement login_Button_Envpage;
	
	@FindBy(name = "ENVIRONMENT")
	private WebElement environment_DropDown;
	
	public void navigateToBNPP_Home_Page()
	{
		branch_DropDown.sendKeys(configFileReader.getBranch());
		environment_DropDown.sendKeys(configFileReader.getOffice());
		login_Button_Envpage.click();		
	}
		
	public String getTitle(WebDriver driver)
	{
		String title = driver.getTitle();
		return title ;
	}
}
