package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_ClientHierarchy_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	static String[] testDataValue;

	public BNPP_ClientHierarchy_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(), 'Client Hierarchy')]")
	private WebElement ClientHierarchy_Label;

	@FindBy(id = "CM_CUST_ID")
	private WebElement ClientID_BGID_TextBox;

	@FindBy(id = "AS_ON_DATE")
	private WebElement AsOnDate_TextBox;

	@FindBy(id = "PM_PHONE_NO")
	private WebElement Account_ID_txtbox;

	@FindBy(id = "HIER_VIEW")
	private WebElement Hierarchy_view_dropdown;

	@FindBy(name = "COMMON.LOAD_LOCAL_BUTTON")
	private WebElement Local_Hierarchy_Button;

	@FindBy(name = "COMMON.BUTTON_CLEAR")
	private WebElement Clear_Button;

	@FindBy(name = "COMMON.BUTTON_EXPORT")
	private WebElement Export_Button;
	
	@FindBy(id = "PM_PHONE_NO")
	private WebElement AccountID_TextBox;

	@FindBy(xpath = "//caption[contains(text(),'Client View - Local Hierarchy')]//following::table[1]")
	private WebElement Local_Hierarchy_Table;
		
	@SuppressWarnings("static-access")
	public void ckeckClientHierarchyLabelDisplayed() {
		if (verificationHelper.isDisplayed(ClientHierarchy_Label)) {
			Screenshot.takeSnapShot(driver, "ClientHierarchy\\");
			AssertionHelper.markPass("Client Hierarchy Label is Displaying Successfully.");
		} else {
			assertionHelper.markFail();
		}
	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String TableName = "Client_Hierarchy";
		String column = "Client_ID_BG_ID,Account_ID,Hierarchy_view";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void EnterClientHierarchyDetails(String condition) throws Exception {
		BNPP_ClientHierarchy_Page.getTestData(condition);

		String ClientIDBGID = testDataValue[0];
		String AccountID = testDataValue[1];
		String Hierarchyview = testDataValue[2];
		

		ClientID_BGID_TextBox.sendKeys(ClientIDBGID);
		AsOnDate_TextBox.clear();
		//long AsOnDate = System.currentTimeMillis();
		///AsOnDate_TextBox.sendKeys(AsOnDate);
		AccountID_TextBox.sendKeys(AccountID);
		dropDownHelper.selectUsingVisibleText(Hierarchy_view_dropdown, Hierarchyview);
		Screenshot.takeSnapShot(driver, "ClientHierarchy\\");
		Local_Hierarchy_Button.click();
		Wait.untilPageLoadComplete(driver);
	}

	@SuppressWarnings("static-access")
	public void VerifyLocalHierarchyDisplayed() {
		if (verificationHelper.isDisplayed(Local_Hierarchy_Table)) {
			Screenshot.takeSnapShot(driver, "ClientHierarchy\\");
			AssertionHelper.markPass("Local Hierarchy Table is Displaying Successfully.");
		} else {
			assertionHelper.markFail("Local Hierarchy Table is not Displaying");
		}
	}

}
