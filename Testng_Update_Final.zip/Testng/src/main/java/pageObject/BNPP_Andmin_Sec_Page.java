package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.VerificationHelper;
import utility.ConfigFileReader;

public class BNPP_Andmin_Sec_Page {
	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	VerificationHelper verificationHelper = new VerificationHelper(driver);


	public BNPP_Andmin_Sec_Page(WebDriver driver) {
		 
		 this.driver = driver;
		 PageFactory.initElements(driver, this);	
	}
	
	@FindBy(id = "paramRecords_0__TSC_SECURITY_ID")
	private WebElement Security_TextBox;
	
	@FindBy(id = "paramRecords_0__TSC_DESCRIPTION")
	private WebElement SecurityDescription_TextBox;
	
	@FindBy (id= "paramRecords_0__TSC_PROF_DEFN_YN")
	private WebElement SecurityProfileDescription_DropDown;
	
	@FindBy(id = "paramRecords_0__TSC_TYPE")
	private WebElement SerurityType;
	
	@FindBy(className = "message-header")
	private WebElement MessageHead;
	
	
	
	@FindBy(id= "SaveBtn")
	private WebElement Save_Button;
	
	
	
	public void createSecurityCode(String SecID,String Des, String ProfiDe, String SecType)
	{
		Security_TextBox.sendKeys(SecID);
		SecurityDescription_TextBox.sendKeys(Des);
		dropDownHelper.selectUsingVisibleText(SecurityProfileDescription_DropDown, ProfiDe);
		dropDownHelper.selectUsingVisibleText(SerurityType, SecType);
		Save_Button.click();
	}
	public void validateCreation()
	{
		
		if(verificationHelper.isDisplayed(MessageHead))
		{
			System.out.println(MessageHead.getText());
			if(MessageHead.getText().contains("Successfully saved Record(s) "))
			{
			assertionHelper.markPass();
			}
			else
			{
				assertionHelper.markFail();
			}
			
		}
		else
		{
			System.out.println("Not able to fond ele");
			
		}
	}

}
