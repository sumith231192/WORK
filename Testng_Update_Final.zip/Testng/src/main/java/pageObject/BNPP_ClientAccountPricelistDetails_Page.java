package pageObject;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AlertHelper;
import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import helper.WindowHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_ClientAccountPricelistDetails_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	AlertHelper alerthelper = new AlertHelper(driver);
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	WindowHelper switchWindow =new WindowHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	static String[] testDataValue;

	public BNPP_ClientAccountPricelistDetails_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(), 'Client Account Pricelist Details')]")
	private WebElement ClientAccountPricelistDetails_Label;

	@FindBy(xpath = "//a[contains(text(), 'Filter')]")
	private WebElement Filter_Link;

	@FindBy(name = "FilterColumn")
	private WebElement FilterColumn_DropDown;

	@FindBy(name = "FilterOperator")
	private WebElement FilterOperator_DropDown;

	@FindBy(name = "FilterValue")
	private WebElement FilterValue_TextBox;

	@FindBy(name = "FilterAdd")
	private WebElement Filter_Add_Button;

	@FindBy(name = "FilterClearAll")
	private WebElement Filter_Clear_Button;

	@FindBy(name = "B12")
	private WebElement Filter_Search_Button;

	@FindBy(xpath = "//table[@summary='Customer Account Pricelist']/tbody/tr[2]/td[8]")
	private WebElement Rate_Link;

	@FindBy(id = "editvariation_0__TV_PRICING_TEMPLATE")
	private WebElement Methodology_TextBox;

	@FindBy(id = "editvariation_0__TV_FROM_DATE")
	private WebElement From_Date_TextBox;

	@FindBy(id = "editvariation_0__TV_TO_DATE")
	private WebElement To_Date_TextBox;

	@FindBy(id = "editvariation_0__TV_TARIFF_CLASS")
	private WebElement Package_TextBox;

	@FindBy(id = "editvariation_0__methodologyTO_tariffScheme_TS_CR_DB")
	private WebElement Credit_Debit_DropDown;

	@FindBy(id = "editvariation_0__methodologyTO_tariffScheme_TS_USAGE_DATA")
	private WebElement Based_On_DropDown;

	@FindBy(id = "editvariation_0__methodologyTO_callScheme_TC_MIN_CHARGE")
	private WebElement Minimum_Charge_TextBox;

	@FindBy(id = "editvariation_0__methodologyTO_callScheme_TC_MAX_CHARGE")
	private WebElement Maximum_Charge_TextBox;

	@FindBy(id = "editvariation_0__methodologyTO_callScheme_TC_CUM_TYPE")
	private WebElement Computation_Model_DropDown;

	@FindBy(xpath = "editvariation_0__methodologyTO_callScheme_TC_RATE_TYPE")
	private WebElement Rate_Type_DropDown;

	@FindBy(id = "editvariation_0__methodologyTO_callScheme_details_0__TCR_NOP_LOWER")
	private static WebElement Tier_From_TextBox;

	@FindBy(id = "editvariation_0__methodologyTO_callScheme_details_0__TCR_NOP")
	private static WebElement Tier_To_TextBox;

	@FindBy(id = "editvariation_0__methodologyTO_callScheme_details_0__TCR_RATE")
	private static WebElement Rate_TextBox;

	@FindBy(name = "COMMON.ADD_DETAILS")
	private static WebElement Add_Button;

	@FindBy(name = "COMMON.SAVE")
	private WebElement Save_Button;
	
	@FindBy(name = "COMMON.CLOSE")
	private WebElement Close_Button;
	
	@FindBy(xpath = "//table[@summary='Customer Account Pricelist']")
	private WebElement ClientAccountPricelistDetails_Table;

	@SuppressWarnings("static-access")
	public void ckeckClientAccountPricelistDetailsLabelDisplayed() {
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");
		if (verificationHelper.isDisplayed(ClientAccountPricelistDetails_Label)) {
			assertionHelper.markPass();
		} else {
			assertionHelper.markFail();
		}
	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Personalised,Inheritance_Level,Price_List_ID,Charge_Code,Description,Tier_From,Tier_To,Rate,Methodology,Methodology_Description,Package,Minimum_Charge,Maximum_Charge,Pricing_Currency,From_Date,To_Date";
		String TableName = "Client_Account_Pricelist";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		System.out.println(testDataValue[0]);
		return testDataValue;
	}

	public static String[] getDropdownIndexValue(String condition) throws Exception {
		String RowNo = "1";
		String column = "Client_BG_ID,Account_ID,From_Date,To_Date,Description,Package,Charge_Code";
		String TableName = "Client_Account_Pricelist";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		System.out.println(testDataValue[0]);
		return testDataValue;
	}

	public void FilterForPricelistDetails(String condition) throws Exception {
		String[] excelData = BNPP_ClientAccountPricelistDetails_Page.getDropdownIndexValue(condition);
		Filter_Link.click();
		Wait.waitUnitWebElementVisible(driver, Filter_Clear_Button);
		Filter_Clear_Button.click();
		for (int index = 0; index <= 6; index++) {
			Wait.waitUnitWebElementVisible(driver, FilterColumn_DropDown);
			dropDownHelper.selectUsingIndex(FilterColumn_DropDown, index);
			Wait.waitUnitWebElementVisible(driver, FilterValue_TextBox);
			FilterValue_TextBox.sendKeys(excelData[index]);

			Filter_Add_Button.click();
		}
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");
		Wait.waitUnitWebElementVisible(driver, Filter_Search_Button);
		Filter_Search_Button.click();
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");
			
	}

	public void ClientAccountPricelistDetailsCreationORUpdate(String condition) throws Exception {
		String[] excelData = BNPP_ClientAccountPricelistDetails_Page.getTestData(condition);
		Wait.waitUnitWebElementVisible(driver, Rate_Link);
		Rate_Link.click();
		Set<String> windows = driver.getWindowHandles();
		for (String child : windows) {
			System.out.println(child);
			driver.switchTo().window(child);
		}	
		//Wait.waitUnitWebElementVisible(driver, Methodology_TextBox);
		//Methodology_TextBox.clear();
		//Wait.waitUnitWebElementVisible(driver, Methodology_TextBox);
		//Methodology_TextBox.sendKeys(excelData[8]);
		//From_Date_TextBox.sendKeys();
		//To_Date_TextBox.sendKeys();
		//Package_TextBox.sendKeys();
		//dropDownHelper.selectUsingVisibleText(Credit_Debit_DropDown, "");
		//dropDownHelper.selectUsingVisibleText(Based_On_DropDown, "");
		//Minimum_Charge_TextBox.sendKeys();
		//Maximum_Charge_TextBox.sendKeys();
		//dropDownHelper.selectUsingVisibleText(Computation_Model_DropDown, "");
		//dropDownHelper.selectUsingVisibleText(Rate_Type_DropDown, "");
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");
		Thread.sleep(5000);
		BNPP_ClientAccountPricelistDetails_Page.AddTransactionRate(driver, condition, excelData);
		//BNPP_ClientAccountPricelistDetails_Page.AddButton().click();
		//BNPP_ClientAccountPricelistDetails_Page.AddTransactionRate(driver, condition, excelData);
		Wait.waitUnitWebElementVisible(driver, Save_Button);
		Actions action = new Actions(driver);
		action.doubleClick(Save_Button).perform();		
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");
		Thread.sleep(5000);
		Alert alert = driver.switchTo().alert();
		Thread.sleep(5000);
		alert.accept();
		Thread.sleep(5000);
		//Close_Button.click();
		driver.switchTo().defaultContent();
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");
	}

	public static void AddTransactionRate(WebDriver driver, String condition, String[] excelData) throws Exception {
		Wait.waitUnitWebElementVisible(driver, Tier_From_TextBox);
		Tier_From_TextBox.clear();
		Tier_From_TextBox.sendKeys(excelData[5]);
		Wait.waitUnitWebElementVisible(driver, Tier_To_TextBox);
		Tier_To_TextBox.clear();
		Tier_To_TextBox.sendKeys(excelData[6]);
		Wait.waitUnitWebElementVisible(driver, Rate_TextBox);
		Rate_TextBox.clear();
		Rate_TextBox.sendKeys(excelData[7]);
		Screenshot.takeSnapShot(driver, "ClientAccountPricelistDetails\\");		
	}

	public static WebElement AddButton() {
		return Add_Button;
	}

	@SuppressWarnings("static-access")
	public void CheakClientAccountPricelistDetailsView() {
		if (verificationHelper.isDisplayed(ClientAccountPricelistDetails_Table)) {
			assertionHelper.markPass();
		} else {
			assertionHelper.markFail();
		}

	}

}
