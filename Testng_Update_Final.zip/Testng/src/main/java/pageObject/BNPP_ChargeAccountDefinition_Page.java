package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;

public class BNPP_ChargeAccountDefinition_Page {

	WebDriver driver;
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	ConfigFileReader configFileReader = new ConfigFileReader();
	AssertionHelper assertionHelper = new AssertionHelper();
	static String[] testDataValue;

	public BNPP_ChargeAccountDefinition_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(), 'Charge Account Definition')]")
	private WebElement ChargeAccountDefinition_Label;

	@FindBy(id = "details_0__EAD_BG_ID")
	private WebElement Business_Group_TextBox;

	@FindBy(id = "details_0__EAD_CUST_ID")
	private WebElement Client_TextBox;

	@FindBy(id = "details_0__EAD_OPER_PH_NO")
	private WebElement Operational_Account_TextBox;

	@FindBy(id = "details_0__EAD_EXP_PH_NO")
	private WebElement Charge_Account_TextBox;

	@FindBy(id = "details_0__EAD_FROM_DATE")
	private WebElement From_Date_TextBox;

	@FindBy(id = "details_0__EAD_TO_DATE")
	private WebElement To_Date_TextBox;

	@FindBy(name = "COMMON.ADD_DETAILS")
	private WebElement Add_Button;

	@FindBy(name = "SaveButton")
	private WebElement Save_Button;

	@SuppressWarnings("static-access")
	public void ckeckChargeAccountDefinitionLabelDisplayed() {
		Screenshot.takeSnapShot(driver, "ChargeAccountDefinition\\");
		if (verificationHelper.isDisplayed(ChargeAccountDefinition_Label)) {
			assertionHelper.markPass();
		} else {
			assertionHelper.markFail();
		}
	}
	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Business_Group,Client,Operational_Account,Charge_Account,From_Date,To_Date";
		String TableName = "Charge_Account_Definition";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void EnterDataForChargeAccountDefinition(String condition) throws Exception {
		String[] excelData = BNPP_ChargeAccountDefinition_Page.getTestData(condition);
		
		String BusinessGroup = excelData[0];
		String Client = excelData[1];
		String OperationalAccount = excelData[2];
		String ChargeAccount = excelData[3];
		String FromDate = excelData[4];
		String ToDate = excelData[5];
		Business_Group_TextBox.sendKeys(BusinessGroup);
		Client_TextBox.sendKeys(Client);
		Operational_Account_TextBox.sendKeys(OperationalAccount);
		Charge_Account_TextBox.sendKeys(ChargeAccount);
		From_Date_TextBox.sendKeys(FromDate);
		To_Date_TextBox.sendKeys(ToDate);
		Screenshot.takeSnapShot(driver, "ChargeAccountDefinition\\");
	}

	public WebElement AddButton() {
		return Add_Button;
	}

	public WebElement SaveButton() {
		return Save_Button;
	}

}
