package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


import utility.ConfigFileReader;
import utility.Wait;

public class BNPP_Home_Page {

	WebDriver driver;
	ConfigFileReader configFileReader;
	Wait wait;

	public BNPP_Home_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//input[@class=' x-form-text x-form-field x-form-empty-field']")
	private WebElement FindPage_TextBox;

	@FindBy(linkText = "Transaction Home")
	private WebElement TransactionHome_Link;
	
	@FindBy(linkText = "Transaction home")
	private WebElement TransactionHome2_Link;

	@FindBy(linkText = "Manual Settlements")
	private WebElement ManualSettlements_Link;

	@FindBy(linkText = "Payment Cancellatio")
	private WebElement PaymentCancellatio_Link;

	@FindBy(xpath= "//*[@class=' x-btn-text searchIcn']")
	private WebElement Search_Button;
	
	@FindBy(xpath= "//*[@class=' x-btn-text clearIcn']")
	private WebElement reset_Button;
	 
	@FindBy(linkText = "Create")
	private WebElement Create_Link;

	@FindBy(linkText = "View")
	private WebElement View_Link;

	@FindBy(xpath = "//*[@class=' x-btn-text icon-collapse-all']")
	private WebElement Collapse_Button;

	@FindBy(linkText = "File Upload")
	private WebElement FileUplod_Link;
	
	@FindBy(linkText = "Administration Home")
	private WebElement AdministrationHome_Link;
	
	@FindBy (xpath = "Security Codes")
	private WebElement SecurityCodes_Link;
	
	@FindBy (xpath = "//span[text()='Manual Billable Events']//preceding::img[2]")
	private WebElement ManualBillableEvents_Link;
	
	@FindBy (xpath = "//span[text()='Parameter Home']//preceding::img[2]")
	private WebElement ParameterHome_Link;
	
	@FindBy (xpath = "//span[text()='Charge Account Definition']//preceding::img[2]")
	private WebElement ChargeAccountDefinition_Link;
	
	@FindBy (xpath = "(//span[text()='Pricing Home']//preceding::img[2])[1]")
	private WebElement PricingHome_Link;
	
	@FindBy (xpath = "(//span[text()='Pricing Home']//preceding::img[2])[2]")
	private WebElement PricingHome2_Link;
	
	@FindBy (xpath = "//span[text()='Client Account Pricelist Details']//preceding::img[2]")
	private WebElement ClientAccountPricelistDetails_Link;
	
	@FindBy (xpath = "//span[text()='Enquiry Home']//preceding::img[2]")
	private WebElement EnquiryHome_Link;
	
	@FindBy (xpath = "//span[text()='Client Hierarchy']//preceding::img[2]")
	private WebElement ClientHierarchy_Link;
	
	@FindBy (xpath = "//span[text()='Invoice Home']//preceding::img[2]")
	private WebElement InvoicingHome_Link;
	
	@FindBy (xpath = "//span[text()='Officer Adjustments - Debit']//preceding::img[2]")
	private WebElement OfficerAdjustmentsDebit_Link;
	
	@FindBy (xpath = "//span[text()='Bill Details']//preceding::img[2]")
	private WebElement BillDetail_Link;
	
	@FindBy(linkText = "Client/Account Home")
	private WebElement ClientAccountHome_Link;
	
	@FindBy(linkText = "Subscription Setup")
	private WebElement SubscriptionSetup_Link;
	
	@FindBy(xpath = "//*[@class=' x-btn-text clearIcn']")
    private WebElement Reset_Button;
	
	@FindBy(linkText = "Booking Cancellation")
	private WebElement Booking_Cancellation_Link;
	
	@FindBy(linkText = "Invoice Home")
	private WebElement Invoice_Home_Link;
	
	@FindBy(linkText = "Package Definition")
	private WebElement PackageDefinition_Link;
	
	@FindBy(linkText = "Standard Pricelist Definition")
	private WebElement Standard_Pricelist_Definition_Link;
	
	@FindBy(linkText = "Transaction Consolidation Frequency Setup")
	private WebElement Transaction_Consolidation_Frequency_Setup_Link;
	
	@FindBy(linkText = "Standard Pricelist")
	private WebElement StandardPricelistLink;
	
	
	public void navigateTo_BNPP_TransactionConsolidationFrequency_Page(String options) {

		Collapse_Button.click();
		FindPage_TextBox.sendKeys("Transaction Consolidation");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, PricingHome_Link);
		PricingHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, Transaction_Consolidation_Frequency_Setup_Link);
		Transaction_Consolidation_Frequency_Setup_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();
		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
	}
	
	public void navigateTo_BNPP_StandardPricelisDefinition_Page(String options) {
		
		Collapse_Button.click();
		FindPage_TextBox.sendKeys("Standard Pricelist");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, PricingHome_Link);
		PricingHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, Standard_Pricelist_Definition_Link);
		Standard_Pricelist_Definition_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();
		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();

		}
	}
	
	public void navigateTo_BPNPP_PackageDefinition_Page(String options) {
		Collapse_Button.click();
		FindPage_TextBox.sendKeys("Package Definition");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, PricingHome_Link);
		PricingHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, PackageDefinition_Link);
		PackageDefinition_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();
		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
	}
	
	public void navigateTo_BNPP_Booking_Cancellation_Page() {
		Collapse_Button.click();

		FindPage_TextBox.sendKeys("Booking Cancellation");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, Invoice_Home_Link);
		Invoice_Home_Link.click();
		Wait.waitUnitWebElementVisible(driver, Booking_Cancellation_Link);
		Booking_Cancellation_Link.click();
	}
	
	public void navigateToSubscription(String options) throws InterruptedException {
		Wait.waitUnitWebElementVisible(driver, Collapse_Button);
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, FindPage_TextBox);
		FindPage_TextBox.sendKeys("Subscription");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, TransactionHome2_Link);
		
		if (TransactionHome2_Link.isDisplayed()) {
			System.out.println("In Transaction Home");
			TransactionHome2_Link.click();
			Thread.sleep(2000);
			Wait.waitUnitWebElementVisible(driver, SubscriptionSetup_Link);
			if(SubscriptionSetup_Link.isDisplayed()) 
				SubscriptionSetup_Link.click();
	    }
		
		if (options.toUpperCase().equals("CREATE")) 
			Create_Link.click();
		else if (options.toUpperCase().equals("VIEW")) 
			View_Link.click();
		
		
	}
	
	public void navigateToClientAccountHome() {
		Wait.waitUnitWebElementVisible(driver, Collapse_Button);
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, FindPage_TextBox);
		FindPage_TextBox.sendKeys("Client/Account");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, ClientAccountHome_Link);
		if (ClientAccountHome_Link.isDisplayed()) 
			ClientAccountHome_Link.click();
		else { Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, ClientAccountHome_Link);
		ClientAccountHome_Link.click();
		}
	}
	
	public void navigateToBNPP_ManualSettlements_Page(String options) {
		Collapse_Button.click();
		FindPage_TextBox.sendKeys("Manual Settlements");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, TransactionHome_Link);
		TransactionHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, ManualSettlements_Link);
		ManualSettlements_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
	}

	public void navigateToBNPP_FileUpload_Page(String options) {

		Collapse_Button.click();

		FindPage_TextBox.sendKeys("File Upload");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, TransactionHome_Link);
		TransactionHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, FileUplod_Link);
		FileUplod_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}

	}
	
	public void navigateToBNPP_AdministrationHome_Page(String options )
	{
		Collapse_Button.click();
		FindPage_TextBox.sendKeys("Security Codes");
		Wait.waitUnitWebElementVisible(driver, Search_Button);
		Search_Button.click();
		Wait.waitUnitWebElementVisible(driver, AdministrationHome_Link);
		AdministrationHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, SecurityCodes_Link);
		SecurityCodes_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		
	}
	
	public void navigateToBNPP_ManualBillableEvents_Page(String options) {
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, TransactionHome2_Link);
		TransactionHome2_Link.click();
		Wait.waitUnitWebElementVisible(driver, ManualBillableEvents_Link);
		ManualBillableEvents_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		
	}
	public void navigateToBNPP_BillDetail_Page(String options) throws InterruptedException {
		Wait.waitUnitWebElementVisible(driver, Collapse_Button);
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, EnquiryHome_Link);
		EnquiryHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, BillDetail_Link);
		if (BillDetail_Link.isDisplayed())
		BillDetail_Link.click();
		else {
			EnquiryHome_Link.click();
			Wait.waitUnitWebElementVisible(driver, BillDetail_Link);
			BillDetail_Link.click();
		}		
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			Thread.sleep(5000);
			View_Link.click();
		}
		
	}
	public void navigateToBNPP_ChargeAccountDefinition_Page(String options) {
		Wait.waitUnitWebElementVisible(driver, Collapse_Button);
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, ParameterHome_Link);
		ParameterHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, ChargeAccountDefinition_Link);
		System.out.println("Charge account visible");
		if (ChargeAccountDefinition_Link.isDisplayed())
			ChargeAccountDefinition_Link.click();
		else {
			ParameterHome_Link.click();
			Wait.waitUnitWebElementVisible(driver, ChargeAccountDefinition_Link);
			ChargeAccountDefinition_Link.click();
		}
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		else System.out.println("View/Create not found");
		
	}
	public void navigateToBNPP_ClientAccountPricelistDetailsNORWAY_Page(String options) {
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, PricingHome_Link);
		PricingHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, ClientAccountPricelistDetails_Link);
		ClientAccountPricelistDetails_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		
	}
	public void navigateToBNPP_ClientAccountPricelistDetailsATADMIN_Page(String options) {
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, PricingHome2_Link);
		PricingHome2_Link.click();
		Wait.waitUnitWebElementVisible(driver, ClientAccountPricelistDetails_Link);
		ClientAccountPricelistDetails_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		
	}
	public void navigateToBNPP_ClientHierarchy_Page(String options) {
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, EnquiryHome_Link);
		EnquiryHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, ClientHierarchy_Link);
		ClientHierarchy_Link.click();
		Wait.untilPageLoadComplete(driver);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		
	}
	public void navigateToBNPP_OfficerAdjustmentsDebit_Page(String options) {
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, InvoicingHome_Link);
		InvoicingHome_Link.click();
		Wait.waitUnitWebElementVisible(driver, OfficerAdjustmentsDebit_Link);
		OfficerAdjustmentsDebit_Link.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
		
	}
	
	public void navigateToBNPP_StandardPricelist(String options) {
		Collapse_Button.click();
		Wait.waitUnitWebElementVisible(driver, PricingHome2_Link);
		PricingHome2_Link.click();
		System.out.println("Pricing home Clicked");
		Wait.waitUnitWebElementVisible(driver, StandardPricelistLink);
		StandardPricelistLink.click();
		Wait.waitUnitWebElementVisible(driver, Create_Link);
		if (options.toUpperCase().equals("CREATE")) {
			Create_Link.click();

		} else if (options.toUpperCase().equals("VIEW")) {
			View_Link.click();
		}
	}

}
