package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_BillDetail_Page {
	WebDriver driver;
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	ConfigFileReader configFileReader = new ConfigFileReader();
	static String[] testDataValue;

	public BNPP_BillDetail_Page(WebDriver driver) {		 
		 this.driver = driver;
		 PageFactory.initElements(driver, this);	
	}

	@FindBy(xpath = "//label[contains(text(), 'Bill Details')]")
	private WebElement  BillDetail_Label;
	
	@FindBy(id = "BL_BILL_NO")
	private WebElement Bill_Number_TextBox; 
	
	@FindBy(id = "CM_CUST_ID")
	private WebElement Client_BG_ID_TextBox;
	
	@FindBy(id = "BL_SUBSCRIBER_ID")
	private WebElement Account_ID_TextBox; 
	
	@FindBy(id = "BILL_USER4")
	private WebElement Booking_Reference_TextBox; 
	
	@FindBy(name = "BILL_ENQ_COMMON.BUTTON_SEARCH")
	private WebElement Search_Button;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[14]/a[text()='detail']")
	private WebElement Details_Button;
	
	@FindBy(xpath = "//caption[contains(text(), 'Bill Details - Quick Summary')]")
	private WebElement Bill_Details_Quick_Summary;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[1]/span/input")
	private WebElement Bill_Number;	
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[8]/span/input")
	private WebElement Booking_Reference;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[2]/span/input")
	private WebElement Bill_Date;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[3]")
	private WebElement Status;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[4]/span/input")
	private WebElement Currency;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[5]/span/input")
	private WebElement Bill_Amount;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[6]/span/input")
	private WebElement Amt_in_IBC;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[7]/span/input")
	private WebElement Client_Name;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[9]/span/input")
	private WebElement Charge_Account;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[10]/span/input")
	private WebElement Booking_Cancellation_Status;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[11]")
	private WebElement Invoice_Type;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[12]/span/input")
	private WebElement Corrected_Booking_Reference;
	
	@FindBy(xpath = "//table[@summary='BILLSEARCH.SMRY_RIGHT_PANE']/tbody/tr[1]/td[13]/span/input")
	private WebElement Intraday_Vacation;
	
	@FindBy(xpath = "//label[contains(text(),'Account Level Summary')]")
	private WebElement Account_Level_Summary;
		
	@FindBy(xpath = "//a[contains(text(),'Account Summary')]")
	private WebElement Account_Summary_Link;
	
	@FindBy(xpath = "//*[contains(text(),'Grand Total')]")
	private WebElement Grand_Total_Label;
	
	@SuppressWarnings("static-access")
	public void ckeckBillDetailLabelDisplayed() {
		if (verificationHelper.isDisplayed(BillDetail_Label)) {
			Screenshot.takeSnapShot(driver, "BillDetails\\");
			AssertionHelper.markPass("Bill Details Label is Displaying Successfully.");
		} else {
			assertionHelper.markFail("Bill Details Page is not Displaying Successfully.");
		}
	}
	
	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String TableName = "Bill_Details";
		String column = "Bill_Number,Client_ID,Account_ID,Booking_Reference,Charge_Code,Volume,Bill_Date,Status,Currency,Bill_Amount,Amt_in_IBC,Client_Name,Charge_Account,Booking_Cancellation_Status,Invoice_Type,Corrected_Booking_Reference,Intraday_Vacation";
		
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void SearchBillDetails(String condition) throws Exception {
		BNPP_BillDetail_Page.getTestData(condition);

		String BillNumber = testDataValue[0];
		String ClientID = testDataValue[1];
		String AccountID = testDataValue[2];
		String BookingReference = testDataValue[3];
		
		Bill_Number_TextBox.sendKeys(BillNumber); 
		Client_BG_ID_TextBox.sendKeys(ClientID);
		Account_ID_TextBox.sendKeys(AccountID); 
		Booking_Reference_TextBox.sendKeys(BookingReference); 
		Search_Button.click();
		Wait.untilPageLoadComplete(driver);
		Thread.sleep(3000);
		Wait.waitUnitWebElementVisible(driver, Details_Button);
		Details_Button.click(); 
		Screenshot.takeSnapShot(driver, "BillDetails\\");
	}
	@SuppressWarnings("static-access")	
	public void VerifyBillDetails(String condition) throws Exception {
		String[] excelData = BNPP_BillDetail_Page.getTestData(condition);
		Screenshot.takeSnapShot(driver, "BillDetails\\");
		if (excelData[0].equalsIgnoreCase(Bill_Number.getAttribute("value"))
				&& excelData[3].equalsIgnoreCase(Booking_Reference.getAttribute("value"))
				&& excelData[6].equalsIgnoreCase(Bill_Date.getAttribute("value"))
				&& excelData[7].equalsIgnoreCase(Status.getText())
				&& excelData[8].equalsIgnoreCase(Currency.getAttribute("value"))
				&& excelData[9].equalsIgnoreCase(Bill_Amount.getAttribute("value"))
				&& excelData[10].equalsIgnoreCase(Amt_in_IBC.getAttribute("value"))
				&& excelData[11].equalsIgnoreCase(Client_Name.getAttribute("value")))				
				//&& excelData[12].equalsIgnoreCase(Charge_Account.getAttribute("value")))
				//&& excelData[13].equalsIgnoreCase(Booking_Cancellation_Status.getAttribute("value"))
				//&& excelData[14].equalsIgnoreCase(Invoice_Type.getText()))
				//&& excelData[15].equalsIgnoreCase(Corrected_Booking_Reference.getAttribute("value"))
				//&& excelData[13].equalsIgnoreCase(Intraday_Vacation.getAttribute("value")))
		{
			assertionHelper.markPass("Bill details Field validated successfully.");
		}
		else {
			assertionHelper.markFail("Bill details Field do not match");
		}
	}

	@SuppressWarnings("static-access")
	public void VerifyAccountSummaryDetails(String condition, String condition1) throws Exception {
		String[] excelData = BNPP_BillDetail_Page.getTestData(condition);
		
		Wait.waitUnitWebElementVisible(driver, Account_Level_Summary);
		
		WebElement accountNumberElement = driver.findElement(By.xpath("//label[text()='Account Level Summary']//following::table[1]/tbody/tr["+condition1+"]/td[1]/span/input"));
		String accountNumber =accountNumberElement.getAttribute("value");
		
		WebElement currencyElement = driver.findElement(By.xpath("//label[text()='Account Level Summary']//following::table[1]/tbody/tr["+condition1+"]/td[2]/span/input"));
		String currency = currencyElement.getAttribute("value");
		
		WebElement priceElement = driver.findElement(By.xpath("//label[text()='Account Level Summary']//following::table[1]/tbody/tr["+condition1+"]/td[3]/span/input"));
		String price = priceElement.getAttribute("value");
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;  
		   js.executeScript("arguments[0].scrollIntoView();", Account_Level_Summary);
		Screenshot.takeSnapShot(driver, "BillDetails\\");
		Thread.sleep(3000);
			if(excelData[2].equalsIgnoreCase(accountNumber)){
				if(excelData[8].equalsIgnoreCase(currency)) {
					if(excelData[9].equalsIgnoreCase(price))						
						{
						Wait.waitUnitWebElementVisible(driver, Account_Summary_Link);
						Account_Summary_Link.click();
						Thread.sleep(3000);
						JavascriptExecutor jss = (JavascriptExecutor) driver;  
						   jss.executeScript("arguments[0].scrollIntoView();", Grand_Total_Label);
						Screenshot.takeSnapShot(driver, "BillDetails\\");
						assertionHelper.markPass("Account Number Available with Summary.");
						}}}
			else
			{
				assertionHelper.markFail("Account Number not Available with Summary.");
			}		
		}
		
	

}
