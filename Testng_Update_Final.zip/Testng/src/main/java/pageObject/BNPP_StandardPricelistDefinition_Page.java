package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.DropDownHelper;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_StandardPricelistDefinition_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	DropDownHelper dropDownHelper = new DropDownHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	static String TableName = "Standard Pricelist Definition";
	static String[] testDataValue;
	Wait wait = new Wait();

	public void BNPP_StandardPriceltisDefinition_Page(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(),'Standard Pricelist Definition')]")
	WebElement Standard_Pricelist_Definition_Label;

	@FindBy(name = "paramRecords[0].TCG_CODE")
	private WebElement Price_List_TextBox;

	@FindBy(name = "paramRecords[0].TCG_DES")
	private WebElement Description_TextBox;

	@FindBy(className = "Successfully saved Record(s)")
	private WebElement MessageHead1;

	@FindBy(id = "SaveBtn")
	private WebElement Save_Button;

	@FindBy(xpath = "//label[contains(text(),'Successfully saved Record(s)')]")
	WebElement Header_message_Label;

	public boolean standard_pricelist_definitionLabel() {
		return Standard_Pricelist_Definition_Label.isDisplayed();

	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Price_List,Description";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);
		return testDataValue;
	}

	public void Standardpricelisdefinition(String condition) throws Exception {
		String[] exelData = BNPP_BookingCancellation_Page.getTestData(condition);

		String pl = exelData[0];
		String dec = exelData[1];
		Price_List_TextBox.sendKeys(pl);
		Description_TextBox.sendKeys(dec);
		Save_Button.click();
		Wait.untilPageLoadComplete(driver);
	}

	public void validateCreationLabelDisplayed() {
		// TODO Auto-generated method stub
		if (Header_message_Label.getText().contains("Successfully saved Record(s) ")) {
			AssertionHelper.markPass("Message Head is displaying suessfully");
		} else {
			AssertionHelper.markFail("Message Head is not displaying suessfully");
		}
	}
}
