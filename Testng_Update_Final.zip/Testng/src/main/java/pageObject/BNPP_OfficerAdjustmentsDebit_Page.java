package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import helper.AssertionHelper;
import helper.Screenshot;
import helper.VerificationHelper;
import utility.ConfigFileReader;
import utility.ExcelUtils;
import utility.Wait;

public class BNPP_OfficerAdjustmentsDebit_Page {

	WebDriver driver;
	ConfigFileReader configFileReader = new ConfigFileReader();
	VerificationHelper verificationHelper = new VerificationHelper(driver);
	AssertionHelper assertionHelper = new AssertionHelper();
	static String[] testDataValue;

	public BNPP_OfficerAdjustmentsDebit_Page(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//label[contains(text(), 'Officer Adjustments - Debit')]")
	private WebElement OfficerAdjustmentsDebit_Label;

	@FindBy(id = "CD_CUST_ID")
	private WebElement Client_ID_TextBox;

	@FindBy(id = "CD_SUBS_ID")
	private WebElement Account_ID_TextBox;

	@FindBy(xpath = "//a[contains(text(), 'Enter Debit Details')]")
	private WebElement Enter_Debit_Details_Link;

	@FindBy(name = "COMMON.SAVE")
	private WebElement Save_Button;

	@FindBy(name = "COMMON.ADD_DETAILS")
	private WebElement Add_Button;

	@FindBy(name = "COMMON.BUTTON_CLEAR")
	private WebElement Clear_Button;

	@FindBy(xpath = "//caption[contains(text(), 'Adjustment Details')]")
	private WebElement AdjustmentDetails_Label;

	@FindBy(id = "voucherDetails_0__CDD_BD_CODE")
	private WebElement Charge_Code_TextBox;

	@FindBy(id = "voucherDetails_0__CDD_RATE_IVC")
	private WebElement Adjustment_Amount_TextBox;

	@SuppressWarnings("static-access")
	public void ckeckOfficerAdjustmentsDebitLabelDisplayed() {
		Screenshot.takeSnapShot(driver, "OfficerAdjustmentsDebit\\");
		if (verificationHelper.isDisplayed(OfficerAdjustmentsDebit_Label)) {
			assertionHelper.markPass();
		} else {
			assertionHelper.markFail();
		}
	}

	@SuppressWarnings("static-access")
	public void ckeckAdjustmentDetailsLabelDisplayed() {
		Screenshot.takeSnapShot(driver, "OfficerAdjustmentsDebit\\");
		if (verificationHelper.isDisplayed(AdjustmentDetails_Label)) {
			assertionHelper.markPass();
		} else {
			assertionHelper.markFail();
		}
	}

	public static String[] getTestData(String condition) throws Exception {
		String RowNo = "1";
		String column = "Client_ID,Account_ID,Charge_Code,Adjustment_Amount";
		String TableName = "Officer_Adjustments_Debit";
		testDataValue = ExcelUtils.getCellData(RowNo, column, TableName, condition);	
		return testDataValue;

	}

	public void EnterIDForDebitOfficerAdjustment(String condition) throws Exception {
		String[] excelData = BNPP_OfficerAdjustmentsDebit_Page.getTestData(condition);
		
		String ClientID = excelData[0];
		String AccountID = excelData[1];
				
		Client_ID_TextBox.sendKeys(ClientID);
		Account_ID_TextBox.sendKeys(AccountID);
		Enter_Debit_Details_Link.click();
		Wait.untilPageLoadComplete(driver);
		Screenshot.takeSnapShot(driver, "OfficerAdjustmentsDebit\\");
		
	}
	public void EnterAdjustmentdetails(String condition) throws Exception {
		String[] excelData = BNPP_OfficerAdjustmentsDebit_Page.getTestData(condition);
		String ChargeCode = excelData[2];
		String AdjustmentAmount = excelData[3];
		Charge_Code_TextBox.sendKeys(ChargeCode);
		Adjustment_Amount_TextBox.sendKeys(AdjustmentAmount);
		Screenshot.takeSnapShot(driver, "OfficerAdjustmentsDebit\\");		
	}

	public WebElement AddButton() {
		return Add_Button;
	}

	public WebElement SaveButton() {
		return Save_Button;
	}	

}
